export interface City {
  id: string;
  name: string;
  country: string;
  flag: string;
  region: 'Europe' | 'North America' | 'Asia-Pac' | 'Middle East' | 'Other';
  costIndex: number; // London base = 100
  rentIndex: number;
  groceriesIndex: number;
  transitIndex: number;
  diningIndex: number;
  healthcareIndex: number;
  averageMonthlyRent: number; // in USD
  currency: string;
  currencySymbol: string;
  medianTechSalaryLocal: string;
  surplusNote?: string;
  popular?: boolean;
}

export interface Currency {
  code: string;
  name: string;
  symbol: string;
  rateToGBP: number; // 1 GBP = X
  rateToUSD: number; // 1 USD = X
  flag: string;
  change24h: number;
  category: 'Popular' | 'Major FX' | 'Asia-Pacific' | 'Crypto/Pegged';
}

export interface ParityBasketItem {
  id: string;
  title: string;
  subtext: string;
  originMonthly: number;
  destMonthly: number;
  diffPercent: number; // negative means origin is cheaper, positive means origin is more expensive
  icon: string;
}

export type HouseholdType = 'single' | 'dual' | 'family-1' | 'family-2plus';
export type LifestyleTier = 'frugal' | 'balanced' | 'executive';
export type ResidenceType = 'prime' | 'outer' | 'luxury';

export interface UserScenario {
  originCityId: string;
  destCityId: string;
  baseSalary: number; // in Origin Currency
  currencyCode: string;
  isAnnual: boolean;
  household: HouseholdType;
  lifestyle: LifestyleTier;
  residence: ResidenceType;
  deductTaxes: boolean;
  theme: 'light' | 'dark' | 'system';
  numberFormat: 'us' | 'eu';
}

export interface UserProfile {
  fullName: string;
  email: string;
  role: string;
  homeCityId: string;
  preferredCurrency: string;
  baseSalary: number;
  isAnnual: boolean;
  bio: string;
  avatarColor: string;
}

export interface RagGroundedSource {
  title: string;
  url: string;
}

export interface RagVerificationResult {
  success: boolean;
  analysis: string;
  queriesExecuted: string[];
  groundedSources: RagGroundedSource[];
  timestamp: string;
  provider: string;
  error?: string;
}

export interface AlertItem {
  id: string;
  title: string;
  description: string;
  timeAgo: string;
  type: 'fx' | 'rent' | 'inflation';
  read: boolean;
}
