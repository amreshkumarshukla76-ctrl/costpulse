import { City, Currency, UserScenario, ParityBasketItem } from '../types';

export function formatCurrencyNumber(num: number, currencySymbol: string = '$'): string {
  return `${currencySymbol}${Math.round(num).toLocaleString('en-US')}`;
}

/**
 * Returns a realistic, corporate baseline compensation for a city based on its currency and living costs.
 * Prevents toy/sub-poverty anchors (e.g. converting GBP 85k to INR 85k/year instead of 10-15 LPA).
 */
export function getRealisticBaselineForCity(city: City, isAnnual: boolean = true): number {
  if (city.currency === 'INR') {
    // 15 LPA (₹15,00,000/yr) is standard corporate mid-senior CTC in Mumbai/Delhi/BLR, or ₹1,25,000/mo
    return isAnnual ? 1500000 : 125000;
  }
  if (city.currency === 'GBP') {
    return isAnnual ? 85000 : 7083;
  }
  if (city.currency === 'USD') {
    return isAnnual ? 135000 : 11250;
  }
  if (city.currency === 'EUR') {
    return isAnnual ? 75000 : 6250;
  }
  if (city.currency === 'CHF') {
    return isAnnual ? 140000 : 11667;
  }
  if (city.currency === 'AED') {
    return isAnnual ? 300000 : 25000;
  }
  if (city.currency === 'SGD') {
    return isAnnual ? 130000 : 10833;
  }
  if (city.currency === 'JPY') {
    return isAnnual ? 9500000 : 791667;
  }
  if (city.currency === 'CAD') {
    return isAnnual ? 115000 : 9583;
  }
  return isAnnual ? 85000 : 7000;
}

export function calculateParity(
  origin: City,
  dest: City,
  scenario: UserScenario,
  currencies: Currency[]
) {
  // Find exchange rates (rateToUSD: 1 USD = X units of currency)
  const originCurrency = currencies.find((c) => c.code === origin.currency) || currencies[0];
  const destCurrency = currencies.find((c) => c.code === dest.currency) || currencies[1];

  const originUsdRate = originCurrency.rateToUSD > 0 ? originCurrency.rateToUSD : 1;
  const destUsdRate = destCurrency.rateToUSD > 0 ? destCurrency.rateToUSD : 1;

  // Household multiplier
  let householdMult = 1.0;
  if (scenario.household === 'dual') householdMult = 1.5;
  if (scenario.household === 'family-1') householdMult = 1.85;
  if (scenario.household === 'family-2plus') householdMult = 2.2;

  // Lifestyle multiplier
  let lifestyleMult = 1.0;
  if (scenario.lifestyle === 'frugal') lifestyleMult = 0.88;
  if (scenario.lifestyle === 'executive') lifestyleMult = 1.28;

  // Residence multiplier & Rent weighting
  // In real-world economics, housing accounts for 30% to 40% of standard living costs
  let residenceMult = 1.0;
  let rentWeight = 0.35;
  if (scenario.residence === 'outer') {
    residenceMult = 0.80;
    rentWeight = 0.30;
  } else if (scenario.residence === 'luxury') {
    residenceMult = 1.35;
    rentWeight = 0.40;
  }
  const cpiWeight = 1.0 - rentWeight;

  // TRUE COST OF LIVING PLUS RENT COMPOSITE INDEX
  // Merges non-housing consumer prices with actual residential lease market indices
  const originCompositeIndex = (origin.costIndex * cpiWeight) + (origin.rentIndex * rentWeight);
  const destCompositeIndex = (dest.costIndex * cpiWeight) + (dest.rentIndex * rentWeight);

  // Parity Ratio: Destination Composite Index / Origin Composite Index
  const ratio = destCompositeIndex / Math.max(originCompositeIndex, 1);
  const costDiffPercent = ((destCompositeIndex - originCompositeIndex) / originCompositeIndex) * 100;

  // UNIT NORMALIZATION: Clarify Annual vs Monthly
  const isAnnual = scenario.isAnnual;
  const baseSalaryAnnual = isAnnual ? scenario.baseSalary : scenario.baseSalary * 12;
  const baseSalaryMonthly = isAnnual ? scenario.baseSalary / 12 : scenario.baseSalary;

  // Parity conversion in USD baseline
  const baseSalaryAnnualUSD = baseSalaryAnnual / originUsdRate;
  const targetRequiredAnnualUSD = baseSalaryAnnualUSD * ratio * lifestyleMult * residenceMult;
  const targetRequiredDestAnnual = targetRequiredAnnualUSD * destUsdRate;
  const targetRequiredDestMonthly = targetRequiredDestAnnual / 12;

  // Active target based on selected scenario period (annual or monthly)
  const targetRequiredDest = isAnnual ? targetRequiredDestAnnual : targetRequiredDestMonthly;
  const targetRequiredUSD = isAnnual ? targetRequiredAnnualUSD : targetRequiredAnnualUSD / 12;

  // Effective localized tax estimation
  const getTaxRate = (country: string, annualGrossInUSD: number) => {
    switch (country) {
      case 'United Kingdom': return 0.31;
      case 'USA': return 0.32;
      case 'UAE': return 0.0;
      case 'Germany': return 0.38;
      case 'France': return 0.36;
      case 'Switzerland': return 0.19;
      case 'Singapore': return 0.14;
      case 'Japan': return 0.26;
      case 'Spain': return 0.28;
      case 'India':
        // Indian New Tax Regime: progressive ~10% to 25% effective
        if (annualGrossInUSD < 15000) return 0.10;
        if (annualGrossInUSD < 35000) return 0.18;
        return 0.25;
      default: return 0.26;
    }
  };

  const originTaxRate = getTaxRate(origin.country, baseSalaryAnnualUSD);
  const destTaxRate = getTaxRate(dest.country, targetRequiredAnnualUSD);

  const effectiveOriginTax = scenario.deductTaxes ? originTaxRate : 0;
  const effectiveDestTax = scenario.deductTaxes ? destTaxRate : 0;

  const originNetMonthly = baseSalaryMonthly * (1 - effectiveOriginTax);
  const destNetMonthly = targetRequiredDestMonthly * (1 - effectiveDestTax);
  const originNetAnnual = originNetMonthly * 12;
  const destNetAnnual = destNetMonthly * 12;

  // Localized living expenses in respective local currencies
  // averageMonthlyRent is calibrated in USD, convert to local currency
  const originRentMonthlyLocal = (origin.averageMonthlyRent * originUsdRate) * residenceMult;
  const destRentMonthlyLocal = (dest.averageMonthlyRent * destUsdRate) * residenceMult;

  // Non-rent living expenses in local currency
  // Calibrated with baseline: ~$950/mo in London * (costIndex / 100) * householdMult * lifestyleMult
  const originNonRentMonthlyLocal = (950 * (origin.costIndex / 100) * originUsdRate) * householdMult * lifestyleMult;
  const destNonRentMonthlyLocal = (950 * (dest.costIndex / 100) * destUsdRate) * householdMult * lifestyleMult;

  const originLivingCostMonthly = originRentMonthlyLocal + originNonRentMonthlyLocal;
  const destLivingCostMonthly = destRentMonthlyLocal + destNonRentMonthlyLocal;

  const originSurplus = Math.max(0, originNetMonthly - originLivingCostMonthly);
  const destSurplus = Math.max(0, destNetMonthly - destLivingCostMonthly);
  const originSurplusUSD = originSurplus / originUsdRate;
  const destSurplusUSD = destSurplus / destUsdRate;
  const hasOriginAdvantage = originSurplusUSD >= destSurplusUSD;
  const surplusDeltaUSD = Math.abs(originSurplusUSD - destSurplusUSD);
  const surplusDeltaOrigin = Math.round(surplusDeltaUSD * originUsdRate);
  const surplusDeltaDest = Math.round(surplusDeltaUSD * destUsdRate);

  // Category basket items comparing local market power
  const originRent = Math.round(originRentMonthlyLocal);
  const destRent = Math.round(destRentMonthlyLocal);
  const rentDiff = ((dest.rentIndex - origin.rentIndex) / Math.max(origin.rentIndex, 1)) * 100;

  const groceriesDiff = ((dest.groceriesIndex - origin.groceriesIndex) / Math.max(origin.groceriesIndex, 1)) * 100;
  const transitDiff = ((dest.transitIndex - origin.transitIndex) / Math.max(origin.transitIndex, 1)) * 100;
  const healthcareDiff = ((dest.healthcareIndex - origin.healthcareIndex) / Math.max(origin.healthcareIndex, 1)) * 100;
  const diningDiff = ((dest.diningIndex - origin.diningIndex) / Math.max(origin.diningIndex, 1)) * 100;

  const originGroceries = Math.round(350 * (origin.groceriesIndex / 100) * originUsdRate * householdMult);
  const destGroceries = Math.round(350 * (dest.groceriesIndex / 100) * destUsdRate * householdMult);

  const originTransit = Math.round(120 * (origin.transitIndex / 100) * originUsdRate);
  const destTransit = Math.round(120 * (dest.transitIndex / 100) * destUsdRate);

  const originHealthcare = Math.round(80 * (origin.healthcareIndex / 100) * originUsdRate * householdMult);
  const destHealthcare = Math.round(80 * (dest.healthcareIndex / 100) * destUsdRate * householdMult);

  const originDining = Math.round(300 * (origin.diningIndex / 100) * originUsdRate * lifestyleMult);
  const destDining = Math.round(300 * (dest.diningIndex / 100) * destUsdRate * lifestyleMult);

  const baskets: ParityBasketItem[] = [
    {
      id: 'housing',
      title: 'Housing & Rent',
      subtext: `${origin.name} residential lease vs ${dest.name} equivalent flat`,
      originMonthly: originRent,
      destMonthly: destRent,
      diffPercent: rentDiff,
      icon: 'Building2',
    },
    {
      id: 'groceries',
      title: 'Groceries & Daily Essentials',
      subtext: `${origin.name} grocery basket vs ${dest.name} supermarket index`,
      originMonthly: originGroceries,
      destMonthly: destGroceries,
      diffPercent: groceriesDiff,
      icon: 'ShoppingCart',
    },
    {
      id: 'transit',
      title: 'Municipal Transit & Fuel',
      subtext: `${origin.name} transit pass vs ${dest.name} local mobility`,
      originMonthly: originTransit,
      destMonthly: destTransit,
      diffPercent: transitDiff,
      icon: 'Train',
    },
    {
      id: 'healthcare',
      title: 'Healthcare & Medical Outlays',
      subtext: `${origin.name} out-of-pocket & coverage vs ${dest.name}`,
      originMonthly: originHealthcare,
      destMonthly: destHealthcare,
      diffPercent: healthcareDiff,
      icon: 'Shield',
    },
    {
      id: 'dining',
      title: 'Dining, Cafes & Leisure',
      subtext: `Mid-tier dining for two, cafes, and leisure indices`,
      originMonthly: originDining,
      destMonthly: destDining,
      diffPercent: diningDiff,
      icon: 'UtensilsCrossed',
    },
  ];

  return {
    ratio,
    costDiffPercent,
    targetRequiredDest,
    targetRequiredUSD,
    targetRequiredDestAnnual,
    targetRequiredDestMonthly,
    baseSalaryAnnual,
    baseSalaryMonthly,
    originNetMonthly,
    destNetMonthly,
    originNetAnnual,
    destNetAnnual,
    originSurplus,
    destSurplus,
    originSurplusUSD,
    destSurplusUSD,
    hasOriginAdvantage,
    surplusDeltaUSD,
    surplusDeltaOrigin,
    surplusDeltaDest,
    originTaxRate,
    destTaxRate,
    originCompositeIndex,
    destCompositeIndex,
    rentWeight,
    cpiWeight,
    baskets,
  };
}

