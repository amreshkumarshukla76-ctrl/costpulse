import { City, UserScenario } from '../types';

/**
 * Updates the document head with dynamic OpenGraph meta tags, Twitter card tags,
 * canonical URLs, page titles, and Schema.org JSON-LD structured data tailored to
 * the active view and city comparison pair.
 */
export function updateComparisonSEO(
  activeView: string,
  originCity: City,
  destCity: City,
  scenario: UserScenario,
  targetSalaryDest: number,
  destCurrencySymbol: string
) {
  if (typeof document === 'undefined') return;

  const currentOrigin = typeof window !== 'undefined' ? window.location.origin : '';
  const currentPath = typeof window !== 'undefined' ? window.location.pathname : '';
  const canonicalUrl = `${currentOrigin}${currentPath}`;
  const periodLabel = scenario.isAnnual ? '/year' : '/month';

  let title = '';
  let description = '';
  let ogImage = 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&h=630&q=85';

  if (activeView === 'analytics') {
    title = `${originCity.name} vs ${destCity.name} Financial Matrix & Cost of Living Parity`;
    description = `Deep econometric breakdown between ${originCity.name} and ${destCity.name}. Rent, groceries, transit, dining, healthcare outlays, and net disposable surplus matrix.`;
  } else if (activeView === 'hub') {
    title = `Global Metro Platform Hub — Cost of Living & Purchasing Power Index`;
    description = `Explore 160+ world cities by purchasing power, median compensation, average rent, and living cost indexes across North America, Europe, Asia, and the Middle East.`;
  } else {
    // Default Hero Comparison View
    title = `${originCity.name} to ${destCity.name} Salary & Purchasing Power Calculator`;
    description = `Need ${destCurrencySymbol}${Math.round(targetSalaryDest).toLocaleString()}${periodLabel} in ${destCity.name} to maintain a ${originCity.currencySymbol}${scenario.baseSalary.toLocaleString()}${periodLabel} lifestyle in ${originCity.name}. Real-time parity engine.`;
  }

  // 1. Update Title
  document.title = `${title} | GetCostPulse`;

  // 2. Helper to set or update meta tag
  const setMetaTag = (attribute: 'name' | 'property', key: string, content: string) => {
    let el = document.querySelector(`meta[${attribute}="${key}"]`);
    if (!el) {
      el = document.createElement('meta');
      el.setAttribute(attribute, key);
      document.head.appendChild(el);
    }
    el.setAttribute('content', content);
  };

  // Standard Meta Tags
  setMetaTag('name', 'description', description);
  setMetaTag('name', 'robots', 'index, follow, max-snippet:-1, max-image-preview:large');

  // OpenGraph Meta Tags
  setMetaTag('property', 'og:site_name', 'GetCostPulse');
  setMetaTag('property', 'og:type', 'website');
  setMetaTag('property', 'og:title', title);
  setMetaTag('property', 'og:description', description);
  setMetaTag('property', 'og:url', canonicalUrl);
  setMetaTag('property', 'og:image', ogImage);
  setMetaTag('property', 'og:image:width', '1200');
  setMetaTag('property', 'og:image:height', '630');
  setMetaTag('property', 'og:image:alt', `${originCity.name} vs ${destCity.name} Cost of Living Comparison`);
  setMetaTag('property', 'og:locale', 'en_US');

  // Twitter Cards
  setMetaTag('name', 'twitter:card', 'summary_large_image');
  setMetaTag('name', 'twitter:title', title);
  setMetaTag('name', 'twitter:description', description);
  setMetaTag('name', 'twitter:image', ogImage);

  // Canonical Tag
  let canonicalLink = document.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
  if (!canonicalLink) {
    canonicalLink = document.createElement('link');
    canonicalLink.setAttribute('rel', 'canonical');
    document.head.appendChild(canonicalLink);
  }
  canonicalLink.setAttribute('href', canonicalUrl);

  // 3. Dynamic JSON-LD Structured Data
  let ldJsonScript = document.getElementById('dynamic-comparison-jsonld') as HTMLScriptElement | null;
  if (!ldJsonScript) {
    ldJsonScript = document.createElement('script');
    ldJsonScript.id = 'dynamic-comparison-jsonld';
    ldJsonScript.type = 'application/ld+json';
    document.head.appendChild(ldJsonScript);
  }

  const structuredData = {
    '@context': 'https://schema.org',
    '@graph': [
      {
        '@type': 'WebPage',
        '@id': `${canonicalUrl}#webpage`,
        url: canonicalUrl,
        name: title,
        description: description,
        inLanguage: 'en-US',
        isPartOf: {
          '@type': 'WebSite',
          '@id': `${currentOrigin}/#website`,
          url: currentOrigin,
          name: 'GetCostPulse',
          description: 'Purchasing power parity engine and cost-of-living comparison matrix across global metros.',
        },
        breadcrumb: {
          '@type': 'BreadcrumbList',
          itemListElement: [
            {
              '@type': 'ListItem',
              position: 1,
              name: 'Home',
              item: currentOrigin,
            },
            {
              '@type': 'ListItem',
              position: 2,
              name: `${originCity.name} vs ${destCity.name}`,
              item: canonicalUrl,
            },
          ],
        },
        about: [
          {
            '@type': 'City',
            name: originCity.name,
            containedInPlace: {
              '@type': 'Country',
              name: originCity.country,
            },
          },
          {
            '@type': 'City',
            name: destCity.name,
            containedInPlace: {
              '@type': 'Country',
              name: destCity.country,
            },
          },
        ],
      },
      {
        '@type': 'FinancialProduct',
        name: `${originCity.name} to ${destCity.name} Purchasing Power Parity Calculation`,
        description: `Financial parity model calculating equivalent gross and net income required between ${originCity.name} and ${destCity.name}.`,
        category: 'Cost of Living Calculator',
        provider: {
          '@type': 'Organization',
          name: 'GetCostPulse',
          url: currentOrigin,
        },
        offers: {
          '@type': 'Offer',
          price: '0',
          priceCurrency: 'USD',
          availability: 'https://schema.org/InStock',
        },
      },
    ],
  };

  ldJsonScript.textContent = JSON.stringify(structuredData, null, 2);
}
