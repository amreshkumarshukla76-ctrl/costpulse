import React, { useState, useEffect } from 'react';
import { X, DollarSign, Check, Calendar } from 'lucide-react';
import { City } from '../types';

interface SalaryEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentSalary: number;
  isAnnual?: boolean;
  originCity: City;
  onSaveSalary: (newSalary: number, isAnnual: boolean) => void;
}

export const SalaryEditorModal: React.FC<SalaryEditorModalProps> = ({
  isOpen,
  onClose,
  currentSalary,
  isAnnual = true,
  originCity,
  onSaveSalary,
}) => {
  const [val, setVal] = useState(currentSalary.toString());
  const [selectedIsAnnual, setSelectedIsAnnual] = useState(isAnnual);

  useEffect(() => {
    if (isOpen) {
      setVal(currentSalary.toString());
      setSelectedIsAnnual(isAnnual);
    }
  }, [isOpen, currentSalary, isAnnual]);

  if (!isOpen) return null;

  const handleTogglePeriod = (annual: boolean) => {
    if (annual === selectedIsAnnual) return;
    const num = parseFloat(val.replace(/[^0-9.]/g, ''));
    if (!isNaN(num) && num > 0) {
      if (annual) {
        // Switching from Monthly to Annual
        setVal(Math.round(num * 12).toString());
      } else {
        // Switching from Annual to Monthly
        setVal(Math.round(num / 12).toString());
      }
    }
    setSelectedIsAnnual(annual);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const num = parseFloat(val.replace(/[^0-9.]/g, ''));
    if (!isNaN(num) && num > 0) {
      onSaveSalary(num, selectedIsAnnual);
      onClose();
    }
  };

  const isINR = originCity.currency === 'INR';

  // Currency and period contextual presets
  const quickSalaries = selectedIsAnnual
    ? isINR
      ? [
          { label: 'Corporate (10 LPA)', amount: 1000000 },
          { label: 'Mid-Senior (15 LPA)', amount: 1500000 },
          { label: 'Lead / SDE-3 (25 LPA)', amount: 2500000 },
          { label: 'Exec (40 LPA)', amount: 4000000 },
        ]
      : [
          { label: 'Junior', amount: 55000 },
          { label: 'Mid-Level', amount: 85000 },
          { label: 'Senior', amount: 140000 },
          { label: 'Principal', amount: 220000 },
        ]
    : isINR
    ? [
        { label: 'Junior (₹50k/mo)', amount: 50000 },
        { label: 'Corporate (₹85k/mo)', amount: 85000 },
        { label: 'Lead (₹1.5L/mo)', amount: 150000 },
        { label: 'Director (₹2.5L/mo)', amount: 250000 },
      ]
    : [
        { label: 'Junior', amount: 4500 },
        { label: 'Mid-Level', amount: 7000 },
        { label: 'Senior', amount: 11500 },
        { label: 'Principal', amount: 18000 },
      ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 dark:bg-slate-950/75">
      <div
        id="salary-editor-modal"
        className="w-full max-w-sm bg-white dark:bg-slate-900 border border-slate-200 dark:border-white/15 rounded-3xl p-5 shadow-2xl text-slate-900 dark:text-slate-100 space-y-4 transition-colors"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            <h3 className="text-base font-bold text-slate-900 dark:text-white">Adjust Base Compensation</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/10"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs text-slate-500 dark:text-slate-400">
          Enter your gross compensation in <span className="font-semibold text-slate-800 dark:text-slate-200">{originCity.name}</span> ({originCity.currency}).
        </p>

        {/* Period Selector Tabs: Monthly vs Annual */}
        <div className="flex items-center p-1 rounded-xl bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-white/10 text-xs font-semibold">
          <button
            type="button"
            onClick={() => handleTogglePeriod(false)}
            className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
              !selectedIsAnnual
                ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Monthly (/mo)</span>
          </button>
          <button
            type="button"
            onClick={() => handleTogglePeriod(true)}
            className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
              selectedIsAnnual
                ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Annual (/yr)</span>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative flex items-center">
            <span className="absolute left-3.5 text-base font-bold text-slate-400 font-mono">
              {originCity.currencySymbol}
            </span>
            <input
              type="text"
              autoFocus
              value={val}
              onChange={(e) => setVal(e.target.value)}
              className="w-full pl-9 pr-14 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-white/12 text-slate-900 dark:text-white font-mono font-bold text-lg focus:outline-none focus:border-cyan-500 shadow-inner"
            />
            <span className="absolute right-3 text-xs text-slate-500 dark:text-slate-400 font-mono font-bold">
              {selectedIsAnnual ? '/yr' : '/mo'}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            {quickSalaries.map((q) => (
              <button
                key={q.label}
                type="button"
                onClick={() => setVal(q.amount.toString())}
                className="py-1.5 px-2 rounded-lg bg-slate-50 dark:bg-white/5 hover:bg-slate-100 dark:hover:bg-white/10 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-white/5 text-left font-mono transition-colors"
              >
                <div className="text-[10px] text-slate-400 font-sans">{q.label}</div>
                <div className="font-bold text-slate-900 dark:text-white">
                  {originCity.currencySymbol}{q.amount.toLocaleString()}
                  <span className="text-[10px] font-normal text-slate-400 ml-0.5">
                    {selectedIsAnnual ? '/yr' : '/mo'}
                  </span>
                </div>
              </button>
            ))}
          </div>

          <button
            type="submit"
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-400 to-sky-500 hover:from-cyan-300 hover:to-sky-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md shadow-cyan-500/20"
          >
            <Check className="w-4 h-4 stroke-[2.5]" />
            <span>Apply {selectedIsAnnual ? 'Annual' : 'Monthly'} Compensation</span>
          </button>
        </form>
      </div>
    </div>
  );
};

