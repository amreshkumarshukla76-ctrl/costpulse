import React, { useState, useEffect } from 'react';
import {
  X,
  ShieldCheck,
  Lock,
  Eye,
  EyeOff,
  ArrowRight,
  Sparkles,
  KeyRound,
  RotateCcw,
  CheckCircle2,
  LogOut,
  User,
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  isAuthenticated: boolean;
  userEmail?: string;
  onSuccessAuth: (email: string) => void;
  onSignOut?: () => void;
  onShowToast?: (msg: string, type?: 'success' | 'info' | 'warning') => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  isAuthenticated,
  userEmail,
  onSuccessAuth,
  onSignOut,
  onShowToast,
}) => {
  const [step, setStep] = useState<'login' | 'mfa'>('login');
  const [email, setEmail] = useState(userEmail || 'c.stewart@stratford-capital.com');
  const [password, setPassword] = useState('Password123!#%');
  const [showPassword, setShowPassword] = useState(false);
  const [require2FA, setRequire2FA] = useState(false);
  const [generatedOtp, setGeneratedOtp] = useState<string>('842915');
  const [otpDigits, setOtpDigits] = useState(['8', '4', '2', '9', '1', '5']);
  const [countdown, setCountdown] = useState(60);
  const [otpSentNotice, setOtpSentNotice] = useState<string | null>(null);

  useEffect(() => {
    if (userEmail) setEmail(userEmail);
  }, [userEmail]);

  useEffect(() => {
    if (step === 'mfa' && countdown > 0) {
      const timer = setInterval(() => setCountdown((c) => c - 1), 1000);
      return () => clearInterval(timer);
    }
  }, [step, countdown]);

  if (!isOpen) return null;

  // Direct login without 2-step verification
  const handleDirectLogin = (targetEmail = email) => {
    onSuccessAuth(targetEmail);
    onShowToast?.(`Signed in successfully as ${targetEmail}`, 'success');
    setStep('login');
    onClose();
  };

  const handleInitialSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (require2FA) {
      handleGenerateOtp();
      setStep('mfa');
    } else {
      handleDirectLogin(email);
    }
  };

  const handleGenerateOtp = () => {
    // Generate a fresh 6-digit OTP
    const newCode = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(newCode);
    setOtpDigits(newCode.split(''));
    setCountdown(60);
    setOtpSentNotice(`Fresh OTP Generated: ${newCode} (Ready to verify)`);
    onShowToast?.(`OTP generated: ${newCode}`, 'success');
  };

  const handleAutofillOtp = () => {
    setOtpDigits(generatedOtp.split(''));
    onShowToast?.(`Autofilled verification code ${generatedOtp}`, 'info');
  };

  const handleOtpChange = (index: number, val: string) => {
    if (val.length > 1) val = val[val.length - 1];
    const newDigits = [...otpDigits];
    newDigits[index] = val;
    setOtpDigits(newDigits);
    if (val && index < 5) {
      const nextInput = document.getElementById(`otp-input-${index + 1}`);
      nextInput?.focus();
    }
  };

  const handleVerify = () => {
    onSuccessAuth(email);
    onShowToast?.(`Verification successful! Welcome back, ${email}`, 'success');
    setStep('login');
    onClose();
  };

  const handleSignOutClick = () => {
    if (onSignOut) {
      onSignOut();
      onClose();
      onShowToast?.('You have been securely signed out.', 'info');
    }
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 dark:bg-slate-950/70 animate-fadeIn"
    >
      <div
        id="auth-modal-container"
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col text-slate-900 dark:text-slate-100 transition-colors"
      >
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-xl text-slate-400 hover:text-slate-800 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors z-20"
        >
          <X className="w-4 h-4" />
        </button>

        {isAuthenticated ? (
          /* ACTIVE USER PROFILE & SIGN OUT VIEW */
          <div className="p-6 md:p-8 space-y-5">
            <div className="flex flex-col items-center text-center">
              <div className="relative mb-3">
                <div className="w-16 h-16 rounded-2xl bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center text-cyan-600 dark:text-cyan-400 shadow-lg">
                  <User className="w-8 h-8 stroke-[2.2]" />
                </div>
                <span className="absolute bottom-0 right-0 w-4 h-4 rounded-full bg-emerald-500 border-2 border-white dark:border-slate-900" />
              </div>
              <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                Active Session
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xs mt-0.5">
                Signed in with verified account <strong className="text-slate-800 dark:text-slate-200">{(userEmail || email).replace(/^(.{2})(.*)(@.*)$/, '$1***$3')}</strong>
              </p>
            </div>

            {/* Session details */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-white/10 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Identity Tier:</span>
                <span className="font-bold text-cyan-600 dark:text-cyan-400">Enterprise Mobility Analyst</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Session Status:</span>
                <span className="flex items-center gap-1.5 font-semibold text-emerald-600 dark:text-emerald-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  <span>Encrypted • 256-bit TLS</span>
                </span>
              </div>
              <div className="flex items-center justify-between font-mono text-[11px]">
                <span className="text-slate-500">Session ID:</span>
                <span className="text-slate-600 dark:text-slate-400">#SES-98241-US-EAST</span>
              </div>
            </div>

            {/* Prominent SIGN OUT BUTTON */}
            <div className="space-y-2 pt-2">
              <button
                id="auth-signout-btn"
                onClick={handleSignOutClick}
                className="w-full py-3 px-4 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 border border-rose-500/30 text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-sm active:scale-95"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out of Account</span>
              </button>

              <button
                onClick={onClose}
                className="w-full py-2.5 px-4 rounded-xl bg-slate-100 dark:bg-white/5 hover:bg-slate-200 dark:hover:bg-white/10 text-slate-700 dark:text-slate-300 text-xs font-semibold transition-colors"
              >
                Close &amp; Keep Session Active
              </button>
            </div>
          </div>
        ) : (
          /* LOGIN OR MFA FORM */
          <>
            {step === 'login' && (
              <div className="p-6 md:p-8 space-y-5">
                <div className="flex flex-col items-center text-center">
                  <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center text-cyan-600 dark:text-cyan-400 mb-3 shadow-lg shadow-cyan-500/10">
                    <ShieldCheck className="w-6 h-6 stroke-[2.2]" />
                  </div>
                  <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                    Welcome to GetCostPulse
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xs mt-1 leading-relaxed">
                    Sign in to access real-time purchasing power telemetry, custom parity portfolios, and synchronized relocation benchmarks.
                  </p>
                </div>

            {/* SSO buttons */}
            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => handleDirectLogin('executive.user@gmail.com')}
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700/80 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-800 dark:text-slate-200 transition-all hover:border-cyan-400/40"
              >
                <span>🌐</span>
                <span>Sign in with Google</span>
              </button>
              <button
                type="button"
                onClick={() => handleDirectLogin('analyst.corp@stratford-capital.com')}
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700/80 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-800 dark:text-slate-200 transition-all hover:border-cyan-400/40"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400" />
                <span>Single Sign-On (SSO)</span>
              </button>
            </div>

            <div className="flex items-center gap-3">
              <div className="flex-1 h-px bg-slate-200 dark:bg-slate-800" />
              <span className="text-[10px] font-mono uppercase tracking-wider text-slate-500">
                or sign in with credentials
              </span>
              <div className="flex-1 h-px bg-slate-200 dark:bg-slate-800" />
            </div>

            <form onSubmit={handleInitialSubmit} className="space-y-3 text-xs">
              <div>
                <label className="text-[10px] font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 block mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500"
                  required
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400">
                    Password / Security Key
                  </label>
                  <button
                    type="button"
                    onClick={() => onShowToast?.(`Password recovery link dispatched to ${email}.`, 'info')}
                    className="text-[10px] text-cyan-600 dark:text-cyan-400 hover:underline"
                  >
                    Forgot?
                  </button>
                </div>
                <div className="relative flex items-center">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-3.5 pr-10 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 font-mono"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 text-slate-400 hover:text-slate-700 dark:hover:text-white"
                  >
                    {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {/* 2-Step Option Toggle */}
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 flex items-center justify-between">
                <label className="flex items-center gap-2 cursor-pointer select-none text-[11px] text-slate-700 dark:text-slate-300">
                  <input
                    type="checkbox"
                    checked={require2FA}
                    onChange={(e) => setRequire2FA(e.target.checked)}
                    className="rounded border-slate-300 dark:border-slate-600 text-cyan-600 focus:ring-cyan-500"
                  />
                  <span>Enable 2-Step OTP Verification</span>
                </label>
                <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${require2FA ? 'bg-cyan-500/15 text-cyan-700 dark:text-cyan-300' : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-400'}`}>
                  {require2FA ? 'OTP Required' : 'Direct Login'}
                </span>
              </div>

              {/* Login Actions */}
              <div className="space-y-2 pt-1">
                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-sky-500 hover:from-cyan-400 hover:to-sky-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-lg shadow-cyan-500/20 cursor-pointer"
                >
                  <span>{require2FA ? 'Continue to 2-Step Verification' : 'Sign In Directly'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                {require2FA && (
                  <button
                    type="button"
                    onClick={() => handleDirectLogin(email)}
                    className="w-full py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 text-[11px] font-medium transition-all"
                  >
                    ⚡ Skip 2-Step &amp; Log In Directly
                  </button>
                )}
              </div>
            </form>

            <div className="pt-1 text-center text-[10px] text-slate-500 flex items-center justify-center gap-3">
              <span>🔒 256-BIT TLS</span>
              <span>•</span>
              <span>🛡️ SOC-2 TYPE II</span>
              <span>•</span>
              <span>🌐 CLIENT-SIDE PRIVACY</span>
            </div>
          </div>
        )}

        {step === 'mfa' && (
          <div className="p-6 md:p-8 space-y-4">
            <div className="flex flex-col items-center text-center">
              <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center text-cyan-400 mb-2 shadow-lg">
                <KeyRound className="w-6 h-6" />
              </div>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 uppercase tracking-wider mb-1">
                • 2-STEP OTP VERIFICATION
              </span>
              <h2 className="text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">Enter One-Time Passcode</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xs mt-0.5 leading-relaxed">
                Verification code dispatched for <span className="text-slate-800 dark:text-white font-medium">{email}</span>.
              </p>
            </div>

            {/* GET OTP CARD & AUTOFILL HELPER */}
            <div className="p-3 rounded-2xl bg-cyan-50/70 dark:bg-cyan-950/20 border border-cyan-200 dark:border-cyan-500/30 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-cyan-800 dark:text-cyan-300 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400" />
                  <span>One-Time Passcode (OTP):</span>
                </span>
                <span className="font-mono text-sm font-extrabold text-emerald-600 dark:text-emerald-400 tracking-wider bg-emerald-500/15 px-2 py-0.5 rounded-lg border border-emerald-500/30">
                  {generatedOtp}
                </span>
              </div>
              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={handleGenerateOtp}
                  className="flex-1 py-1.5 px-2.5 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-700 dark:text-cyan-300 text-[11px] font-bold flex items-center justify-center gap-1.5 transition-all"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Get New OTP</span>
                </button>
                <button
                  type="button"
                  onClick={handleAutofillOtp}
                  className="flex-1 py-1.5 px-2.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-700 dark:text-emerald-300 text-[11px] font-bold flex items-center justify-center gap-1.5 transition-all"
                >
                  <CheckCircle2 className="w-3 h-3" />
                  <span>Auto-Fill {generatedOtp}</span>
                </button>
              </div>
            </div>

            {/* 6-Digit OTP Boxes */}
            <div className="flex justify-center gap-2 my-2">
              {otpDigits.map((digit, i) => (
                <input
                  key={i}
                  id={`otp-input-${i}`}
                  type="text"
                  maxLength={1}
                  value={digit}
                  onChange={(e) => handleOtpChange(i, e.target.value)}
                  className="w-10 h-12 text-center text-lg font-bold font-mono rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 text-slate-900 dark:text-white shadow-inner"
                />
              ))}
            </div>

            <div className="flex items-center justify-between text-xs text-slate-400">
              <div className="flex items-center gap-1.5 font-mono text-[11px]">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                <span>Expires in 00:{countdown < 10 ? `0${countdown}` : countdown}</span>
              </div>
              <button
                type="button"
                onClick={handleGenerateOtp}
                className="text-cyan-400 hover:underline inline-flex items-center gap-1 text-[11px] font-medium"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Get Fresh OTP</span>
              </button>
            </div>

            <div className="space-y-2 pt-1">
              <button
                onClick={handleVerify}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-sky-500 hover:from-cyan-400 hover:to-sky-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-lg shadow-cyan-500/20 cursor-pointer"
              >
                <span>Verify OTP &amp; Complete Sign In</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => handleDirectLogin(email)}
                className="w-full py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 text-[11px] font-medium transition-all"
              >
                ⚡ Skip Verification &amp; Enter Directly
              </button>
            </div>

            <div className="text-center pt-1">
              <button
                onClick={() => setStep('login')}
                className="text-xs text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white transition-colors"
              >
                ← Return to credential sign in
              </button>
            </div>
          </div>
        )}
        </>
        )}

        {/* Footer Metrics */}
        <div className="p-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 grid grid-cols-3 gap-2 text-center text-xs">
          <div>
            <span className="text-[9px] font-bold uppercase tracking-wider text-slate-500 block">
              Parity Delta
            </span>
            <span className="font-bold text-cyan-600 dark:text-cyan-400 font-mono">+14.2% NYC</span>
          </div>
          <div>
            <span className="text-[9px] font-bold uppercase tracking-wider text-slate-500 block">
              FX Settlement
            </span>
            <span className="font-bold text-slate-800 dark:text-white font-mono">1.284 GBP/USD</span>
          </div>
          <div>
            <span className="text-[9px] font-bold uppercase tracking-wider text-slate-500 block">
              System Status
            </span>
            <span className="font-bold text-emerald-600 dark:text-emerald-400 font-mono">99.98% SLA</span>
          </div>
        </div>
      </div>
    </div>
  );
};
