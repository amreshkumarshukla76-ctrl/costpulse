import React from 'react';
import {
  Home,
  Search,
  LayoutGrid,
  TrendingUp,
  User,
  Bell,
  Settings,
  Moon,
  Sun,
  ShieldCheck,
  LifeBuoy,
  Menu,
} from 'lucide-react';

interface SidebarProps {
  activeView: 'hero' | 'analytics' | 'hub';
  onSelectView: (view: 'hero' | 'analytics' | 'hub') => void;
  onOpenSearch: () => void;
  onOpenAuth: () => void;
  onOpenAlerts: () => void;
  onOpenSettings: () => void;
  onToggleTheme: () => void;
  onOpenVerify?: () => void;
  onOpenSupport?: () => void;
  onOpenProfile?: () => void;
  isDarkMode: boolean;
  unreadAlertsCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeView,
  onSelectView,
  onOpenSearch,
  onOpenAuth,
  onOpenAlerts,
  onOpenSettings,
  onToggleTheme,
  onOpenVerify,
  onOpenSupport,
  onOpenProfile,
  isDarkMode,
  unreadAlertsCount,
}) => {
  return (
    <>
      {/* ========================================================================= */}
      {/* MOBILE BOTTOM NAVIGATION BAR (< md)                                       */}
      {/* Strictly for mobile devices with touch targets and ergonomic layout       */}
      {/* ========================================================================= */}
      <nav
        id="mobile-bottom-nav"
        className="fixed bottom-0 left-0 right-0 z-40 md:hidden bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 shadow-xl px-2 py-1.5 flex items-center justify-around pointer-events-auto"
        aria-label="Mobile Navigation"
      >
        {/* 1. Overview / Home */}
        <button
          id="mobile-nav-home"
          onClick={() => onSelectView('hero')}
          className={`flex-1 flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all cursor-pointer ${
            activeView === 'hero'
              ? 'text-cyan-600 dark:text-cyan-400 font-bold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <div className={`p-1 rounded-lg ${activeView === 'hero' ? 'bg-cyan-500/15' : ''}`}>
            <Home className="w-5 h-5 stroke-[2.2]" />
          </div>
          <span className="text-[10px] tracking-tight mt-0.5">Overview</span>
        </button>

        {/* 2. Parity Analytics */}
        <button
          id="mobile-nav-analytics"
          onClick={() => onSelectView('analytics')}
          className={`flex-1 flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all cursor-pointer ${
            activeView === 'analytics'
              ? 'text-cyan-600 dark:text-cyan-400 font-bold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <div className={`p-1 rounded-lg ${activeView === 'analytics' ? 'bg-cyan-500/15' : ''}`}>
            <TrendingUp className="w-5 h-5 stroke-[2.2]" />
          </div>
          <span className="text-[10px] tracking-tight mt-0.5">Analytics</span>
        </button>

        {/* 3. Explore & Metros Hub */}
        <button
          id="mobile-nav-hub"
          onClick={() => onSelectView('hub')}
          className={`flex-1 flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all cursor-pointer ${
            activeView === 'hub'
              ? 'text-cyan-600 dark:text-cyan-400 font-bold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <div className={`p-1 rounded-lg ${activeView === 'hub' ? 'bg-cyan-500/15' : ''}`}>
            <LayoutGrid className="w-5 h-5 stroke-[2.2]" />
          </div>
          <span className="text-[10px] tracking-tight mt-0.5">Hub</span>
        </button>

        {/* 4. Notifications with notification badge */}
        <button
          id="mobile-nav-alerts"
          onClick={onOpenAlerts}
          className="flex-1 flex flex-col items-center justify-center py-1 px-2 rounded-xl text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition-all cursor-pointer relative"
        >
          <div className="p-1 rounded-lg relative">
            <Bell className="w-5 h-5 stroke-[2.2]" />
            {unreadAlertsCount > 0 && (
              <span className="absolute top-0 right-0 w-2 h-2 rounded-full bg-rose-500 ring-2 ring-white dark:ring-slate-950 animate-pulse" />
            )}
          </div>
          <span className="text-[10px] tracking-tight mt-0.5">Notifications</span>
        </button>

        {/* 5. Menu & Preferences */}
        <button
          id="mobile-nav-menu"
          onClick={onOpenSettings}
          className="flex-1 flex flex-col items-center justify-center py-1 px-2 rounded-xl text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition-all cursor-pointer"
        >
          <div className="p-1 rounded-lg">
            <Menu className="w-5 h-5 stroke-[2.2]" />
          </div>
          <span className="text-[10px] tracking-tight mt-0.5">Menu</span>
        </button>
      </nav>

      {/* ========================================================================= */}
      {/* DESKTOP FLOATING SIDEBAR DOCK (>= md)                                     */}
      {/* Sleek vertical floating pill dock positioned on left side of desktop view */}
      {/* ========================================================================= */}
      <aside
        id="desktop-navigation-dock"
        className="hidden md:flex fixed z-40 top-1/2 left-4 -translate-y-1/2 flex-col items-center pointer-events-auto transition-all"
        aria-label="Desktop Navigation Dock"
      >
        <div className="flex flex-col items-center gap-1.5 p-2 rounded-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl text-slate-600 dark:text-slate-400">
          {/* Home icon */}
          <button
            id="sidebar-nav-home"
            onClick={() => onSelectView('hero')}
            className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-200 cursor-pointer ${
              activeView === 'hero'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/30 font-bold'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-950 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/10'
            }`}
            title="Dashboard Overview"
          >
            <Home className="w-4 h-4 stroke-[2.2]" />
          </button>

          {/* Analytics / Parity Engine (TrendingUp) */}
          <button
            id="sidebar-nav-analytics"
            onClick={() => onSelectView('analytics')}
            className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-200 cursor-pointer ${
              activeView === 'analytics'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/30 font-bold'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-950 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/10'
            }`}
            title="Financial Comparison & Parity Engine"
          >
            <TrendingUp className="w-4 h-4 stroke-[2.2]" />
          </button>

          {/* Platform Hub (Grid) */}
          <button
            id="sidebar-nav-hub"
            onClick={() => onSelectView('hub')}
            className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-200 cursor-pointer ${
              activeView === 'hub'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/30 font-bold'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-950 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/10'
            }`}
            title="Navigation & Platform Hub"
          >
            <LayoutGrid className="w-4 h-4 stroke-[2.2]" />
          </button>

          {/* Search icon (Ctrl+K) */}
          <button
            id="sidebar-nav-search"
            onClick={onOpenSearch}
            className="w-10 h-10 rounded-full flex items-center justify-center text-slate-600 dark:text-slate-400 hover:text-slate-950 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/10 transition-colors cursor-pointer"
            title="City Explorer & Command Palette (Ctrl+K)"
          >
            <Search className="w-4 h-4 stroke-[2.2]" />
          </button>

          {/* User Account (User) */}
          <button
            id="sidebar-nav-user"
            onClick={onOpenProfile || onOpenAuth}
            className="w-10 h-10 rounded-full flex items-center justify-center text-slate-600 dark:text-slate-400 hover:text-slate-950 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/10 transition-colors cursor-pointer"
            title="User Profile & Account"
          >
            <User className="w-4 h-4 stroke-[2.2]" />
          </button>

          {/* Notifications (Bell) with notification badge */}
          <button
            id="sidebar-nav-alerts"
            onClick={onOpenAlerts}
            className="relative w-10 h-10 rounded-full flex items-center justify-center text-slate-600 dark:text-slate-400 hover:text-slate-950 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/10 transition-colors cursor-pointer"
            title="Parity & FX Notifications"
          >
            <Bell className="w-4 h-4 stroke-[2.2]" />
            {unreadAlertsCount > 0 && (
              <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-rose-500 ring-2 ring-white dark:ring-slate-900 animate-pulse" />
            )}
          </button>

          {/* Divider */}
          <div className="w-5 h-px bg-slate-300 dark:bg-white/15 my-1" />

          {/* Help & Support / Lodge Complaint (LifeBuoy) */}
          {onOpenSupport && (
            <button
              id="sidebar-nav-support"
              onClick={onOpenSupport}
              className="w-10 h-10 rounded-full flex items-center justify-center text-slate-600 dark:text-slate-400 hover:text-cyan-600 dark:hover:text-cyan-400 hover:bg-slate-100 dark:hover:bg-white/10 transition-colors cursor-pointer"
              title="Help Desk, Support & Lodge a Complaint"
            >
              <LifeBuoy className="w-4 h-4 stroke-[2.2]" />
            </button>
          )}

          {/* Data Sources & Calculations */}
          {onOpenVerify && (
            <button
              id="sidebar-nav-verify"
              onClick={onOpenVerify}
              className="w-10 h-10 rounded-full flex items-center justify-center text-slate-600 dark:text-slate-400 hover:text-cyan-600 dark:hover:text-cyan-400 hover:bg-slate-100 dark:hover:bg-white/10 transition-colors cursor-pointer"
              title="Inspect Data Sources & Parity Calculations"
            >
              <ShieldCheck className="w-4 h-4 stroke-[2.2]" />
            </button>
          )}

          {/* Settings gear */}
          <button
            id="sidebar-nav-settings"
            onClick={onOpenSettings}
            className="w-10 h-10 rounded-full flex items-center justify-center text-slate-600 dark:text-slate-400 hover:text-slate-950 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/10 transition-colors cursor-pointer"
            title="Preferences & Settings"
          >
            <Settings className="w-4 h-4 stroke-[2.2]" />
          </button>

          {/* Daylight / Night mode toggle */}
          <button
            id="sidebar-nav-theme-toggle"
            onClick={onToggleTheme}
            className="w-10 h-10 rounded-full flex items-center justify-center text-slate-600 dark:text-slate-400 hover:text-slate-950 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/10 transition-colors cursor-pointer"
            title={isDarkMode ? 'Night Mode Active — Click for Daylight' : 'Daylight Mode Active — Click for Night Mode'}
            aria-label={isDarkMode ? 'Night mode active' : 'Daylight mode active'}
          >
            {isDarkMode ? (
              <Moon className="w-4 h-4 stroke-[2.2] text-cyan-400 fill-cyan-400/20" />
            ) : (
              <Sun className="w-4 h-4 stroke-[2.2] text-amber-500 fill-amber-500/20" />
            )}
          </button>
        </div>
      </aside>
    </>
  );
};
