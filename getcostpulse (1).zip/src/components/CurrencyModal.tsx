import React, { useState, useEffect } from 'react';
import { Search, X, Check, ArrowRight, RefreshCw, Zap } from 'lucide-react';
import { Currency } from '../types';
import { CURRENCIES } from '../data/mockData';

interface CurrencyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectCurrency: (curr: Currency) => void;
  selectedCurrencyCode: string;
  onOpenVerify?: () => void;
  liveLastUpdated?: string;
}

export const CurrencyModal: React.FC<CurrencyModalProps> = ({
  isOpen,
  onClose,
  onSelectCurrency,
  selectedCurrencyCode,
  onOpenVerify,
  liveLastUpdated,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<'All' | 'Popular' | 'Major FX' | 'Asia-Pacific' | 'Crypto/Pegged'>('All');
  const [pendingSelection, setPendingSelection] = useState<string>(selectedCurrencyCode);

  useEffect(() => {
    if (isOpen) {
      setPendingSelection(selectedCurrencyCode);
      setSearchQuery('');
    }
  }, [isOpen, selectedCurrencyCode]);

  if (!isOpen) return null;

  const filteredCurrencies = CURRENCIES.filter((curr) => {
    const matchesSearch =
      curr.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      curr.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      curr.symbol.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;
    if (activeCategory === 'All') return true;
    return curr.category === activeCategory;
  });

  const handleApply = () => {
    const chosen = CURRENCIES.find((c) => c.code === pendingSelection);
    if (chosen) {
      onSelectCurrency(chosen);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 dark:bg-slate-950/80">
      <div
        id="currency-selector-modal"
        className="relative w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-white/15 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[88vh] text-slate-900 dark:text-slate-100 transition-colors"
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-200 dark:border-white/10 space-y-3 bg-slate-50/95 dark:bg-slate-900/95">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-bold tracking-tight text-slate-900 dark:text-white">Select Display Currency</h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/20 text-cyan-700 dark:text-cyan-300 border border-cyan-500/30">
                LIVE FX
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-1.5 py-0.5 rounded text-[10px] font-mono text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10">
                ESC
              </span>
              <button
                onClick={onClose}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-200 dark:hover:bg-white/10 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-500 dark:text-slate-400">
              {liveLastUpdated ? `Live synced: ${liveLastUpdated}` : 'Exchange rates updated via real-time market API.'}
            </span>
            {onOpenVerify && (
              <button
                type="button"
                onClick={onOpenVerify}
                className="text-cyan-600 dark:text-cyan-400 hover:text-cyan-500 dark:hover:text-cyan-300 font-bold flex items-center gap-1 transition-colors text-[11px]"
              >
                <span>Verify Data Feed</span>
                <span className="text-[10px]">↗</span>
              </button>
            )}
          </div>

          {/* Search bar */}
          <div className="relative flex items-center">
            <Search className="absolute left-3.5 w-4 h-4 text-slate-400 pointer-events-none" />
            <input
              type="text"
              placeholder="Search currency or country (e.g. USD, Yen, Euro)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-xl bg-white dark:bg-slate-950/80 border border-slate-200 dark:border-white/12 text-xs text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all font-medium shadow-inner"
            />
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto text-xs pb-1">
            {(['All', 'Popular', 'Major FX', 'Asia-Pacific', 'Crypto/Pegged'] as const).map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                  activeCategory === cat
                    ? 'bg-cyan-500 text-slate-950 shadow-sm font-bold'
                    : 'bg-white dark:bg-white/5 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/10 border border-slate-200 dark:border-white/5'
                }`}
              >
                {cat === 'Popular' && '★ '}
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Currency Cards List */}
        <div className="p-4 overflow-y-auto space-y-4 flex-1">
          <div>
            <div className="flex items-center justify-between text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
              <span>Featured Benchmark Currencies</span>
              <span className="text-slate-400 dark:text-slate-500">London Base Anchor</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {filteredCurrencies.slice(0, 4).map((curr) => {
                const isSelected = curr.code === pendingSelection;
                return (
                  <div
                    key={curr.code}
                    onClick={() => setPendingSelection(curr.code)}
                    className={`p-3 rounded-2xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-cyan-500/10 border-cyan-500/60 shadow-md shadow-cyan-500/10'
                        : 'bg-slate-50 dark:bg-white/[0.02] border-slate-200 dark:border-white/10 hover:bg-slate-100 dark:hover:bg-white/[0.06] hover:border-slate-300 dark:hover:border-white/20'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-xl">{curr.flag}</span>
                        <div>
                          <span className="font-bold text-sm text-slate-900 dark:text-white">{curr.code}</span>
                          <span className="text-slate-500 dark:text-slate-400 text-xs ml-1">• {curr.symbol}</span>
                          <div className="text-[10px] text-slate-500 dark:text-slate-400 leading-none">{curr.name}</div>
                        </div>
                      </div>
                      {isSelected ? (
                        <div className="w-5 h-5 rounded-full bg-cyan-500 text-slate-950 flex items-center justify-center">
                          <Check className="w-3 h-3 stroke-[3]" />
                        </div>
                      ) : (
                        <span className="text-[10px] font-semibold text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white px-2 py-0.5 rounded bg-white dark:bg-white/5 border border-slate-200 dark:border-white/5">
                          Select
                        </span>
                      )}
                    </div>

                    <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-200 dark:border-white/5 font-mono">
                      <span className="text-slate-500 dark:text-slate-400 text-[11px]">
                        1 GBP = {curr.symbol}{curr.rateToGBP.toFixed(curr.code === 'INR' || curr.code === 'JPY' ? 2 : 4)}
                      </span>
                      <span
                        className={`text-[10px] font-bold ${
                          curr.change24h > 0
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : curr.change24h < 0
                            ? 'text-rose-600 dark:text-rose-400'
                            : 'text-slate-400'
                        }`}
                      >
                        {curr.change24h > 0 ? '+' : ''}
                        {curr.change24h.toFixed(2)}%
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Other Global Markets */}
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
              Other Global Markets (Mid-Market Rates)
            </div>
            <div className="space-y-1.5">
              {filteredCurrencies.slice(4).map((curr) => {
                const isSelected = curr.code === pendingSelection;
                return (
                  <div
                    key={curr.code}
                    onClick={() => setPendingSelection(curr.code)}
                    className={`flex items-center justify-between p-2.5 rounded-xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-cyan-500/15 border-cyan-500/60 text-slate-900 dark:text-white shadow-sm'
                        : 'bg-slate-50 dark:bg-white/[0.02] border-slate-200 dark:border-white/5 hover:bg-slate-100 dark:hover:bg-white/[0.05]'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="text-base">{curr.flag}</span>
                      <span className="font-bold text-xs text-slate-900 dark:text-white">{curr.code}</span>
                      <span className="text-xs text-slate-500 dark:text-slate-400">{curr.name}</span>
                    </div>
                    <div className="flex items-center gap-3 font-mono text-xs text-slate-600 dark:text-slate-300">
                      <span>
                        1 GBP = {curr.rateToGBP.toFixed(2)} {curr.code}
                      </span>
                      {isSelected ? (
                        <Check className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400 stroke-[3]" />
                      ) : (
                        <span className="text-[10px] text-slate-400">Pick</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-slate-950/80 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>Live FX Stream Active • Synced 18s ago</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3.5 py-1.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200 dark:hover:bg-white/10 transition-colors"
            >
              Cancel
            </button>
            <button
              id="apply-currency-btn"
              onClick={handleApply}
              className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-cyan-400 to-sky-500 text-slate-950 font-bold text-xs hover:from-cyan-300 hover:to-sky-400 transition-all shadow-md shadow-cyan-500/20"
            >
              Apply Currency
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
