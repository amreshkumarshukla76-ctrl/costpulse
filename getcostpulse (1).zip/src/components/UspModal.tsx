import React from 'react';
import {
  X,
  Sparkles,
  CheckCircle2,
  XCircle,
  ShieldCheck,
  Zap,
  DollarSign,
  Layers,
  ArrowRight,
} from 'lucide-react';

interface UspModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenAnalytics?: () => void;
}

export const UspModal: React.FC<UspModalProps> = ({ isOpen, onClose, onOpenAnalytics }) => {
  if (!isOpen) return null;

  const comparisonRows = [
    {
      feature: 'Net Income & Progressive Tax Modeling',
      generic: 'Shows only gross price indices (+15% rent) without tax bracket impact',
      costpulse: 'Calculates true disposable take-home salary across progressive local tax rates',
      advantage: true,
    },
    {
      feature: 'Real-Time FX Exchange Rates',
      generic: 'Uses static, quarterly or annual outdated currency approximations',
      costpulse: 'Continuously synchronized with live interbank mid-market exchange feeds',
      advantage: true,
    },
    {
      feature: 'Lifestyle & Family Customization',
      generic: 'Assumes an abstract single individual with fixed spending habits',
      costpulse: '5 dynamic scenarios (Single, Dual-Income, Families, Expats, Remote Nomads)',
      advantage: true,
    },
    {
      feature: 'Privacy & Data Sovereignty',
      generic: 'Collects emails, paywalls reports behind $49/mo, uses aggressive trackers',
      costpulse: '100% client-side privacy, zero paywalls, zero lead-capture forms, data stays local',
      advantage: true,
    },
    {
      feature: 'Relocation Purchasing Arbitrage',
      generic: 'No actionable salary recommendation for job negotiations',
      costpulse: 'Explicit target compensation recommendation with savings delta metrics',
      advantage: true,
    },
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-950/70 animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="usp-modal-title"
    >
      <div
        className="relative w-full max-w-3xl max-h-[90vh] flex flex-col rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-white/10 shadow-2xl overflow-hidden transition-all"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-slate-200 dark:border-white/10 bg-slate-50/50 dark:bg-slate-950/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-600 dark:text-cyan-400 flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 id="usp-modal-title" className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                Why GetCostPulse?
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Why professionals &amp; expats rely on GetCostPulse over generic calculators
              </p>
            </div>
          </div>
          <button
            id="close-usp-modal-btn"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/5 transition-colors"
            aria-label="Close why us modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-slate-700 dark:text-slate-300 text-xs sm:text-sm">
          {/* Transparent Proposition Introduction */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-cyan-500/5 to-blue-500/5 border border-cyan-500/15">
            <p className="text-xs text-slate-700 dark:text-slate-200 leading-relaxed">
              There are dozens of cost-of-living tools on the internet. But raw index numbers alone don’t answer the most critical question:{' '}
              <strong className="text-cyan-600 dark:text-cyan-400 font-bold">
                “Exactly what salary offer must I negotiate in another city to retain my current disposable savings and quality of life?”
              </strong>{' '}
              Here is how GetCostPulse solves this transparently.
            </p>
          </div>

          {/* 4 Pillars of Differentiation */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {/* Pillar 1 */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950/40 border border-slate-200 dark:border-white/5">
              <div className="flex items-center gap-2.5 mb-2">
                <div className="w-7 h-7 rounded-lg bg-emerald-500/10 text-emerald-500 flex items-center justify-center">
                  <DollarSign className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-slate-900 dark:text-white text-xs sm:text-sm">
                  True Take-Home Parity, Not Gross Estimates
                </h3>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Unlike sites that merely compare prices, we compute progressive tax brackets, national insurance, and after-tax disposable purchasing power.
              </p>
            </div>

            {/* Pillar 2 */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950/40 border border-slate-200 dark:border-white/5">
              <div className="flex items-center gap-2.5 mb-2">
                <div className="w-7 h-7 rounded-lg bg-blue-500/10 text-blue-500 flex items-center justify-center">
                  <Zap className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-slate-900 dark:text-white text-xs sm:text-sm">
                  Live FX Mid-Market Rates
                </h3>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Outdated quarterly currency rates cause massive errors. We synchronize with real-time foreign exchange feeds to guarantee currency parity precision.
              </p>
            </div>

            {/* Pillar 3 */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950/40 border border-slate-200 dark:border-white/5">
              <div className="flex items-center gap-2.5 mb-2">
                <div className="w-7 h-7 rounded-lg bg-purple-500/10 text-purple-500 flex items-center justify-center">
                  <Layers className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-slate-900 dark:text-white text-xs sm:text-sm">
                  Tailored Spending Profiles
                </h3>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Rent in city center vs suburbs, families vs solo expats, transit vs driving. GetCostPulse weights each basket to match your real life.
              </p>
            </div>

            {/* Pillar 4 */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950/40 border border-slate-200 dark:border-white/5">
              <div className="flex items-center gap-2.5 mb-2">
                <div className="w-7 h-7 rounded-lg bg-amber-500/10 text-amber-500 flex items-center justify-center">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-slate-900 dark:text-white text-xs sm:text-sm">
                  No Registration Paywalls
                </h3>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Full breakdowns, PDF-ready reports, and multi-currency conversions are completely accessible without paying for gated reports.
              </p>
            </div>
          </div>

          {/* Direct Comparison Matrix */}
          <div>
            <h4 className="font-bold text-slate-900 dark:text-white text-xs uppercase tracking-wider mb-3">
              Direct Comparison Matrix
            </h4>
            <div className="rounded-2xl border border-slate-200 dark:border-white/10 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-100/70 dark:bg-slate-950/60 border-b border-slate-200 dark:border-white/10">
                      <th className="py-2.5 px-3.5 font-semibold text-slate-600 dark:text-slate-300 w-1/3">
                        Capability
                      </th>
                      <th className="py-2.5 px-3.5 font-semibold text-rose-600 dark:text-rose-400 w-1/3">
                        Generic Calculators
                      </th>
                      <th className="py-2.5 px-3.5 font-semibold text-emerald-600 dark:text-emerald-400 w-1/3 bg-emerald-500/5">
                        GetCostPulse
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 dark:divide-white/5">
                    {comparisonRows.map((row, idx) => (
                      <tr
                        key={idx}
                        className="hover:bg-slate-50/50 dark:hover:bg-white/[0.02] transition-colors"
                      >
                        <td className="py-2.5 px-3.5 font-medium text-slate-900 dark:text-slate-200">
                          {row.feature}
                        </td>
                        <td className="py-2.5 px-3.5 text-slate-500 dark:text-slate-400 flex items-start gap-1.5">
                          <XCircle className="w-3.5 h-3.5 text-rose-500 shrink-0 mt-0.5" />
                          <span>{row.generic}</span>
                        </td>
                        <td className="py-2.5 px-3.5 text-slate-800 dark:text-slate-200 bg-emerald-500/5 font-medium">
                          <div className="flex items-start gap-1.5">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
                            <span>{row.costpulse}</span>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-200 dark:border-white/10 bg-slate-50/50 dark:bg-slate-950/40">
          <span className="text-[11px] text-slate-500 dark:text-slate-400">
            Transparent methodology • Zero hidden fees
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-200/60 dark:hover:bg-white/10 transition-colors"
            >
              Close
            </button>
            {onOpenAnalytics && (
              <button
                onClick={() => {
                  onClose();
                  onOpenAnalytics();
                }}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-cyan-500 hover:bg-cyan-600 text-white shadow-md shadow-cyan-500/20 flex items-center gap-1.5 transition-all"
              >
                <span>View Full Analytics</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
