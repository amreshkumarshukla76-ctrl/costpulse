import React, { useEffect, useRef } from 'react';

interface AdSenseSlotProps {
  slot?: string;
  format?: 'auto' | 'horizontal' | 'rectangle';
  responsive?: boolean;
  className?: string;
}

export const AdSenseSlot: React.FC<AdSenseSlotProps> = ({
  slot,
  format = 'auto',
  responsive = true,
  className = '',
}) => {
  const adRef = useRef<HTMLModElement | null>(null);
  const clientId = (import.meta.env.VITE_ADSENSE_CLIENT_ID as string) || 'ca-pub-9983854730849691';

  useEffect(() => {
    if (clientId && clientId.startsWith('ca-pub-')) {
      try {
        const win = window as unknown as { adsbygoogle?: unknown[] };
        win.adsbygoogle = win.adsbygoogle || [];
        win.adsbygoogle.push({});
      } catch (err) {
        console.debug('AdSense push handled:', err);
      }
    }
  }, [clientId, slot]);

  return (
    <div
      className={`w-full flex flex-col items-center justify-center my-6 overflow-hidden ${className}`}
      aria-label="Advertisement"
    >
      <div className="w-full max-w-4xl rounded-2xl border border-dashed border-slate-200 dark:border-white/10 bg-slate-50/50 dark:bg-slate-900/30 p-3 flex flex-col items-center text-center">
        {/* Google AdSense Compliant Label */}
        <span className="text-[10px] tracking-wider uppercase font-semibold text-slate-400 dark:text-slate-500 mb-1">
          Advertisement
        </span>

        {clientId && clientId.startsWith('ca-pub-') ? (
          <ins
            ref={adRef}
            className="adsbygoogle block w-full min-h-[90px]"
            style={{ display: 'block' }}
            data-ad-client={clientId}
            data-ad-slot={slot || '1234567890'}
            data-ad-format={format}
            data-full-width-responsive={responsive ? 'true' : 'false'}
          />
        ) : (
          <div className="py-4 px-6 w-full flex flex-col items-center justify-center text-slate-400 dark:text-slate-500 text-xs">
            <p className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
              Google AdSense Display Space
            </p>
            <p className="text-[10px] text-slate-400 dark:text-slate-600 mt-0.5 max-w-md">
              Configured for responsive display. Live ads will serve once your publisher ID (<code className="font-mono text-[10px]">ca-pub-XXXX</code>) is connected.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
