import React, { useMemo } from 'react';
import {
  Share2,
  FileDown,
  Building2,
  ShoppingCart,
  Train,
  ShieldCheck,
  UtensilsCrossed,
  Info,
  ArrowRight,
  TrendingUp,
  Percent,
  Sliders,
  RotateCcw,
} from 'lucide-react';
import { City, Currency, UserScenario } from '../types';
import { calculateParity, formatCurrencyNumber } from '../utils/parityCalc';
import { AdContainer } from './AdContainer';

interface AnalyticsViewProps {
  originCity: City;
  destCity: City;
  scenario: UserScenario;
  currencies: Currency[];
  onUpdateScenario: (scenario: Partial<UserScenario>) => void;
  onNavigate: (view: 'hero' | 'analytics' | 'hub') => void;
  onShowToast?: (message: string, type?: 'success' | 'info' | 'warning') => void;
  onOpenVerify?: () => void;
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({
  originCity,
  destCity,
  scenario,
  currencies,
  onUpdateScenario,
  onNavigate,
  onShowToast,
  onOpenVerify,
}) => {
  const {
    ratio,
    costDiffPercent,
    targetRequiredDest,
    targetRequiredUSD,
    targetRequiredDestAnnual,
    targetRequiredDestMonthly,
    baseSalaryAnnual,
    baseSalaryMonthly,
    originNetMonthly,
    destNetMonthly,
    originSurplus,
    destSurplus,
    hasOriginAdvantage,
    surplusDeltaOrigin,
    surplusDeltaDest,
    originTaxRate,
    destTaxRate,
    originCompositeIndex,
    destCompositeIndex,
    rentWeight,
    baskets,
  } = useMemo(
    () => calculateParity(originCity, destCity, scenario, currencies),
    [originCity, destCity, scenario, currencies]
  );

  const destCurrency = currencies.find((c) => c.code === destCity.currency) || currencies[1];
  const isAnnual = scenario.isAnnual;
  const periodLabel = isAnnual ? '/yr' : '/mo';

  const handleTogglePeriod = (annual: boolean) => {
    if (annual === scenario.isAnnual) return;
    if (annual) {
      onUpdateScenario({ isAnnual: true, baseSalary: Math.round(scenario.baseSalary * 12) });
    } else {
      onUpdateScenario({ isAnnual: false, baseSalary: Math.round(scenario.baseSalary / 12) });
    }
  };

  const handleShare = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      onShowToast?.('Parity scenario link copied to clipboard!', 'success');
    } catch {
      onShowToast?.('Parity scenario ready to share.', 'info');
    }
  };

  const handleExportPDF = () => {
    onShowToast?.('Generating Parity Telemetry report for print / PDF...', 'info');
    setTimeout(() => {
      window.print();
    }, 400);
  };

  const resetScenario = () => {
    const isINR = originCity.currency === 'INR';
    const defaultSalary = isAnnual ? (isINR ? 1020000 : 85000) : (isINR ? 85000 : 7000);
    onUpdateScenario({
      household: 'single',
      lifestyle: 'balanced',
      residence: 'prime',
      baseSalary: defaultSalary,
    });
    onShowToast?.('Scenario parameters reset to baseline defaults.', 'info');
  };

  const isINR = originCity.currency === 'INR';
  const sliderConfig = isAnnual
    ? isINR
      ? { min: 300000, max: 6000000, step: 50000, presets: [{ label: '10 LPA', val: 1000000 }, { label: '15 LPA', val: 1500000 }, { label: '25 LPA', val: 2500000 }, { label: '40 LPA', val: 4000000 }] }
      : { min: 30000, max: 350000, step: 5000, presets: [{ label: '55k', val: 55000 }, { label: '85k Anchor', val: 85000 }, { label: '140k', val: 140000 }, { label: '220k', val: 220000 }] }
    : isINR
    ? { min: 20000, max: 500000, step: 5000, presets: [{ label: '₹50k', val: 50000 }, { label: '₹85k/mo', val: 85000 }, { label: '₹1.5L', val: 150000 }, { label: '₹2.5L', val: 250000 }] }
    : { min: 2000, max: 30000, step: 500, presets: [{ label: '4.5k', val: 4500 }, { label: '7k Anchor', val: 7000 }, { label: '11.5k', val: 11500 }, { label: '18k', val: 18000 }] };

  return (
    <div className="min-h-screen w-full pt-20 md:pt-24 pb-32 md:pb-20 px-4 md:px-10 max-w-7xl mx-auto text-slate-900 dark:text-slate-100 transition-colors">
      {/* Top Breadcrumb & Controls */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2 text-[11px] font-mono tracking-wider uppercase text-cyan-600 dark:text-cyan-400 mb-1">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-pulse" />
            <span>Analytics &amp; Models</span>
            <span className="text-slate-400 dark:text-white/20">/</span>
            <span className="text-slate-500 dark:text-slate-400">Cross-Metro Parity Calculator</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Financial Comparison &amp; Parity Engine
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 max-w-3xl mt-1">
            Compare gross-to-net disposable capital, localized living overheads, and real purchasing equivalence between{' '}
            <span className="text-slate-900 dark:text-white font-semibold">{originCity.name}</span> (Anchor Metro) and{' '}
            <span className="text-slate-900 dark:text-white font-semibold">{destCity.name}</span> (Destination Metro).
          </p>
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-2.5 self-start lg:self-center">
          <div className="flex items-center p-1 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-white/10 text-xs font-semibold shadow-sm">
            <button
              onClick={() => handleTogglePeriod(true)}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                scenario.isAnnual ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Annual
            </button>
            <button
              onClick={() => handleTogglePeriod(false)}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                !scenario.isAnnual ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Monthly
            </button>
          </div>

          {onOpenVerify && (
            <button
              onClick={onOpenVerify}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-cyan-500/10 border border-cyan-500/30 hover:bg-cyan-500/20 text-xs font-semibold text-cyan-700 dark:text-cyan-400 transition-all"
              title="Inspect Open Data Sources & Calculation Breakdown"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-pulse" />
              <span>Data Sources &amp; Math</span>
            </button>
          )}

          <button
            onClick={handleShare}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white dark:bg-slate-900/80 border border-slate-200 dark:border-white/12 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 transition-all shadow-sm"
          >
            <Share2 className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400" />
            <span>Share Model</span>
          </button>

          <button
            onClick={handleExportPDF}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold transition-all shadow-md shadow-cyan-500/20"
          >
            <FileDown className="w-3.5 h-3.5" />
            <span>Export PDF Report</span>
          </button>
        </div>
      </div>

      {/* Top 3 KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-5 mb-8">
        {/* Card 1: Equivalent Target Salary */}
        <div className="p-5 md:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Equivalent Target Salary
              </span>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                costDiffPercent > 0
                  ? 'bg-amber-500/20 text-amber-700 dark:text-amber-300 border border-amber-500/30'
                  : 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30'
              }`}>
                {costDiffPercent > 0 ? `+${costDiffPercent.toFixed(1)}%` : `${costDiffPercent.toFixed(1)}%`} Living Cost Gap
              </span>
            </div>
            <div className="text-xs text-slate-500 dark:text-slate-400 mb-1">
              {originCity.name} Anchor: <span className="font-semibold text-slate-800 dark:text-slate-200">{originCity.currencySymbol}{scenario.baseSalary.toLocaleString()}{periodLabel}</span>
            </div>
            <div className="text-3xl md:text-4xl font-black text-slate-900 dark:text-white font-mono tracking-tight">
              {destCurrency.symbol}{Math.round(targetRequiredDest).toLocaleString()}
              <span className="text-sm font-normal text-slate-500 dark:text-slate-400 font-sans ml-1">{periodLabel}</span>
            </div>
            <div className="text-xs font-mono text-cyan-600 dark:text-cyan-400 mt-1 font-semibold">
              {isAnnual
                ? `≈ ${destCurrency.symbol}${Math.round(targetRequiredDestMonthly).toLocaleString()}/mo (vs ${originCity.currencySymbol}${Math.round(baseSalaryMonthly).toLocaleString()}/mo)`
                : `≈ ${destCurrency.symbol}${Math.round(targetRequiredDestAnnual).toLocaleString()}/yr (vs ${originCity.currencySymbol}${Math.round(baseSalaryAnnual).toLocaleString()}/yr)`
              }
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mt-2">
              Equivalent purchasing capacity in {destCity.name} factoring in residential leases ({Math.round(rentWeight * 100)}% weight) and core living baskets.
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-200 dark:border-white/10 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-mono">
            <span>Index Parity Ratio</span>
            <span className="text-cyan-600 dark:text-cyan-400 font-bold">{ratio.toFixed(3)}x Composite (Rent &amp; CPI)</span>
          </div>
        </div>

        {/* Card 2: Net Monthly Surplus */}
        <div className="p-5 md:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Net Monthly Surplus
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/20 text-cyan-700 dark:text-cyan-300 border border-cyan-500/30">
                {hasOriginAdvantage ? `+${originCity.name} Advantage` : `+${destCity.name} Advantage`}
              </span>
            </div>
            <div className="text-xs text-slate-500 dark:text-slate-400 mb-2">After Rent, Tax &amp; Core FMCG Outlays</div>
            <div className="grid grid-cols-2 gap-2 pt-1 pb-2">
              <div>
                <div className="text-[10px] uppercase font-bold text-slate-500 dark:text-slate-400">{originCity.name} Retained</div>
                <div className="text-xl md:text-2xl font-black text-cyan-600 dark:text-cyan-400 font-mono">
                  {originCity.currencySymbol}{Math.round(originSurplus).toLocaleString()}
                  <span className="text-[10px] font-normal text-slate-500 dark:text-slate-400 font-sans">/mo</span>
                </div>
              </div>
              <div>
                <div className="text-[10px] uppercase font-bold text-slate-500 dark:text-slate-400">{destCity.name} Retained</div>
                <div className="text-xl md:text-2xl font-black text-slate-800 dark:text-slate-200 font-mono">
                  {destCurrency.symbol}{Math.round(destSurplus).toLocaleString()}
                  <span className="text-[10px] font-normal text-slate-500 dark:text-slate-400 font-sans">/mo</span>
                </div>
              </div>
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-200 dark:border-white/10 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-mono">
            <span>Monthly Surplus Delta</span>
            <span className="text-emerald-600 dark:text-emerald-400 font-bold">
              {hasOriginAdvantage
                ? `+${originCity.currencySymbol}${surplusDeltaOrigin.toLocaleString()}/mo in ${originCity.name}`
                : `+${destCurrency.symbol}${surplusDeltaDest.toLocaleString()}/mo in ${destCity.name}`
              }
            </span>
          </div>
        </div>

        {/* Card 3: Effective Deductions & Tax */}
        <div className="p-5 md:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Effective Deductions &amp; Tax
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-700 dark:text-rose-300 border border-rose-500/30">
                +{((destTaxRate - originTaxRate) * 100).toFixed(1)}% {destCity.name} Drag
              </span>
            </div>
            <div className="text-xs text-slate-500 dark:text-slate-400 mb-2">
              {originCity.country} PAYE vs {destCity.country} Federal + Local
            </div>

            <div className="flex items-center justify-between text-xs mb-1 font-mono">
              <span className="text-slate-600 dark:text-slate-300">{originCity.name} Net Effective:</span>
              <span className="font-bold text-slate-900 dark:text-white">{(originTaxRate * 100).toFixed(1)}%</span>
            </div>
            <div className="w-full bg-slate-200 dark:bg-slate-800 rounded-full h-2 overflow-hidden mb-2">
              <div
                className="bg-cyan-500 h-full rounded-full"
                style={{ width: `${originTaxRate * 100}%` }}
              />
            </div>

            <div className="flex items-center justify-between text-xs mb-1 font-mono">
              <span className="text-slate-600 dark:text-slate-300">{destCity.name} Total Effective:</span>
              <span className="font-bold text-amber-600 dark:text-amber-400">{(destTaxRate * 100).toFixed(1)}%</span>
            </div>
            <div className="w-full bg-slate-200 dark:bg-slate-800 rounded-full h-2 overflow-hidden">
              <div
                className="bg-amber-500 h-full rounded-full"
                style={{ width: `${destTaxRate * 100}%` }}
              />
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-200 dark:border-white/10 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Direct Fiscal Differential</span>
            <span className="text-rose-600 dark:text-rose-400 font-semibold">
              ${Math.round(targetRequiredUSD * (destTaxRate - originTaxRate)).toLocaleString()} extra tax/yr
            </span>
          </div>
        </div>
      </div>

      {/* Main Analysis Columns: Left Parity Baskets + Right Scenario Adjusters */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start mb-8">
        {/* Left Baskets (7 Cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-lg">
            <div className="flex items-center justify-between mb-2">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white tracking-tight">Basket-Level Parity Breakdown</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Normalized monthly localized expenditure across median corporate cohorts.
                </p>
              </div>
              <div className="flex items-center gap-3 text-xs">
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-cyan-500" />
                  <span className="text-slate-700 dark:text-slate-300 font-medium">{originCity.name}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-slate-400" />
                  <span className="text-slate-700 dark:text-slate-300 font-medium">{destCity.name}</span>
                </div>
              </div>
            </div>

            <div className="space-y-3 mt-5">
              {baskets.map((b) => {
                const isCheaperInOrigin = b.diffPercent < 0;
                return (
                  <div
                    key={b.id}
                    className="p-4 rounded-2xl bg-slate-50 dark:bg-white/[0.02] border border-slate-200 dark:border-white/5 hover:border-cyan-500/30 transition-all"
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-white/10 flex items-center justify-center text-cyan-600 dark:text-cyan-400">
                          {b.id === 'housing' && <Building2 className="w-4 h-4" />}
                          {b.id === 'groceries' && <ShoppingCart className="w-4 h-4" />}
                          {b.id === 'transit' && <Train className="w-4 h-4" />}
                          {b.id === 'healthcare' && <ShieldCheck className="w-4 h-4" />}
                          {b.id === 'dining' && <UtensilsCrossed className="w-4 h-4" />}
                        </div>
                        <div>
                          <div className="text-sm font-bold text-slate-900 dark:text-white">{b.title}</div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400">{b.subtext}</div>
                        </div>
                      </div>

                      <span
                        className={`text-xs font-bold font-mono px-2.5 py-1 rounded-full ${
                          b.diffPercent > 0
                            ? 'bg-amber-500/15 text-amber-700 dark:text-amber-300 border border-amber-500/25'
                            : 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border border-emerald-500/25'
                        }`}
                      >
                        {destCity.name} {b.diffPercent > 0 ? '+' : ''}
                        {b.diffPercent.toFixed(1)}% vs {originCity.name}
                      </span>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-slate-200 dark:border-white/5 text-xs font-mono">
                      <div>
                        <span className="text-slate-500">{originCity.name} Monthly: </span>
                        <span className="text-slate-900 dark:text-white font-bold">
                          {originCity.currencySymbol}{b.originMonthly.toLocaleString()}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500">{destCity.name} Monthly: </span>
                        <span className="text-slate-800 dark:text-slate-200 font-bold">
                          {destCurrency.symbol}{b.destMonthly.toLocaleString()}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="mt-5 p-3.5 rounded-2xl bg-cyan-50 dark:bg-cyan-950/20 border border-cyan-200 dark:border-cyan-500/20 flex items-start gap-3 text-xs text-slate-700 dark:text-slate-300">
              <Info className="w-4 h-4 text-cyan-600 dark:text-cyan-400 shrink-0 mt-0.5" />
              <span>
                Calculated on Hedonic Quality Adjustments: {destCity.name}&apos;s higher nominal salaries are absorbed by elevated mandatory private healthcare and real estate premiums.
              </span>
            </div>
          </div>
        </div>

        {/* Right Adjusters & NYC Capital Allocation Donut (5 Cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Scenario Adjusters */}
          <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-lg space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white tracking-tight">Scenario Adjusters</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">Dynamically recalibrate target comp parity.</p>
              </div>
              <button
                onClick={resetScenario}
                className="flex items-center gap-1 text-xs text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors"
                title="Reset scenario defaults"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>RESET</span>
              </button>
            </div>

            {/* Household Profile */}
            <div>
              <label className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 block mb-2">
                Household Profile
              </label>
              <div className="grid grid-cols-2 gap-2 text-xs">
                {(
                  [
                    { id: 'single', label: 'Single Individual' },
                    { id: 'dual', label: 'Partner / Dual' },
                    { id: 'family-1', label: 'Family (1 Child)' },
                    { id: 'family-2plus', label: 'Family (2+ Children)' },
                  ] as const
                ).map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => onUpdateScenario({ household: opt.id })}
                    className={`py-2 px-2.5 rounded-xl text-xs font-semibold text-center transition-all ${
                      scenario.household === opt.id
                        ? 'bg-cyan-500 text-slate-950 shadow-sm font-bold'
                        : 'bg-slate-100 dark:bg-white/5 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-white/10 border border-slate-200 dark:border-white/5'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Lifestyle & Consumption Tier */}
            <div>
              <label className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 block mb-2">
                Lifestyle &amp; Consumption Tier
              </label>
              <div className="grid grid-cols-3 gap-2 text-xs">
                {(
                  [
                    { id: 'frugal', label: 'Frugal' },
                    { id: 'balanced', label: 'Balanced Tech' },
                    { id: 'executive', label: 'Executive' },
                  ] as const
                ).map((tier) => (
                  <button
                    key={tier.id}
                    onClick={() => onUpdateScenario({ lifestyle: tier.id })}
                    className={`py-2 px-2 rounded-xl text-xs font-semibold text-center transition-all ${
                      scenario.lifestyle === tier.id
                        ? 'bg-cyan-500 text-slate-950 shadow-sm font-bold'
                        : 'bg-slate-100 dark:bg-white/5 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-white/10 border border-slate-200 dark:border-white/5'
                    }`}
                  >
                    {tier.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Residential Selection */}
            <div>
              <label className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 block mb-2">
                Residential Selection
              </label>
              <div className="space-y-1.5 text-xs">
                {(
                  [
                    { id: 'prime', label: 'Prime Center (1-Bed Flat)', badge: 'Index Base' },
                    { id: 'outer', label: 'Outer Borough / Suburban (3-Bed)', badge: '+14% Parity Gap' },
                    { id: 'luxury', label: 'High-End Luxury Penthouse', badge: '+42% Parity Gap' },
                  ] as const
                ).map((res) => (
                  <button
                    key={res.id}
                    onClick={() => onUpdateScenario({ residence: res.id })}
                    className={`w-full flex items-center justify-between p-2.5 rounded-xl border transition-all ${
                      scenario.residence === res.id
                        ? 'bg-cyan-500/15 border-cyan-500 text-slate-900 dark:text-white font-bold'
                        : 'bg-slate-50 dark:bg-white/[0.02] border-slate-200 dark:border-white/5 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className={`w-2 h-2 rounded-full ${scenario.residence === res.id ? 'bg-cyan-500' : 'bg-slate-400 dark:bg-slate-600'}`} />
                      <span className="font-medium">{res.label}</span>
                    </div>
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">{res.badge}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Base Compensation Slider */}
            <div>
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  {originCity.name} Base Compensation
                </span>
                <span className="text-slate-900 dark:text-white font-bold font-mono text-sm">
                  {originCity.currencySymbol}{scenario.baseSalary.toLocaleString()} {periodLabel}
                </span>
              </div>
              <input
                type="range"
                min={sliderConfig.min}
                max={sliderConfig.max}
                step={sliderConfig.step}
                value={Math.min(Math.max(scenario.baseSalary, sliderConfig.min), sliderConfig.max)}
                onChange={(e) => onUpdateScenario({ baseSalary: Number(e.target.value) })}
                className="w-full accent-cyan-500 cursor-pointer"
              />
              <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono mt-1 mb-2">
                <span>{originCity.currencySymbol}{sliderConfig.min.toLocaleString()}</span>
                <span>{originCity.currencySymbol}{Math.round((sliderConfig.min + sliderConfig.max) / 2).toLocaleString()}</span>
                <span>{originCity.currencySymbol}{sliderConfig.max.toLocaleString()}</span>
              </div>
              {/* Presets */}
              <div className="grid grid-cols-4 gap-1.5 pt-1">
                {sliderConfig.presets.map((preset) => (
                  <button
                    key={preset.label}
                    onClick={() => onUpdateScenario({ baseSalary: preset.val })}
                    className={`py-1 px-1.5 rounded-lg text-[10px] font-mono font-medium border transition-colors text-center ${
                      scenario.baseSalary === preset.val
                        ? 'bg-cyan-500 text-slate-950 border-cyan-400 font-bold'
                        : 'bg-slate-100 dark:bg-white/5 border-slate-200 dark:border-white/5 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-white/10'
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Capital Allocation Donut Card (matches Screenshot 13) */}
          <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h4 className="text-base font-bold text-slate-900 dark:text-white">{destCity.name} Capital Allocation</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Projected burn of {destCurrency.symbol}{Math.round(targetRequiredDest).toLocaleString()} required salary.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-around gap-4">
              {/* Circular SVG Donut */}
              <div className="relative w-32 h-32 flex items-center justify-center">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                  {/* Background Circle */}
                  <circle cx="18" cy="18" r="14" fill="none" stroke="#e2e8f0" className="dark:stroke-slate-800" strokeWidth="4.5" />
                  {/* Rent: 42% (cyan) */}
                  <circle
                    cx="18"
                    cy="18"
                    r="14"
                    fill="none"
                    stroke="#06b6d4"
                    strokeWidth="4.5"
                    strokeDasharray="37 63"
                    strokeDashoffset="0"
                  />
                  {/* Taxes: 32% (blue) */}
                  <circle
                    cx="18"
                    cy="18"
                    r="14"
                    fill="none"
                    stroke="#3b82f6"
                    strokeWidth="4.5"
                    strokeDasharray="28 72"
                    strokeDashoffset="-37"
                  />
                  {/* Daily: 18% (amber) */}
                  <circle
                    cx="18"
                    cy="18"
                    r="14"
                    fill="none"
                    stroke="#f59e0b"
                    strokeWidth="4.5"
                    strokeDasharray="18 82"
                    strokeDashoffset="-65"
                  />
                  {/* Savings: 8% (emerald) */}
                  <circle
                    cx="18"
                    cy="18"
                    r="14"
                    fill="none"
                    stroke="#10b981"
                    strokeWidth="4.5"
                    strokeDasharray="7 93"
                    strokeDashoffset="-83"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                  <span className="text-sm font-black text-slate-900 dark:text-white font-mono">100%</span>
                  <span className="text-[9px] uppercase font-bold text-slate-500 dark:text-slate-400">Gross</span>
                </div>
              </div>

              {/* Donut Legend */}
              <div className="space-y-2 text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-cyan-500" />
                  <span className="text-slate-700 dark:text-slate-300">Rent &amp; Shelter</span>
                  <span className="font-bold text-slate-900 dark:text-white font-mono ml-auto">42%</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-500" />
                  <span className="text-slate-700 dark:text-slate-300">Taxes &amp; Deductions</span>
                  <span className="font-bold text-slate-900 dark:text-white font-mono ml-auto">32%</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                  <span className="text-slate-700 dark:text-slate-300">Daily Living</span>
                  <span className="font-bold text-slate-900 dark:text-white font-mono ml-auto">18%</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  <span className="text-slate-700 dark:text-slate-300">Retained Savings</span>
                  <span className="font-bold text-slate-900 dark:text-white font-mono ml-auto">8%</span>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-200 dark:border-white/10 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
              <span className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                <span>1.284 GBP / USD Feed</span>
              </span>
              <span>Syndicated 12m ago</span>
            </div>
          </div>
        </div>
      </div>

      {/* Google AdSense Responsive Display Inventory Container */}
      <AdContainer adSlot="8492019384" className="my-6" />

      {/* Bottom Card: Global Real Estate Purchasing Index (matches Screenshot 13) */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-lg flex flex-col md:flex-row items-center gap-6">
        <div className="relative w-full md:w-64 h-36 rounded-2xl overflow-hidden shrink-0 border border-slate-200 dark:border-white/10">
          <img
            src="https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=800&q=80"
            alt="Asset Yield"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent flex items-end p-3">
            <span className="text-xs font-bold text-white">Asset Yield Equivalence</span>
          </div>
        </div>

        <div className="space-y-1.5">
          <div className="text-[11px] font-bold uppercase tracking-wider text-cyan-600 dark:text-cyan-400">
            Capital Efficiency Index
          </div>
          <h4 className="text-xl font-bold text-slate-900 dark:text-white">Global Real Estate Purchasing Index</h4>
          <p className="text-xs md:text-sm text-slate-600 dark:text-slate-300 leading-relaxed max-w-3xl">
            Retained savings from {originCity.name} allow 1.4x earlier principal accumulation on secondary Mediterranean vacation assets compared to metropolitan {destCity.name} baseline savings rate.
          </p>
          <button
            onClick={() => onShowToast?.('Opening cross-metro real estate parity and capital yield analysis.', 'info')}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-cyan-600 dark:text-cyan-400 hover:text-cyan-500 pt-1"
          >
            <span>View full property yield analysis</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
