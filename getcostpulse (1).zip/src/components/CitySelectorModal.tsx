import React, { useState } from 'react';
import { Search, X, Check, ArrowRight } from 'lucide-react';
import { City } from '../types';
import { CITIES } from '../data/mockData';

interface CitySelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectCity: (city: City) => void;
  selectedCityId: string;
  title: string;
  onShowToast?: (msg: string, type?: 'success' | 'info' | 'warning') => void;
}

export const CitySelectorModal: React.FC<CitySelectorModalProps> = ({
  isOpen,
  onClose,
  onSelectCity,
  selectedCityId,
  title,
  onShowToast,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'All' | 'Popular' | 'Europe' | 'North America' | 'Asia-Pac'>('All');

  if (!isOpen) return null;

  const filteredCities = CITIES.filter((city) => {
    const matchesSearch =
      city.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      city.country.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (activeFilter === 'Popular') return city.popular;
    if (activeFilter === 'Europe') return city.region === 'Europe';
    if (activeFilter === 'North America') return city.region === 'North America';
    if (activeFilter === 'Asia-Pac') return city.region === 'Asia-Pac';
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 dark:bg-slate-950/75">
      <div
        id="city-selector-modal"
        className="relative w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-white/15 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] text-slate-900 dark:text-slate-100 transition-colors"
      >
        {/* Header with Search & Filter */}
        <div className="p-4 border-b border-slate-200 dark:border-white/10 space-y-3 bg-slate-50/90 dark:bg-slate-900/90">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-cyan-600 dark:text-cyan-400">
              {title}
            </span>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-200 dark:hover:bg-white/10 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Search bar with ESC badge */}
          <div className="relative flex items-center">
            <Search className="absolute left-3.5 w-4 h-4 text-slate-400 pointer-events-none" />
            <input
              id="city-search-input"
              type="text"
              autoFocus
              placeholder="Search global metro or country..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-12 py-2.5 rounded-xl bg-white dark:bg-slate-950/80 border border-slate-200 dark:border-white/12 text-sm text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all font-medium shadow-inner"
            />
            <span className="absolute right-3 px-1.5 py-0.5 rounded text-[10px] font-mono text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10">
              ESC
            </span>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
            {(['All', 'Popular', 'Europe', 'North America', 'Asia-Pac'] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => setActiveFilter(filter)}
                className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                  activeFilter === filter
                    ? 'bg-cyan-500 text-slate-950 shadow-sm font-bold'
                    : 'bg-white dark:bg-white/5 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/10 border border-slate-200 dark:border-white/5'
                }`}
              >
                {filter === 'Popular' && '★ '}
                {filter === 'Europe' && '🇪🇺 '}
                {filter === 'North America' && '🇺🇸 '}
                {filter === 'Asia-Pac' && '🌏 '}
                {filter}
              </button>
            ))}
          </div>
        </div>

        {/* Global Metros List */}
        <div className="p-3 overflow-y-auto space-y-1.5 flex-1">
          <div className="flex items-center justify-between px-2 py-1 text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            <span>Global Metros (Indexed)</span>
            <span>160+ Live Cities</span>
          </div>

          {filteredCities.map((city) => {
            const isSelected = city.id === selectedCityId;
            return (
              <div
                key={city.id}
                onClick={() => {
                  onSelectCity(city);
                  onClose();
                }}
                className={`flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer group ${
                  isSelected
                    ? 'bg-cyan-500/10 border-cyan-500/40 text-slate-900 dark:text-white shadow-sm'
                    : 'bg-slate-50 dark:bg-white/[0.02] border-slate-200 dark:border-white/5 hover:bg-slate-100 dark:hover:bg-white/[0.08] hover:border-slate-300 dark:hover:border-white/15'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-white/10 flex items-center justify-center text-lg shadow-sm">
                    {city.flag}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-slate-900 dark:text-slate-100 group-hover:text-cyan-600 dark:group-hover:text-cyan-300">
                        {city.name}, {city.country}
                      </span>
                      {isSelected && (
                        <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-cyan-500/20 text-cyan-700 dark:text-cyan-300 border border-cyan-500/30">
                          Active
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2 mt-0.5">
                      <span>{city.surplusNote || `Cost Index: ${city.costIndex}`}</span>
                      <span>•</span>
                      <span className="text-slate-400 dark:text-slate-500">Median: {city.medianTechSalaryLocal}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {isSelected ? (
                    <span className="flex items-center gap-1 text-xs font-bold text-cyan-600 dark:text-cyan-400">
                      <Check className="w-3.5 h-3.5" />
                      <span>Active</span>
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-xs font-medium text-slate-500 dark:text-slate-400 group-hover:text-slate-900 dark:group-hover:text-white px-2.5 py-1 rounded-lg bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 shadow-sm">
                      <span>Select</span>
                      <span className="font-mono text-[10px]">↵</span>
                    </span>
                  )}
                </div>
              </div>
            );
          })}

          {filteredCities.length === 0 && (
            <div className="py-12 text-center text-slate-500 dark:text-slate-400 text-sm">
              No matching metros found for &quot;{searchQuery}&quot;.
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-3 border-t border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-slate-950/60 flex items-center justify-between text-xs text-slate-600 dark:text-slate-400">
          <span>Can&apos;t locate your city?</span>
          <button
            onClick={() => onShowToast?.('Parity data request logged for custom metro. Priority queue updated.', 'info')}
            className="text-cyan-600 dark:text-cyan-400 hover:text-cyan-500 dark:hover:text-cyan-300 font-semibold inline-flex items-center gap-1"
          >
            <span>Request index data</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>
      </div>
    </div>
  );
};
