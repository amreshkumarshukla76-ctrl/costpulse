import React, { useState, useEffect } from 'react';
import {
  X,
  ShieldCheck,
  FileText,
  AlertTriangle,
  Database,
  Lock,
} from 'lucide-react';

interface DisclaimerPrivacyModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'disclaimer' | 'terms' | 'privacy';
}

export const DisclaimerPrivacyModal: React.FC<DisclaimerPrivacyModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'disclaimer',
}) => {
  const [activeTab, setActiveTab] = useState<'disclaimer' | 'terms' | 'privacy'>(initialTab);

  // Sync tab if modal opens with different initialTab
  useEffect(() => {
    if (isOpen && initialTab) {
      setActiveTab(initialTab);
    }
  }, [isOpen, initialTab]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 animate-fadeIn">
      <div
        id="disclaimer-modal"
        className="relative w-full max-w-3xl max-h-[90vh] bg-white dark:bg-slate-900 border border-slate-200 dark:border-white/15 rounded-3xl shadow-2xl overflow-hidden flex flex-col text-slate-900 dark:text-slate-100 transition-colors"
      >
        {/* Header */}
        <div className="p-6 border-b border-slate-200 dark:border-white/10 flex items-center justify-between bg-slate-50/50 dark:bg-slate-950/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-600 dark:text-cyan-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                Legal, Terms &amp; Privacy
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Purchasing power parity guidelines, usage terms, and client-first privacy commitments
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-800 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/10 transition-colors cursor-pointer"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 dark:border-white/10 bg-slate-50/80 dark:bg-slate-950/60 px-6 gap-2 text-xs font-semibold overflow-x-auto">
          <button
            onClick={() => setActiveTab('disclaimer')}
            className={`py-3 px-3 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'disclaimer'
                ? 'border-cyan-500 text-cyan-600 dark:border-cyan-400 dark:text-cyan-400'
                : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
            <span>1. Disclaimer</span>
          </button>

          <button
            onClick={() => setActiveTab('privacy')}
            className={`py-3 px-3 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'privacy'
                ? 'border-emerald-500 text-emerald-600 dark:border-emerald-400 dark:text-emerald-400'
                : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <Lock className="w-3.5 h-3.5 text-emerald-500" />
            <span>2. Privacy Policy</span>
          </button>

          <button
            onClick={() => setActiveTab('terms')}
            className={`py-3 px-3 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'terms'
                ? 'border-cyan-500 text-cyan-600 dark:border-cyan-400 dark:text-cyan-400'
                : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <FileText className="w-3.5 h-3.5 text-cyan-500" />
            <span>3. Terms of Use</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs text-slate-700 dark:text-slate-300 leading-relaxed max-h-[60vh]">
          {/* TAB 1: FINANCIAL & COMPENSATION DISCLAIMER */}
          {activeTab === 'disclaimer' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h3 className="font-bold text-slate-900 dark:text-white text-xs">
                    Informational and Analytical Purposes Only
                  </h3>
                  <p className="text-[11px] text-slate-600 dark:text-slate-400">
                    GetCostPulse is an algorithmic compensation and purchasing power parity modeling tool. It does not provide certified financial, tax, legal, or immigration advice.
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                  1. Nature of the Calculations
                </h4>
                <p>
                  All parity numbers, equivalence multipliers, and salary benchmarks provided by GetCostPulse are estimates calculated using weighted indices for housing, consumer goods, transportation, dining, and healthcare. Real-world living expenses vary significantly based on personal consumption habits, family size, housing tier, and timing.
                </p>

                <h4 className="font-bold text-slate-900 dark:text-white text-sm pt-2">
                  2. Income Tax &amp; Statutory Deductions
                </h4>
                <p>
                  Unless specifically calculated using our localized progressive tax brackets, figures represent gross purchasing power equivalents. Statutory deductions (such as federal/state taxes, National Insurance, Medicare, and mandatory pension contributions) depend heavily on individual residency status and tax treaties. Always consult a certified public accountant (CPA) or chartered tax advisor before negotiating relocation contracts.
                </p>

                <h4 className="font-bold text-slate-900 dark:text-white text-sm pt-2">
                  3. Currency Fluctuations &amp; Live Rates
                </h4>
                <p>
                  Exchange rates are retrieved from open mid-market institutional feeds (Open Exchange Rates / European Central Bank). Live spot rates fluctuate continuously throughout global trading sessions. Conversion rates should not be relied upon for foreign currency spot transactions or wire settlement.
                </p>
              </div>
            </div>
          )}

          {/* TAB 2: PRIVACY POLICY */}
          {activeTab === 'privacy' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-start gap-3">
                <Lock className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h3 className="font-bold text-slate-900 dark:text-white text-xs">
                    Client-Side First &amp; Transparent Privacy
                  </h3>
                  <p className="text-[11px] text-slate-600 dark:text-slate-400">
                    We value transparency. Below is our full disclosure regarding Google AdSense advertising, cookies, local browser storage, and your rights to manage or erase your data.
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                  1. Google AdSense &amp; Third-Party Advertising Cookies
                </h4>
                <p>
                  This website utilizes Google AdSense to serve advertisements. In compliance with Google publisher policies, please be advised of the following:
                </p>
                <ul className="list-disc pl-5 space-y-1 text-[11px] text-slate-600 dark:text-slate-400">
                  <li>
                    Third-party vendors, including Google, use cookies (such as the DoubleClick cookie) to serve ads based on your prior visits to this website or other websites on the Internet.
                  </li>
                  <li>
                    Google&apos;s use of advertising cookies enables it and its network partners to serve relevant advertisements to users based on browsing visits across the web.
                  </li>
                  <li>
                    <strong>Opt-Out of Personalized Advertising:</strong> You may opt out of personalized advertising by visiting{' '}
                    <a
                      href="https://www.google.com/settings/ads"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-cyan-600 dark:text-cyan-400 font-semibold underline"
                    >
                      Google Ads Settings
                    </a>
                    . Alternatively, you may opt out of third-party advertising cookies by visiting{' '}
                    <a
                      href="https://www.aboutads.info/choices/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-cyan-600 dark:text-cyan-400 font-semibold underline"
                    >
                      www.aboutads.info
                    </a>
                    .
                  </li>
                  <li>
                    GetCostPulse never transmits your salary inputs, financial parity models, or search scenarios to Google AdSense.
                  </li>
                </ul>

                <h4 className="font-bold text-slate-900 dark:text-white text-sm pt-2">
                  2. What Data Is Stored and Where
                </h4>
                <p>
                  All your active inputs—including selected baseline cities, comparison destinations, income amounts, appearance theme, and custom notification thresholds—are stored solely in your device&apos;s local web storage (<code className="px-1 py-0.5 rounded bg-slate-100 dark:bg-white/10 font-mono text-[11px]">localStorage</code>). This data is retained on your machine so you do not lose your calculation state when refreshing. It is never transmitted to an external analytics database.
                </p>

                <h4 className="font-bold text-slate-900 dark:text-white text-sm pt-2">
                  3. External API Requests (Live Currency Rates)
                </h4>
                <p>
                  To convert salaries across foreign currencies, the application queries an open public endpoint (<code className="px-1 py-0.5 rounded bg-slate-100 dark:bg-white/10 font-mono text-[11px]">open.er-api.com</code>). This query is completely anonymous: it only requests general currency pair ratios (e.g. USD to EUR) and never transmits your salary numbers, user identifiers, or personal profile data.
                </p>

                <h4 className="font-bold text-slate-900 dark:text-white text-sm pt-2">
                  4. Account Sign-In &amp; Support Requests
                </h4>
                <p>
                  If you enter an email to sign in or submit feedback through our Help Desk, this information is stored locally in your browser session to maintain your state. Support complaints and discrepancy tickets are routed directly to our creator support inbox (<a href="mailto:Alphafee@outlook.com" className="text-cyan-600 dark:text-cyan-400 font-semibold hover:underline">Official Support Desk</a>). We do not distribute, sell, or rent user contact details to any third-party marketers or data brokers.
                </p>

                <h4 className="font-bold text-slate-900 dark:text-white text-sm pt-2">
                  5. Total User Control &amp; Data Erasure
                </h4>
                <p>
                  You retain full ownership and control of all information on this site. You can wipe all stored preferences, scenarios, and cached rates at any time by opening <strong>Settings</strong> and clicking <strong>&quot;Purge Cached Rates &amp; Reset&quot;</strong>, or by clearing your browser cookies and site storage.
                </p>
              </div>
            </div>
          )}

          {/* TAB 3: TERMS OF USE & METHODOLOGIES */}
          {activeTab === 'terms' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-start gap-3">
                <Database className="w-5 h-5 text-cyan-600 dark:text-cyan-400 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h3 className="font-bold text-slate-900 dark:text-white text-xs">
                    Authoritative Open Macroeconomic Sources
                  </h3>
                  <p className="text-[11px] text-slate-600 dark:text-slate-400">
                    City indices are synthesized from reputable public repositories including the World Bank International Comparison Program (ICP), Eurostat, national statistical bureaus, and Numbeo living cost benchmarks.
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                  1. Permitted Use
                </h4>
                <p>
                  You are granted a non-exclusive license to use GetCostPulse for personal career planning, relocation negotiation, remote compensation modeling, and organizational talent budgeting.
                </p>

                <h4 className="font-bold text-slate-900 dark:text-white text-sm pt-2">
                  2. Intellectual Property &amp; Citations
                </h4>
                <p>
                  When utilizing charts, parity indexes, or comparison data generated by this tool in corporate mobility proposals or publications, attribution to GetCostPulse and its underlying institutional indices is appreciated.
                </p>

                <h4 className="font-bold text-slate-900 dark:text-white text-sm pt-2">
                  3. Limitation of Liability
                </h4>
                <p>
                  Under no circumstances shall the creators, maintainers, or providers of GetCostPulse be held liable for direct, indirect, incidental, or consequential losses resulting from reliance on the mathematical indices, career relocation decisions, or compensation negotiations conducted with data from this software.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-white/10 bg-slate-50/50 dark:bg-slate-950/40 flex items-center justify-between text-xs">
          <div className="text-slate-500 dark:text-slate-400 text-[11px]">
            Updated: September 2026
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100 font-bold transition-all shadow-sm cursor-pointer"
          >
            I Understand &amp; Agree
          </button>
        </div>
      </div>
    </div>
  );
};
