import React, { useEffect, useRef, useState } from 'react';

export interface AdContainerProps {
  /**
   * Google AdSense Ad Unit Slot ID (e.g. '1234567890').
   * If not provided, falls back to default configured slot.
   */
  adSlot?: string;
  /**
   * Google AdSense Publisher Client ID (e.g. 'ca-pub-9983854730849691').
   */
  adClient?: string;
  /**
   * Ad layout format: 'auto', 'fluid', 'rectangle', 'horizontal', or 'vertical'.
   */
  adFormat?: 'auto' | 'fluid' | 'rectangle' | 'horizontal' | 'vertical';
  /**
   * Enable responsive full-width behavior.
   */
  fullWidthResponsive?: boolean;
  /**
   * Optional custom CSS classes for the outer container.
   */
  className?: string;
  /**
   * Optional inline styles for the ins element.
   */
  style?: React.CSSProperties;
  /**
   * Whether to display the policy-compliant "ADVERTISEMENT" header label.
   */
  showPolicyLabel?: boolean;
  /**
   * Custom label text for compliance (default: 'ADVERTISEMENT').
   */
  labelText?: string;
}

/**
 * Dedicated Google AdSense AdContainer component.
 * Renders an ins.adsbygoogle block and manages inventory lifecycle safely.
 */
export const AdContainer: React.FC<AdContainerProps> = ({
  adSlot = '8492019384',
  adClient,
  adFormat = 'auto',
  fullWidthResponsive = true,
  className = '',
  style,
  showPolicyLabel = true,
  labelText = 'ADVERTISEMENT',
}) => {
  const insRef = useRef<HTMLModElement | null>(null);
  const pushedRef = useRef<boolean>(false);
  const [adError, setAdError] = useState<boolean>(false);

  // Publisher Client ID resolution (Env variable -> Prop -> Verified Default)
  const publisherId =
    adClient ||
    (typeof import.meta !== 'undefined' && import.meta.env?.VITE_ADSENSE_CLIENT_ID) ||
    'ca-pub-9983854730849691';

  useEffect(() => {
    // Avoid double-pushing in React 18 strict mode
    if (pushedRef.current) return;

    const timer = setTimeout(() => {
      try {
        if (typeof window !== 'undefined' && insRef.current) {
          // Check if AdSense script has already processed this ins element
          const status = insRef.current.getAttribute('data-adsbygoogle-status');
          if (!status) {
            const win = window as unknown as { adsbygoogle?: Array<Record<string, unknown>> };
            win.adsbygoogle = win.adsbygoogle || [];
            win.adsbygoogle.push({});
            pushedRef.current = true;
          }
        }
      } catch (err) {
        // TagError or blocked ad blocker handled gracefully
        console.debug('[AdSense AdContainer] initialization notice:', err);
        setAdError(true);
      }
    }, 150);

    return () => clearTimeout(timer);
  }, [adSlot, publisherId]);

  return (
    <div
      id={`ad-container-${adSlot}`}
      className={`w-full flex flex-col items-center justify-center my-6 overflow-hidden select-none transition-colors ${className}`}
      aria-label="Sponsored Advertisement"
    >
      <div className="w-full max-w-5xl rounded-2xl border border-slate-200/80 dark:border-white/10 bg-slate-50/60 dark:bg-slate-900/40 p-3.5 flex flex-col items-center text-center shadow-xs">
        {/* AdSense Policy Mandatory Identification Label */}
        {showPolicyLabel && (
          <div className="flex items-center justify-between w-full px-2 mb-2 border-b border-slate-200/60 dark:border-white/5 pb-1.5">
            <span className="text-[10px] tracking-widest uppercase font-semibold text-slate-400 dark:text-slate-500">
              {labelText}
            </span>
            <span className="text-[9px] text-slate-400 dark:text-slate-600">
              Google AdSense Inventory Slot
            </span>
          </div>
        )}

        {/* Primary ins.adsbygoogle Block */}
        <ins
          ref={insRef}
          className="adsbygoogle block w-full min-h-[90px]"
          style={{
            display: 'block',
            textAlign: 'center',
            ...style,
          }}
          data-ad-client={publisherId}
          data-ad-slot={adSlot}
          data-ad-format={adFormat}
          data-full-width-responsive={fullWidthResponsive ? 'true' : 'false'}
        />

        {/* Fallback / Verification Guidance Container (Displays if script unserved or in sandbox preview) */}
        {(!publisherId || adError) && (
          <div className="py-4 px-6 w-full flex flex-col items-center justify-center text-slate-400 dark:text-slate-500 text-xs">
            <p className="text-[11px] font-semibold text-slate-600 dark:text-slate-300">
              AdSense Inventory Space Reserved
            </p>
            <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-1 max-w-lg">
              Live banner ads will render on production domains with active AdSense crawler approval for client <code className="font-mono text-[10px] text-cyan-600 dark:text-cyan-400">{publisherId}</code>.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
