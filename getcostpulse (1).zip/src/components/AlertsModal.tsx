import React from 'react';
import { X, Bell, TrendingUp, Building2, AlertTriangle, CheckCheck } from 'lucide-react';
import { AlertItem } from '../types';

interface AlertsModalProps {
  isOpen: boolean;
  onClose: () => void;
  alerts: AlertItem[];
  onMarkAllAsRead: () => void;
}

export const AlertsModal: React.FC<AlertsModalProps> = ({
  isOpen,
  onClose,
  alerts,
  onMarkAllAsRead,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 dark:bg-slate-950/75 animate-in fade-in duration-150">
      <div
        id="alerts-modal-container"
        className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-white/15 rounded-3xl shadow-2xl overflow-hidden flex flex-col text-slate-900 dark:text-slate-100 max-h-[85vh] transition-colors"
      >
        <div className="p-4 border-b border-slate-200 dark:border-white/10 flex items-center justify-between bg-slate-50/90 dark:bg-slate-900/90">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-rose-500/10 dark:bg-rose-500/20 text-rose-600 dark:text-rose-400 flex items-center justify-center">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">Parity &amp; FX Notifications</h3>
              <span className="text-[11px] text-slate-500 dark:text-slate-400">Market volatility notifications</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/10 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 overflow-y-auto space-y-3 flex-1">
          {alerts.map((alert) => (
            <div
              key={alert.id}
              className={`p-3.5 rounded-2xl border transition-all ${
                !alert.read
                  ? 'bg-rose-500/10 border-rose-500/30 text-slate-900 dark:text-slate-100'
                  : 'bg-slate-50 dark:bg-white/[0.02] border-slate-200 dark:border-white/5 text-slate-800 dark:text-slate-200'
              }`}
            >
              <div className="flex items-start justify-between gap-2 mb-1">
                <span className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  {alert.type === 'fx' && <TrendingUp className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400" />}
                  {alert.type === 'rent' && <Building2 className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />}
                  {alert.type === 'inflation' && <AlertTriangle className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />}
                  <span>{alert.title}</span>
                </span>
                <span className="text-[10px] text-slate-400 dark:text-slate-500 font-mono shrink-0">{alert.timeAgo}</span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">{alert.description}</p>
            </div>
          ))}
        </div>

        <div className="p-3.5 border-t border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-slate-950/60 flex items-center justify-between text-xs">
          <button
            onClick={onMarkAllAsRead}
            className="text-cyan-600 dark:text-cyan-400 hover:text-cyan-700 dark:hover:text-cyan-300 inline-flex items-center gap-1 font-semibold transition-colors"
          >
            <CheckCheck className="w-3.5 h-3.5" />
            <span>Mark all notifications as read</span>
          </button>
          <button
            onClick={onClose}
            className="px-3.5 py-1.5 rounded-xl bg-slate-200 hover:bg-slate-300 dark:bg-white/10 dark:hover:bg-white/15 text-slate-800 dark:text-slate-300 font-medium transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
