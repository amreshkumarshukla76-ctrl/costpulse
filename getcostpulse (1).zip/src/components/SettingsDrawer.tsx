import React from 'react';
import { X, Trash2, Check, RefreshCw, Sun, Moon, Monitor, LogOut, LifeBuoy, User, ShieldCheck, Linkedin, Instagram, ExternalLink, Info, Sparkles } from 'lucide-react';
import { UserScenario, City } from '../types';

interface SettingsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  scenario: UserScenario;
  onUpdateScenario: (scenario: Partial<UserScenario>) => void;
  originCity: City;
  onOpenOriginPicker: () => void;
  onShowToast?: (msg: string, type?: 'success' | 'info' | 'warning') => void;
  isAuthenticated?: boolean;
  userEmail?: string;
  onSignOut?: () => void;
  onOpenSupport?: () => void;
  onOpenAuth?: () => void;
  onOpenDisclaimer?: () => void;
  onOpenPrivacy?: () => void;
  onOpenTerms?: () => void;
  onOpenUsp?: () => void;
}

export const SettingsDrawer: React.FC<SettingsDrawerProps> = ({
  isOpen,
  onClose,
  scenario,
  onUpdateScenario,
  originCity,
  onOpenOriginPicker,
  onShowToast,
  isAuthenticated,
  userEmail,
  onSignOut,
  onOpenSupport,
  onOpenAuth,
  onOpenDisclaimer,
  onOpenPrivacy,
  onOpenTerms,
  onOpenUsp,
}) => {
  if (!isOpen) return null;

  const handlePurge = () => {
    localStorage.clear();
    onShowToast?.('Cached currency feeds and local scenario states purged successfully.', 'success');
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/60 animate-fadeIn">
      <div
        id="settings-drawer-panel"
        className="w-full max-w-md h-full bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-white/10 p-6 shadow-2xl flex flex-col justify-between text-slate-900 dark:text-slate-100 overflow-y-auto transition-colors"
      >
        <div>
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-white/10 mb-6">
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">Preferences &amp; Settings</h3>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-slate-500 dark:text-slate-400">
                DRAWER PANEL
              </span>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/10 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-6">
            {/* Account & Session Section */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-cyan-500" />
                  <span>Account &amp; Session</span>
                </span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-mono uppercase font-bold ${
                  isAuthenticated
                    ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30'
                    : 'bg-slate-200 dark:bg-white/10 text-slate-500 dark:text-slate-400'
                }`}>
                  {isAuthenticated ? 'Authenticated' : 'Guest'}
                </span>
              </div>

              {isAuthenticated ? (
                <div className="space-y-2 text-xs">
                  <div className="flex items-center justify-between text-slate-600 dark:text-slate-400">
                    <span>Account Status:</span>
                    <span className="font-semibold text-cyan-600 dark:text-cyan-400 truncate max-w-[200px] flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3 text-emerald-500" />
                      <span>{userEmail ? `${userEmail.slice(0, 3)}***@${userEmail.split('@')[1] || ''}` : 'Active Session'}</span>
                    </span>
                  </div>
                  <button
                    id="settings-signout-btn"
                    onClick={() => {
                      if (onSignOut) {
                        onSignOut();
                        onClose();
                        onShowToast?.('You have been securely signed out.', 'info');
                      }
                    }}
                    className="w-full py-2.5 px-3 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 border border-rose-500/25 font-bold flex items-center justify-center gap-2 transition-all active:scale-95"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Sign Out of Account</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-2">
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Sign in to save custom city benchmarks, unlock encrypted telemetry, and store multi-city scenarios.
                  </p>
                  <button
                    onClick={() => {
                      onClose();
                      onOpenAuth?.();
                    }}
                    className="w-full py-2 px-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-sm"
                  >
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Sign In to Workspace</span>
                  </button>
                </div>
              )}
            </div>

            {/* Why GetCostPulse? (USP) Card */}
            {onOpenUsp && (
              <div className="p-4 rounded-2xl bg-gradient-to-br from-cyan-500/10 via-blue-500/5 to-transparent border border-cyan-500/30 space-y-2 relative overflow-hidden">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-800 dark:text-cyan-300">
                    <Sparkles className="w-3.5 h-3.5 text-cyan-500" />
                    <span>Why GetCostPulse?</span>
                  </div>
                  <span className="px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider bg-cyan-500/20 text-cyan-700 dark:text-cyan-300">
                    Transparency
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                  Why use GetCostPulse over generic calculators? Real-time institutional rates, zero email paywalls, and pure client-side privacy.
                </p>
                <button
                  onClick={() => {
                    onClose();
                    onOpenUsp();
                  }}
                  className="w-full mt-1 py-2 px-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-sm cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>See How We Compare</span>
                </button>
              </div>
            )}

            {/* Help & Support Desk */}
            {onOpenSupport && (
              <div className="p-4 rounded-2xl bg-cyan-500/5 dark:bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <LifeBuoy className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400" />
                    <span>Support &amp; Issue Resolution</span>
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                    Official Resolution Desk • Lodge tickets &amp; complaints
                  </div>
                </div>
                <button
                  onClick={() => {
                    onClose();
                    onOpenSupport();
                  }}
                  className="px-3 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shrink-0 transition-all shadow-sm"
                >
                  Open Desk
                </button>
              </div>
            )}

            {/* Appearance Theme */}
            <div>
              <div className="flex items-center justify-between text-xs mb-2">
                <label className="font-bold text-slate-700 dark:text-slate-300">Appearance Theme</label>
                <span className="text-cyan-600 dark:text-cyan-400 font-mono text-[11px] capitalize">
                  {scenario.theme === 'light' ? 'Daylight' : scenario.theme} Mode
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2 text-xs">
                {(['light', 'dark', 'system'] as const).map((th) => (
                  <button
                    key={th}
                    onClick={() => onUpdateScenario({ theme: th })}
                    className={`py-2 px-3 rounded-xl font-semibold capitalize flex items-center justify-center gap-1.5 transition-all ${
                      scenario.theme === th
                        ? 'bg-cyan-500 text-slate-950 shadow-sm font-bold'
                        : 'bg-slate-100 dark:bg-white/5 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-white/10 border border-slate-200 dark:border-white/5'
                    }`}
                  >
                    {th === 'light' && <Sun className="w-3.5 h-3.5" />}
                    {th === 'dark' && <Moon className="w-3.5 h-3.5" />}
                    {th === 'system' && <Monitor className="w-3.5 h-3.5" />}
                    <span>{th === 'light' ? 'Daylight' : th}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Income Calculation */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/5 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900 dark:text-white">Income Calculation</span>
                <span className="text-[10px] font-mono text-cyan-600 dark:text-cyan-400 uppercase font-bold">
                  {scenario.deductTaxes ? 'Net Take-home' : 'Gross Nominal'}
                </span>
              </div>
              <div className="flex items-center justify-between pt-1">
                <div>
                  <div className="text-xs font-semibold text-slate-800 dark:text-slate-200">Deduct Estimated Taxes</div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400">
                    Local council + federal tax models applied
                  </div>
                </div>
                <button
                  onClick={() => onUpdateScenario({ deductTaxes: !scenario.deductTaxes })}
                  className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                    scenario.deductTaxes ? 'bg-cyan-500' : 'bg-slate-300 dark:bg-slate-700'
                  }`}
                >
                  <div
                    className={`w-5 h-5 rounded-full bg-white dark:bg-slate-950 transition-transform shadow-sm ${
                      scenario.deductTaxes ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>
            </div>

            {/* Number & Delimiter Format */}
            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-2">
                Number &amp; Delimiter Format
              </label>
              <select
                value={scenario.numberFormat}
                onChange={(e) => onUpdateScenario({ numberFormat: e.target.value as 'us' | 'eu' })}
                className="w-full p-2.5 rounded-xl bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-white/10 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:border-cyan-400"
              >
                <option value="us">US/UK Standard (1,234.56)</option>
                <option value="eu">Continental European (1.234,56)</option>
              </select>
            </div>

            {/* Global Default Baseline */}
            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-2">
                Global Default Baseline
              </label>
              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/5">
                <div className="flex items-center gap-2 text-xs">
                  <span>{originCity.flag}</span>
                  <span className="font-semibold text-slate-900 dark:text-white">
                    {originCity.name}, {originCity.country}
                  </span>
                </div>
                <button
                  onClick={onOpenOriginPicker}
                  className="text-xs text-cyan-600 dark:text-cyan-400 hover:text-cyan-500 font-semibold"
                >
                  Change
                </button>
              </div>
            </div>

            {/* About GetCostPulse Section per user request */}
            <div id="settings-about-section" className="p-4 rounded-2xl bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <Info className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400" />
                  <span>About GetCostPulse</span>
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-500/10 text-cyan-700 dark:text-cyan-300 border border-cyan-500/25">
                  v2.4 Daylight
                </span>
              </div>

              <p className="text-xs leading-relaxed text-slate-700 dark:text-slate-300 font-normal">
                GetCostPulse compares purchasing power between cities, showing the salary you need elsewhere to keep your lifestyle.
              </p>

              <div className="pt-2 border-t border-slate-200 dark:border-white/5 space-y-2">
                <span className="text-[10px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider block">
                  Connect with the creator
                </span>
                <div className="flex flex-wrap items-center gap-3 text-xs">
                  <a
                    id="settings-linkedin-link"
                    href="https://www.linkedin.com/in/atharv-shukla-0a0368345"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 font-semibold text-cyan-600 dark:text-cyan-400 hover:underline group"
                    title="LinkedIn - Atharv Shukla"
                  >
                    <Linkedin className="w-3.5 h-3.5" />
                    <span>LinkedIn - Atharv Shukla</span>
                    <ExternalLink className="w-2.5 h-2.5 opacity-70 group-hover:opacity-100" />
                  </a>

                  <span className="text-slate-300 dark:text-slate-700">•</span>

                  <span className="inline-flex items-center gap-1 text-slate-500 dark:text-slate-400 text-xs">
                    <Instagram className="w-3.5 h-3.5 opacity-70" />
                    <span>Instagram - Soon</span>
                  </span>
                </div>

                <div className="pt-1 text-[11px] text-slate-500 dark:text-slate-400">
                  Designed &amp; built by Atharv Shukla • &copy; 2026
                </div>
              </div>

              {/* Legal & Disclaimer Navigation inside Drawer */}
              <div className="pt-3 border-t border-slate-200 dark:border-white/5 space-y-2">
                <span className="text-[10px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider block">
                  Transparency &amp; Legal
                </span>

                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-white/10 text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
                  <span className="font-semibold text-slate-800 dark:text-slate-200">Disclaimer: </span>
                  GetCostPulse projections are statistical approximations for educational planning. They do not constitute certified financial, tax, or legal advice.
                </div>

                <div className="flex flex-col gap-1 text-xs">
                  <button
                    onClick={() => {
                      onClose();
                      onOpenDisclaimer?.();
                    }}
                    className="flex items-center justify-between py-1.5 text-left text-slate-700 dark:text-slate-300 hover:text-amber-600 dark:hover:text-amber-400 transition-colors cursor-pointer"
                  >
                    <span>Financial &amp; Tax Disclaimer</span>
                    <span className="text-[10px] text-slate-400">Read &rarr;</span>
                  </button>

                  <button
                    onClick={() => {
                      onClose();
                      onOpenPrivacy?.();
                    }}
                    className="flex items-center justify-between py-1.5 text-left text-slate-700 dark:text-slate-300 hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors cursor-pointer"
                  >
                    <span>Privacy Policy</span>
                    <span className="text-[10px] text-slate-400">Read &rarr;</span>
                  </button>

                  <button
                    onClick={() => {
                      onClose();
                      onOpenTerms?.();
                    }}
                    className="flex items-center justify-between py-1.5 text-left text-slate-700 dark:text-slate-300 hover:text-cyan-600 dark:hover:text-cyan-400 transition-colors cursor-pointer"
                  >
                    <span>Terms of Use</span>
                    <span className="text-[10px] text-slate-400">Read &rarr;</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Purge Reset button */}
        <div className="pt-6 border-t border-slate-200 dark:border-white/10">
          <button
            onClick={handlePurge}
            className="w-full py-3 px-4 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-600 dark:text-rose-300 border border-rose-500/20 text-xs font-bold flex items-center justify-center gap-2 transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Purge Cached Rates &amp; Reset</span>
          </button>
        </div>
      </div>
    </div>
  );
};
