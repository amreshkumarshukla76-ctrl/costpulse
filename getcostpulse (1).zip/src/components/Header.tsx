import React from 'react';
import { Activity, ArrowLeftRight, ChevronDown, Sparkles, DollarSign } from 'lucide-react';
import { City, Currency, UserProfile } from '../types';

interface HeaderProps {
  originCity: City;
  destCity: City;
  baseSalary: number;
  isAnnual?: boolean;
  selectedCurrency?: Currency;
  activeCurrency?: Currency;
  userProfile?: UserProfile;
  onOpenOriginPicker: () => void;
  onOpenDestPicker: () => void;
  onOpenSalaryEditor: () => void;
  onOpenCurrencyModal: () => void;
  onOpenAuthModal?: () => void;
  onOpenAuth?: () => void;
  onOpenProfile?: () => void;
  onSwapCities: () => void;
  onCalculateClick?: () => void;
  onLogoClick?: () => void;
  onOpenVerify?: () => void;
  onOpenSupport?: () => void;
  onOpenSettings?: () => void;
  onOpenUsp?: () => void;
  onSignOut?: () => void;
  onToggleTheme?: () => void;
  isDarkMode?: boolean;
  isAuthenticated: boolean;
  activeView?: string;
}

export const Header: React.FC<HeaderProps> = ({
  originCity,
  destCity,
  baseSalary,
  isAnnual = true,
  selectedCurrency,
  activeCurrency,
  userProfile,
  onOpenOriginPicker,
  onOpenDestPicker,
  onOpenSalaryEditor,
  onOpenCurrencyModal,
  onOpenAuthModal,
  onOpenAuth,
  onOpenProfile,
  onSwapCities,
  onCalculateClick,
  onLogoClick,
  onOpenVerify,
  onOpenSupport,
  onOpenSettings,
  onOpenUsp,
  onSignOut,
  onToggleTheme,
  isDarkMode,
  isAuthenticated,
}) => {
  const currencyToUse = selectedCurrency || activeCurrency || {
    code: 'GBP',
    symbol: '£',
    name: 'British Pound',
    rateToGBP: 1.0,
    change24h: 0,
    flag: '🇬🇧',
    category: 'Popular',
  };
  const handleLogoClick = onLogoClick || (() => {});

  return (
    <header className="fixed top-0 left-0 right-0 z-40 px-3 md:px-6 py-3 flex items-center justify-between gap-2 md:gap-3 pointer-events-none transition-colors">
      {/* Brand logo (pointer-events-auto) */}
      <div className="pointer-events-auto flex items-center gap-2">
        <div
          id="brand-logo-pill"
          className="flex items-center gap-2 px-2.5 md:px-3 py-1.5 rounded-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-md transition-all hover:border-cyan-500/40 cursor-pointer"
          onClick={handleLogoClick}
          title="Return to Dashboard"
        >
          <div className="w-6 h-6 rounded-lg bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-sm shrink-0">
            <Activity className="w-3.5 h-3.5 stroke-[2.5]" />
          </div>
          <div className="flex flex-col">
            <span className="text-[11px] md:text-[12px] font-bold tracking-wider text-slate-900 dark:text-slate-100 uppercase">
              GetCostPulse
            </span>
            <span className="text-[8px] md:text-[9px] font-semibold tracking-tight text-cyan-600 dark:text-cyan-400/80 -mt-0.5 hidden sm:inline">
              Purchasing Power Engine
            </span>
          </div>
        </div>
      </div>

      {/* Mobile Compact Selector (Visible on small screens < md) */}
      <div className="pointer-events-auto md:hidden flex items-center bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-full px-2.5 py-1 text-xs text-slate-800 dark:text-slate-200 shadow-md gap-1">
        <button
          onClick={onOpenOriginPicker}
          className="font-bold text-slate-900 dark:text-white hover:text-cyan-600 dark:hover:text-cyan-300 max-w-[70px] truncate"
          title="Change Origin Metro"
        >
          {originCity.name}
        </button>
        <button
          onClick={onSwapCities}
          className="text-cyan-600 dark:text-cyan-400 p-0.5 hover:rotate-180 transition-transform active:scale-90"
          title="Swap Metros"
        >
          <ArrowLeftRight className="w-3 h-3" />
        </button>
        <button
          onClick={onOpenDestPicker}
          className="font-bold text-slate-900 dark:text-white hover:text-cyan-600 dark:hover:text-cyan-300 max-w-[70px] truncate"
          title="Change Destination Metro"
        >
          {destCity.name}
        </button>
        {onCalculateClick && (
          <button
            onClick={onCalculateClick}
            className="ml-1 px-2 py-0.5 rounded-full bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-extrabold text-[10px] tracking-wide active:scale-95 shadow-sm"
          >
            Calc ↗
          </button>
        )}
      </div>

      {/* Main comparative control pill capsule */}
      <div
        id="header-comparison-pill"
        className="pointer-events-auto hidden md:flex items-center absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-full p-1 shadow-lg transition-all hover:border-cyan-500/30 text-slate-800 dark:text-slate-200 z-10 whitespace-nowrap"
      >
        {/* Origin Selector */}
        <button
          id="header-origin-btn"
          onClick={onOpenOriginPicker}
          className="flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/10 transition-colors group"
        >
          <span className="text-rose-500 dark:text-rose-400">📍</span>
          <span className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-semibold">Origin</span>
          <span className="font-semibold text-slate-900 dark:text-white group-hover:text-cyan-600 dark:group-hover:text-cyan-300">
            {originCity.name}, {originCity.country === 'United Kingdom' ? 'UK' : originCity.flag}
          </span>
          <ChevronDown className="w-3 h-3 text-slate-400 group-hover:text-slate-700 dark:group-hover:text-white" />
        </button>

        {/* Swap / Compare Button between Origin & Destination */}
        <button
          id="header-swap-btn"
          onClick={onSwapCities}
          title="Swap origin and destination cities"
          className="flex items-center justify-center p-1.5 mx-0.5 rounded-full text-slate-600 dark:text-slate-300 hover:text-cyan-600 dark:hover:text-cyan-300 hover:bg-cyan-500/10 transition-all active:scale-90"
        >
          <ArrowLeftRight className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400" />
        </button>

        {/* Destination Selector */}
        <button
          id="header-dest-btn"
          onClick={onOpenDestPicker}
          className="flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/10 transition-colors group"
        >
          <span className="text-cyan-600 dark:text-cyan-400">🏢</span>
          <span className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-semibold">Destination</span>
          <span className="font-semibold text-slate-900 dark:text-white group-hover:text-cyan-600 dark:group-hover:text-cyan-300">
            {destCity.name}, {destCity.country === 'USA' ? 'US' : destCity.flag}
          </span>
          <ChevronDown className="w-3 h-3 text-slate-400 group-hover:text-slate-700 dark:group-hover:text-white" />
        </button>

        <div className="w-px h-5 bg-slate-200 dark:bg-white/10 mx-1" />

        {/* Base Salary */}
        <button
          id="header-salary-btn"
          onClick={onOpenSalaryEditor}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/10 transition-colors group"
        >
          <DollarSign className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
          <span className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-semibold">Base Salary</span>
          <span className="font-bold text-slate-900 dark:text-white group-hover:text-cyan-600 dark:group-hover:text-cyan-300">
            {originCity.currencySymbol}{baseSalary.toLocaleString()}{isAnnual ? '/yr' : '/mo'}
          </span>
          <ChevronDown className="w-3 h-3 text-slate-400 group-hover:text-slate-700 dark:group-hover:text-white" />
        </button>

        {/* Calculate Cyan Button */}
        <button
          id="header-calculate-btn"
          onClick={onCalculateClick}
          className="flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-gradient-to-r from-cyan-400 to-sky-500 hover:from-cyan-300 hover:to-sky-400 text-slate-950 font-bold text-xs tracking-wide transition-all shadow-md shadow-cyan-500/20 active:scale-95 ml-1"
        >
          <span>Calculate</span>
          <span className="text-sm leading-none">↗</span>
        </button>
      </div>

      {/* Right controls: Currency + Live Feeds + Support + User profile */}
      <div className="pointer-events-auto flex items-center gap-2">
        {/* Currency toggle */}
        <button
          id="header-currency-toggle"
          onClick={onOpenCurrencyModal}
          className="flex items-center gap-1.5 px-2.5 md:px-3 py-1.5 rounded-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 hover:border-cyan-400/40 hover:bg-slate-50 dark:hover:bg-slate-800 transition-all shadow-sm"
        >
          <span className="text-sm">{currencyToUse.flag}</span>
          <span className="font-bold text-slate-900 dark:text-slate-100">{currencyToUse.code}</span>
          <ChevronDown className="w-3 h-3 text-slate-400" />
        </button>

        {/* Live Feeds status badge / data sources trigger */}
        <button
          id="header-verify-data-btn"
          onClick={onOpenVerify}
          className="hidden xl:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-[11px] text-slate-700 dark:text-slate-200 font-bold hover:border-cyan-400 hover:bg-slate-50 dark:hover:bg-slate-800 transition-all shadow-sm cursor-pointer"
          title="Inspect Open Data Sources & Parity Calculations"
        >
          <span className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse" />
          <span className="tracking-wide uppercase text-[10px]">Data &amp; Sources</span>
        </button>
      </div>
    </header>
  );
};
