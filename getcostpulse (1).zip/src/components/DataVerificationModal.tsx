import React, { useState } from 'react';
import {
  X,
  CheckCircle2,
  ExternalLink,
  RefreshCw,
  ShieldCheck,
  Globe,
  Database,
  Calculator,
  ArrowRight,
  BookOpen,
  AlertCircle,
  Building2,
} from 'lucide-react';
import { City, Currency, UserScenario } from '../types';
import { LiveFxState } from '../utils/liveFxService';
import { calculateParity } from '../utils/parityCalc';

interface DataVerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  originCity: City;
  destCity: City;
  scenario: UserScenario;
  currencies: Currency[];
  liveFx: LiveFxState;
  onRefreshLiveFx: () => Promise<void>;
  initialTab?: 'live-fx' | 'benchmarks' | 'formula' | 'sources';
}

export const DataVerificationModal: React.FC<DataVerificationModalProps> = ({
  isOpen,
  onClose,
  originCity,
  destCity,
  scenario,
  currencies,
  liveFx,
  onRefreshLiveFx,
  initialTab = 'live-fx',
}) => {
  const [activeTab, setActiveTab] = useState<'live-fx' | 'benchmarks' | 'formula' | 'sources'>(initialTab);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [refreshSuccess, setRefreshSuccess] = useState(false);

  if (!isOpen) return null;

  const handleManualRefresh = async () => {
    setIsRefreshing(true);
    setRefreshSuccess(false);
    try {
      await onRefreshLiveFx();
      setRefreshSuccess(true);
      setTimeout(() => setRefreshSuccess(false), 3000);
    } catch {
      // Handled in parent
    } finally {
      setIsRefreshing(false);
    }
  };

  const originCurr = currencies.find((c) => c.code === originCity.currency) || currencies[0];
  const destCurr = currencies.find((c) => c.code === destCity.currency) || currencies[1];

  const originUsd = originCurr.rateToUSD || 1;
  const destUsd = destCurr.rateToUSD || 1;

  const parity = calculateParity(originCity, destCity, scenario, currencies);
  const isAnnual = scenario.isAnnual;
  const periodLabel = isAnnual ? '/yr' : '/mo';

  // External Numbeo comparison link generator
  const numbeoUrl = `https://www.numbeo.com/cost-of-living/compare_cities.jsp?country1=${encodeURIComponent(
    originCity.country
  )}&city1=${encodeURIComponent(originCity.name)}&country2=${encodeURIComponent(
    destCity.country
  )}&city2=${encodeURIComponent(destCity.name)}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-slate-900/60 dark:bg-slate-950/80 animate-in fade-in duration-200">
      <div
        className="w-full max-w-4xl max-h-[90vh] flex flex-col rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-white/15 text-slate-900 dark:text-slate-100 shadow-2xl overflow-hidden transition-colors"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-white/10 flex items-center justify-between bg-slate-50 dark:bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-500/20 to-cyan-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-600 dark:text-emerald-400 shadow-inner">
              <ShieldCheck className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-slate-900 dark:text-white">Data Sources &amp; Calculation Inspector</h2>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-cyan-500/15 text-cyan-700 dark:text-cyan-400 border border-cyan-500/30">
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-500 dark:bg-cyan-400 animate-pulse" />
                  {liveFx.isLive ? 'Live FX Connected' : 'Standard Benchmarks'}
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Inspect real-time FX API calls, public benchmark sources, and parity formulas.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 dark:border-white/10 bg-slate-50/70 dark:bg-slate-950/40 px-6 gap-2 text-xs font-semibold overflow-x-auto">
          <button
            onClick={() => setActiveTab('live-fx')}
            className={`py-3 px-3 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'live-fx'
                ? 'border-cyan-500 text-cyan-600 dark:border-cyan-400 dark:text-cyan-400'
                : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>1. FX &amp; Benchmark Feed</span>
          </button>

          <button
            onClick={() => setActiveTab('benchmarks')}
            className={`py-3 px-3 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'benchmarks'
                ? 'border-cyan-500 text-cyan-600 dark:border-cyan-400 dark:text-cyan-400'
                : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>2. City Cost Indexes ({originCity.name} ⇄ {destCity.name})</span>
          </button>

          <button
            onClick={() => setActiveTab('formula')}
            className={`py-3 px-3 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'formula'
                ? 'border-cyan-500 text-cyan-600 dark:border-cyan-400 dark:text-cyan-400'
                : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <Calculator className="w-3.5 h-3.5" />
            <span>3. Equation Proof Inspector</span>
          </button>

          <button
            onClick={() => setActiveTab('sources')}
            className={`py-3 px-3 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'sources'
                ? 'border-cyan-500 text-cyan-600 dark:border-cyan-400 dark:text-cyan-400'
                : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>4. Institutional References</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-sm">
          {/* TAB 1: LIVE FX FEED */}
          {activeTab === 'live-fx' && (
            <div className="space-y-5">
              <div className="p-4 rounded-2xl bg-cyan-500/5 dark:bg-gradient-to-r dark:from-cyan-950/40 dark:via-slate-900 dark:to-slate-900 border border-cyan-500/20 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 dark:bg-emerald-400 animate-ping" />
                    <span className="text-xs font-bold text-emerald-700 dark:text-emerald-400 uppercase tracking-wider">
                      {liveFx.isFallback ? 'Benchmark Reference Active' : 'Live Feed Active'}
                    </span>
                    <span className="text-xs text-slate-500 dark:text-slate-400">• Provider: {liveFx.provider}</span>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-300">
                    Last synced: <span className="font-mono text-cyan-700 dark:text-cyan-300 font-semibold">{liveFx.lastUpdated}</span>
                    {liveFx.lastFetchDurationMs && (
                      <span className="text-slate-400"> (Latency: {liveFx.lastFetchDurationMs}ms)</span>
                    )}
                  </p>
                </div>

                <div className="flex items-center gap-2.5 w-full md:w-auto">
                  <button
                    onClick={handleManualRefresh}
                    disabled={isRefreshing}
                    className="flex-1 md:flex-none px-4 py-2 rounded-xl bg-cyan-500 text-white dark:bg-cyan-400 dark:text-slate-950 font-bold text-xs hover:bg-cyan-400 transition-all flex items-center justify-center gap-2 shadow-lg disabled:opacity-50"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
                    <span>{isRefreshing ? 'Fetching Live...' : 'Refresh Feed Now'}</span>
                  </button>

                  <a
                    href="https://open.er-api.com/v6/latest/USD"
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-white/5 dark:hover:bg-white/10 border border-slate-200 dark:border-white/10 text-slate-700 dark:text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                    title="View Raw Live JSON in new tab"
                  >
                    <span>Raw JSON</span>
                    <ExternalLink className="w-3 h-3 text-cyan-600 dark:text-cyan-400" />
                  </a>
                </div>
              </div>

              {refreshSuccess && (
                <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-500/40 text-emerald-800 dark:text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                  <span className="font-semibold">Live exchange rates freshly fetched and syndicated across the parity engine!</span>
                </div>
              )}

              {/* Live FX Rate Table */}
              <div className="rounded-2xl border border-slate-200 dark:border-white/10 overflow-hidden bg-slate-50 dark:bg-slate-950/40">
                <div className="px-4 py-2.5 bg-slate-100 dark:bg-white/5 border-b border-slate-200 dark:border-white/10 flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
                  <span>Live Syndicated Currency Rates</span>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400">Base Reference: 1.00 USD</span>
                </div>

                <div className="divide-y divide-slate-200 dark:divide-white/5 max-h-64 overflow-y-auto">
                  {currencies.map((curr) => (
                    <div
                      key={curr.code}
                      className={`px-4 py-2.5 flex items-center justify-between text-xs transition-colors hover:bg-slate-100/80 dark:hover:bg-white/5 ${
                        curr.code === originCity.currency || curr.code === destCity.currency
                          ? 'bg-cyan-500/10'
                          : ''
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-base">{curr.flag}</span>
                        <div>
                          <span className="font-bold text-slate-900 dark:text-white">{curr.code}</span>
                          <span className="text-slate-500 dark:text-slate-400 ml-1.5 hidden sm:inline">({curr.name})</span>
                        </div>
                        {(curr.code === originCity.currency || curr.code === destCity.currency) && (
                          <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-cyan-500 text-white dark:bg-cyan-400 dark:text-slate-950">
                            Active in Scenario
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-6 font-mono text-right">
                        <div>
                          <span className="text-slate-500 dark:text-slate-400 text-[10px] block">1 USD =</span>
                          <span className="text-slate-900 dark:text-white font-semibold">
                            {curr.symbol} {curr.rateToUSD.toLocaleString()}
                          </span>
                        </div>
                        <div className="hidden sm:block">
                          <span className="text-slate-500 dark:text-slate-400 text-[10px] block">1 GBP =</span>
                          <span className="text-slate-700 dark:text-slate-300">
                            {curr.symbol} {curr.rateToGBP.toLocaleString()}
                          </span>
                        </div>
                        <span
                          className={`text-[11px] font-semibold ${
                            curr.change24h >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
                          }`}
                        >
                          {curr.change24h >= 0 ? `+${curr.change24h}%` : `${curr.change24h}%`}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: CITY COST INDEXES */}
          {activeTab === 'benchmarks' && (
            <div className="space-y-5">
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 space-y-2">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <span>How Cost-of-Living Indexes Are Benchmarked</span>
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  Every global metropolitan index is calibrated relative to <strong>New York City (NYC = 100.0)</strong> as the international base standard, identical to the methodology utilized by Numbeo, Mercer, and the Economist Intelligence Unit (EIU).
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Origin City */}
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-white/10 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">{originCity.flag}</span>
                      <div>
                        <span className="font-bold text-slate-900 dark:text-white">{originCity.name}</span>
                        <span className="text-xs text-slate-500 dark:text-slate-400 block">{originCity.country} (Origin Anchor)</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-xs text-slate-500 dark:text-slate-400 block">Overall Index</span>
                      <span className="text-lg font-black font-mono text-cyan-600 dark:text-cyan-400">
                        {originCity.costIndex.toFixed(1)}
                      </span>
                    </div>
                  </div>

                  <div className="space-y-1.5 pt-2 border-t border-slate-200 dark:border-white/10 text-xs">
                    <div className="flex justify-between text-slate-600 dark:text-slate-300">
                      <span>Residential Rent Index:</span>
                      <span className="font-mono text-slate-900 dark:text-white font-semibold">{originCity.rentIndex.toFixed(1)}</span>
                    </div>
                    <div className="flex justify-between text-slate-600 dark:text-slate-300">
                      <span>Groceries & Daily FMCG:</span>
                      <span className="font-mono text-slate-900 dark:text-white font-semibold">{originCity.groceriesIndex.toFixed(1)}</span>
                    </div>
                    <div className="flex justify-between text-slate-600 dark:text-slate-300">
                      <span>Municipal Transit:</span>
                      <span className="font-mono text-slate-900 dark:text-white font-semibold">{originCity.transitIndex.toFixed(1)}</span>
                    </div>
                    <div className="flex justify-between text-slate-600 dark:text-slate-300">
                      <span>Dining & Leisure:</span>
                      <span className="font-mono text-slate-900 dark:text-white font-semibold">{originCity.diningIndex.toFixed(1)}</span>
                    </div>
                    <div className="flex justify-between text-slate-600 dark:text-slate-300">
                      <span>Market Tech Median CTC:</span>
                      <span className="font-mono text-emerald-600 dark:text-emerald-400 font-bold">{originCity.medianTechSalaryLocal}</span>
                    </div>
                  </div>
                </div>

                {/* Destination City */}
                <div className="p-4 rounded-2xl bg-cyan-50/50 dark:bg-slate-950/60 border border-cyan-200 dark:border-cyan-500/20 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">{destCity.flag}</span>
                      <div>
                        <span className="font-bold text-slate-900 dark:text-white">{destCity.name}</span>
                        <span className="text-xs text-slate-500 dark:text-slate-400 block">{destCity.country} (Target Comparison)</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-xs text-slate-500 dark:text-slate-400 block">Overall Index</span>
                      <span className="text-lg font-black font-mono text-emerald-600 dark:text-emerald-400">
                        {destCity.costIndex.toFixed(1)}
                      </span>
                    </div>
                  </div>

                  <div className="space-y-1.5 pt-2 border-t border-slate-200 dark:border-white/10 text-xs">
                    <div className="flex justify-between text-slate-600 dark:text-slate-300">
                      <span>Residential Rent Index:</span>
                      <span className="font-mono text-slate-900 dark:text-white font-semibold">{destCity.rentIndex.toFixed(1)}</span>
                    </div>
                    <div className="flex justify-between text-slate-600 dark:text-slate-300">
                      <span>Groceries & Daily FMCG:</span>
                      <span className="font-mono text-slate-900 dark:text-white font-semibold">{destCity.groceriesIndex.toFixed(1)}</span>
                    </div>
                    <div className="flex justify-between text-slate-600 dark:text-slate-300">
                      <span>Municipal Transit:</span>
                      <span className="font-mono text-slate-900 dark:text-white font-semibold">{destCity.transitIndex.toFixed(1)}</span>
                    </div>
                    <div className="flex justify-between text-slate-600 dark:text-slate-300">
                      <span>Dining & Leisure:</span>
                      <span className="font-mono text-slate-900 dark:text-white font-semibold">{destCity.diningIndex.toFixed(1)}</span>
                    </div>
                    <div className="flex justify-between text-slate-600 dark:text-slate-300">
                      <span>Market Tech Median CTC:</span>
                      <span className="font-mono text-emerald-600 dark:text-emerald-400 font-bold">{destCity.medianTechSalaryLocal}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* External Verification Button */}
              <div className="p-4 rounded-2xl bg-cyan-50 dark:bg-cyan-950/30 border border-cyan-200 dark:border-cyan-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div>
                  <h4 className="text-xs font-bold text-cyan-800 dark:text-cyan-300">Cross-Verify with Live Numbeo Crowdsourced Data</h4>
                  <p className="text-[11px] text-slate-600 dark:text-slate-400">
                    Compare exact retail price items (bread, rent, transit, utility bills) between {originCity.name} and {destCity.name}.
                  </p>
                </div>
                <a
                  href={numbeoUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-white dark:bg-cyan-400 dark:hover:bg-cyan-300 dark:text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-all shadow-md shrink-0"
                >
                  <span>Verify on Numbeo</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          )}

          {/* TAB 3: EQUATION PROOF */}
          {activeTab === 'formula' && (
            <div className="space-y-5">
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 space-y-2">
                <span className="text-xs font-bold text-cyan-700 dark:text-cyan-400 uppercase tracking-wider">
                  Weighted Composite Parity Formula
                </span>
                <div className="p-3 rounded-xl bg-slate-900 dark:bg-slate-950/80 font-mono text-xs text-emerald-300 border border-slate-700 dark:border-emerald-500/20 overflow-x-auto space-y-1">
                  <div>Target Comp = Base × Parity Ratio × FX Rate × Lifestyle / Household Modifiers</div>
                  <div className="text-slate-400 text-[11px]">Composite Index = (Rent Index × {Math.round(parity.rentWeight * 100)}%) + (Core CPI × {Math.round(parity.cpiWeight * 100)}%)</div>
                </div>
              </div>

              <div className="space-y-3 text-xs">
                <h4 className="font-bold text-slate-900 dark:text-white">Step-by-Step Mathematical Breakdown:</h4>

                <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950/50 border border-slate-200 dark:border-white/10 space-y-1.5">
                  <div className="flex justify-between font-mono">
                    <span className="text-slate-600 dark:text-slate-400">1. Baseline Anchor in {originCity.name} ({isAnnual ? 'Annual' : 'Monthly'} Horizon):</span>
                    <span className="text-slate-900 dark:text-white font-bold">
                      {originCity.currencySymbol}{scenario.baseSalary.toLocaleString()}{periodLabel}
                    </span>
                  </div>
                  <div className="flex justify-between font-mono text-[11px] text-slate-500 dark:text-slate-400">
                    <span>Dual-Horizon Normalization:</span>
                    <span className="text-cyan-600 dark:text-cyan-300 font-semibold">
                      {originCity.currencySymbol}{Math.round(parity.baseSalaryMonthly).toLocaleString()}/mo ⇄ {originCity.currencySymbol}{Math.round(parity.baseSalaryAnnual).toLocaleString()}/yr
                    </span>
                  </div>
                  <div className="flex justify-between font-mono text-[11px] text-slate-500 dark:text-slate-400">
                    <span>FX Converted into Base USD:</span>
                    <span className="text-slate-700 dark:text-slate-300 font-semibold">${Math.round(parity.baseSalaryAnnual / (currencies.find(c => c.code === 'USD')?.rateToUSD || 1)).toLocaleString()} USD/yr</span>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950/50 border border-slate-200 dark:border-white/10 space-y-1.5">
                  <div className="flex justify-between font-mono">
                    <span className="text-slate-600 dark:text-slate-400">2. Composite Index &amp; Housing Rent Weighting:</span>
                    <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                      {parity.destCompositeIndex.toFixed(1)} ÷ {parity.originCompositeIndex.toFixed(1)} = {parity.ratio.toFixed(3)}x Composite
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 space-y-1 pt-1">
                    <div className="flex justify-between">
                      <span>• {originCity.name} Index:</span>
                      <span className="font-mono text-slate-800 dark:text-slate-200">CPI {originCity.costIndex.toFixed(1)} | Rent {originCity.rentIndex.toFixed(1)} → Comp {parity.originCompositeIndex.toFixed(1)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>• {destCity.name} Index:</span>
                      <span className="font-mono text-slate-800 dark:text-slate-200">CPI {destCity.costIndex.toFixed(1)} | Rent {destCity.rentIndex.toFixed(1)} → Comp {parity.destCompositeIndex.toFixed(1)}</span>
                    </div>
                    <div className="text-emerald-600 dark:text-emerald-400/90 text-[10px] mt-0.5">
                      ✓ Rent weighting ({Math.round(parity.rentWeight * 100)}%) prevents underestimating severe real-estate cost gaps.
                    </div>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950/50 border border-slate-200 dark:border-white/10 space-y-1.5">
                  <div className="flex justify-between font-mono">
                    <span className="text-slate-600 dark:text-slate-400">3. Target Required Compensation in {destCity.name}:</span>
                    <span className="text-slate-900 dark:text-white font-bold text-sm">
                      {destCity.currencySymbol}{Math.round(parity.targetRequiredDest).toLocaleString()}{periodLabel}
                    </span>
                  </div>
                  <div className="flex justify-between font-mono text-[11px] text-slate-500 dark:text-slate-400">
                    <span>Dual-Horizon Normalization:</span>
                    <span className="text-cyan-600 dark:text-cyan-300 font-semibold">
                      {destCity.currencySymbol}{Math.round(parity.targetRequiredDestMonthly).toLocaleString()}/mo ⇄ {destCity.currencySymbol}{Math.round(parity.targetRequiredDestAnnual).toLocaleString()}/yr
                    </span>
                  </div>
                  <div className="p-2 rounded-lg bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/30 text-[11px] text-emerald-700 dark:text-emerald-400 flex items-center justify-between">
                    <span>Unit Horizon Consistency Check</span>
                    <span className="font-bold">Consistent ({isAnnual ? 'Annual Input → Annual Output' : 'Monthly Input → Monthly Output'})</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: AUTHORITATIVE SOURCES */}
          {activeTab === 'sources' && (
            <div className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 space-y-1.5">
                  <div className="flex items-center gap-2 font-bold text-slate-900 dark:text-white">
                    <Globe className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
                    <span>Open Exchange Rates (ER-API)</span>
                  </div>
                  <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                    Provides mid-market foreign exchange rates aggregated from central banks including the European Central Bank (ECB), Bank of England, and US Federal Reserve.
                  </p>
                  <a
                    href="https://www.exchangerate-api.com"
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 text-cyan-600 dark:text-cyan-400 hover:underline pt-1 font-semibold"
                  >
                    <span>Provider Documentation</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>

                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 space-y-1.5">
                  <div className="flex items-center gap-2 font-bold text-slate-900 dark:text-white">
                    <Database className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                    <span>Numbeo Cost of Living Index</span>
                  </div>
                  <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                    The world&apos;s largest database of user-contributed cost of living data across global cities, standardizing consumer baskets across 160+ metros.
                  </p>
                  <a
                    href="https://www.numbeo.com/cost-of-living/"
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 text-cyan-600 dark:text-cyan-400 hover:underline pt-1 font-semibold"
                  >
                    <span>Numbeo Global Index</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>

                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 space-y-1.5">
                  <div className="flex items-center gap-2 font-bold text-slate-900 dark:text-white">
                    <ShieldCheck className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                    <span>Mercer & EIU Cost of Living</span>
                  </div>
                  <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                    International mobility standards utilized by Fortune 500 compensation committees to calibrate expatriate allowances and cost differentials.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 space-y-1.5">
                  <div className="flex items-center gap-2 font-bold text-slate-900 dark:text-white">
                    <Calculator className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                    <span>World Bank (ICP)</span>
                  </div>
                  <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                    International Comparison Program (ICP) purchasing power parity statistical frameworks measuring price level differences across geographic jurisdictions.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 border-t border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-slate-950/60 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-2">
            <Globe className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
            <span>Last rate update: {liveFx.lastUpdated}</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-200 hover:bg-slate-300 dark:bg-white/10 dark:hover:bg-white/15 text-slate-800 dark:text-white font-semibold transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
