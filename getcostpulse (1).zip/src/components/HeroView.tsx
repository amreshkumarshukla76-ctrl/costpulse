import React, { useMemo, useState } from 'react';
import {
  ArrowUpRight,
  TrendingUp,
  Activity,
  Building2,
  ShoppingCart,
  Train,
  UtensilsCrossed,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';
import { City, Currency, UserScenario } from '../types';
import { calculateParity, formatCurrencyNumber } from '../utils/parityCalc';

interface HeroViewProps {
  originCity: City;
  destCity: City;
  scenario: UserScenario;
  currencies: Currency[];
  onOpenAnalytics: () => void;
  onOpenAbout?: () => void;
  onOpenVerify?: () => void;
  onOpenUsp?: () => void;
  isDarkMode?: boolean;
}

export const HeroView: React.FC<HeroViewProps> = ({
  originCity,
  destCity,
  scenario,
  currencies,
  onOpenAnalytics,
  onOpenVerify,
  onOpenUsp,
  isDarkMode = false,
}) => {
  const {
    costDiffPercent,
    targetRequiredDest,
    targetRequiredDestAnnual,
    targetRequiredDestMonthly,
    baseSalaryAnnual,
    baseSalaryMonthly,
    ratio,
    baskets,
  } = useMemo(
    () => calculateParity(originCity, destCity, scenario, currencies),
    [originCity, destCity, scenario, currencies]
  );

  const destCurrency = currencies.find((c) => c.code === destCity.currency) || currencies[1];

  // Format parity delta banner
  const isDestMoreExpensive = costDiffPercent > 0;
  const costDiffFormatted = `${isDestMoreExpensive ? '+' : ''}${costDiffPercent.toFixed(1)}% Living Cost Gap (incl. Rent)`;

  // Base salary equivalence text with clear time period
  const periodLabel = scenario.isAnnual ? '/yr' : '/mo';
  const originFormattedSalary = `${originCity.currencySymbol}${scenario.baseSalary.toLocaleString()}${periodLabel}`;
  const destFormattedSalary = `${destCurrency.symbol}${Math.round(targetRequiredDest).toLocaleString()}${periodLabel}`;

  const secondaryEquivalenceText = scenario.isAnnual
    ? `≈ ${destCurrency.symbol}${Math.round(targetRequiredDestMonthly).toLocaleString()}/mo in ${destCity.name} vs ${originCity.currencySymbol}${Math.round(baseSalaryMonthly).toLocaleString()}/mo in ${originCity.name}`
    : `≈ ${destCurrency.symbol}${Math.round(targetRequiredDestAnnual).toLocaleString()}/yr in ${destCity.name} vs ${originCity.currencySymbol}${Math.round(baseSalaryAnnual).toLocaleString()}/yr in ${originCity.name}`;

  // Curated Architectural Luxury Villas & Cityscapes
  // Default matches the user's modern luxury architectural villa: timber slats, glowing glass pavilion, pool, lawn at dusk
  const LUXURY_VILLA_DUSK =
    'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=2500&q=85';
  const WATERFRONT_VILLA =
    'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=2500&q=85';
  const CONTEMPORARY_ESTATE =
    'https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&w=2500&q=85';

  const CITY_BACKGROUNDS: Record<string, string> = {
    'new-york-us': 'https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?auto=format&fit=crop&w=2000&q=80',
    'london-uk': 'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?auto=format&fit=crop&w=2000&q=80',
    'mumbai-in': 'https://images.unsplash.com/photo-1570168007204-dfb528c6958f?auto=format&fit=crop&w=2000&q=80',
    'singapore-sg': 'https://images.unsplash.com/photo-1525625293386-3f8f99389edd?auto=format&fit=crop&w=2000&q=80',
    'san-francisco-us': 'https://images.unsplash.com/photo-1501594907352-04cda38ebc29?auto=format&fit=crop&w=2000&q=80',
    'tokyo-jp': 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&w=2000&q=80',
    'dubai-ae': 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=2000&q=80',
    'paris-fr': 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=2000&q=80',
    'berlin-de': 'https://images.unsplash.com/photo-1560969184-10fe8719e047?auto=format&fit=crop&w=2000&q=80',
    'sydney-au': 'https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?auto=format&fit=crop&w=2000&q=80',
    'toronto-ca': 'https://images.unsplash.com/photo-1517090504586-fde19ea6066f?auto=format&fit=crop&w=2000&q=80',
    'amsterdam-nl': 'https://images.unsplash.com/photo-1512470876302-972faa2aa9a4?auto=format&fit=crop&w=2000&q=80',
    'hong-kong-hk': 'https://images.unsplash.com/photo-1506318137071-a8e063b4bec0?auto=format&fit=crop&w=2000&q=80',
    'zurich-ch': 'https://images.unsplash.com/photo-1515488764276-beab7607c1e6?auto=format&fit=crop&w=2000&q=80',
    'bengaluru-in': 'https://images.unsplash.com/photo-1596176530529-78163a4f7af2?auto=format&fit=crop&w=2000&q=80',
    'hyderabad-in': 'https://images.unsplash.com/photo-1605647540924-852290f6b0d5?auto=format&fit=crop&w=2000&q=80',
    'new-delhi-in': 'https://images.unsplash.com/photo-1587474260584-136574528ed5?auto=format&fit=crop&w=2000&q=80',
    'valencia-es': 'https://images.unsplash.com/photo-1579282240050-352db0a14c21?auto=format&fit=crop&w=2000&q=80',
    'long-beach-us': 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=2000&q=80',
  };

  const defaultMetropolitanBg =
    'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=2000&q=80';

  // Background Customization & Persistence State
  // Default to 'villa-dusk' - the architectural modern villa at 100% visibility requested by the user
  const [bgMode] = useState<string>(() => {
    const saved = localStorage.getItem('costpulse_bg_mode_v3');
    if (saved) return saved;
    return 'villa-dusk';
  });
  const [customBgUrl] = useState<string>(() => {
    return localStorage.getItem('costpulse_custom_bg') || '';
  });
  const [bgOpacity] = useState<number>(() => {
    const saved = localStorage.getItem('costpulse_bg_opacity_v3');
    // Default to 100% full clarity and visibility matching the user's mockup exactly
    return saved ? Number(saved) : 100;
  });

  // Select active background: Default to the architectural luxury villa shown in the design mockup
  let activeBackgroundUrl = LUXURY_VILLA_DUSK;
  let activeBackgroundLabel = 'Modern Luxury Villa at Dusk';

  if (bgMode === 'custom' && customBgUrl) {
    activeBackgroundUrl = customBgUrl;
    activeBackgroundLabel = 'Custom Uploaded Wallpaper';
  } else if (bgMode === 'city') {
    activeBackgroundUrl = CITY_BACKGROUNDS[destCity.id] || CITY_BACKGROUNDS[originCity.id] || defaultMetropolitanBg;
    activeBackgroundLabel = `${destCity.name} Metropolitan Cityscape`;
  } else if (bgMode === 'waterfront') {
    activeBackgroundUrl = WATERFRONT_VILLA;
    activeBackgroundLabel = 'Waterfront Architectural Villa';
  } else if (bgMode === 'estate') {
    activeBackgroundUrl = CONTEMPORARY_ESTATE;
    activeBackgroundLabel = 'Contemporary Glass Estate';
  } else {
    activeBackgroundUrl = LUXURY_VILLA_DUSK;
    activeBackgroundLabel = 'Modern Luxury Villa at Dusk';
  }

  return (
    <div className="relative min-h-screen w-full flex flex-col justify-between overflow-hidden bg-slate-950 transition-colors duration-500">
      {/* Crisp Architectural Luxury Villa Background with dynamic Day vs. Night-Light Ambiance */}
      <div className="absolute inset-0 z-0 pointer-events-none select-none overflow-hidden transition-all duration-700">
        <img
          src={activeBackgroundUrl}
          alt={activeBackgroundLabel}
          loading="eager"
          decoding="async"
          className={`w-full h-full object-cover object-center transition-all duration-700 ease-out ${
            isDarkMode
              ? 'brightness-[0.72] contrast-[1.14] saturate-[1.12] hue-rotate-[-6deg]'
              : 'brightness-100 contrast-100 saturate-[1.05]'
          }`}
          style={{ opacity: bgOpacity / 100 }}
          referrerPolicy="no-referrer"
        />
        {/* Day vs. Night Atmospheric Lighting Overlay */}
        <div
          className={`absolute inset-0 transition-opacity duration-700 pointer-events-none ${
            isDarkMode
              ? 'bg-gradient-to-b from-slate-950/80 via-slate-900/35 to-slate-950/90 mix-blend-multiply opacity-90'
              : 'bg-gradient-to-b from-black/25 via-transparent to-black/30 opacity-70'
          }`}
        />
        {/* Night-Light Moonlit & Architectural Warm Window Glow in Night Mode */}
        <div
          className={`absolute inset-0 transition-opacity duration-700 pointer-events-none ${
            isDarkMode
              ? 'bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-400/10 via-cyan-900/10 to-transparent opacity-80 mix-blend-screen'
              : 'opacity-0'
          }`}
        />
      </div>

      {/* Center Hero Content Container */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 md:px-8 pt-20 md:pt-28 pb-28 md:pb-16 flex-1 flex flex-col justify-between">
        {/* Top Badge & Central Display Title */}
        <div className="flex flex-col items-center text-center mt-2 md:mt-4">
          {/* Parity pill tag */}
          <div
            id="hero-parity-tag"
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border border-white/50 dark:border-slate-800 text-xs font-semibold text-slate-900 dark:text-slate-100 shadow-xl mb-3 md:mb-4"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-ping" />
            <span>
              {originCity.name} vs {destCity.name}
            </span>
            <span className="text-slate-400 dark:text-white/30">•</span>
            <span className={isDestMoreExpensive ? 'text-cyan-600 dark:text-cyan-400 font-bold' : 'text-emerald-600 dark:text-emerald-400 font-bold'}>
              {costDiffFormatted}
            </span>
          </div>

          {/* Main Display Title */}
          <h1
            id="hero-headline"
            className="text-3xl sm:text-5xl md:text-7xl font-extrabold text-white tracking-tight max-w-4xl drop-shadow-[0_2px_12px_rgba(0,0,0,0.6)]"
          >
            Purchasing Power <br className="hidden sm:inline" />
            <span className="text-white">
              Redefined
            </span>
          </h1>
        </div>

        {/* Lower Grid: Left Parity Synthesis + Right Floating Parity Delta Card */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-end mt-8 md:mt-12">
          {/* Left synthesis card */}
          <div className="md:col-span-5 flex flex-col justify-end">
            <div
              id="hero-synthesis-card"
              className="p-5 md:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl text-slate-700 dark:text-slate-200 w-full max-w-md"
            >
              <div className="flex items-center gap-2 text-cyan-600 dark:text-cyan-400 text-[11px] font-bold uppercase tracking-wider mb-2">
                <span className="w-2 h-2 rounded-full bg-cyan-500" />
                <span>Parity Synthesis</span>
              </div>

              <p className="text-sm leading-relaxed text-slate-600 dark:text-slate-300 font-normal">
                To maintain a{' '}
                <span className="font-bold text-slate-900 dark:text-white font-mono">{originFormattedSalary}</span> standard of living in{' '}
                <span className="font-semibold text-slate-900 dark:text-white">{originCity.name}</span>, you need an estimated{' '}
                <span className="text-cyan-600 dark:text-cyan-400 font-bold font-mono">
                  {destFormattedSalary}
                </span>{' '}
                in <span className="font-semibold text-slate-900 dark:text-white">{destCity.name}</span>. Overall cost of living in {destCity.name} is{' '}
                <span className="font-semibold text-slate-900 dark:text-white font-mono">
                  {isDestMoreExpensive ? `+${costDiffPercent.toFixed(1)}% higher` : `${Math.abs(costDiffPercent).toFixed(1)}% lower`}
                </span>{' '}
                when factoring housing, local goods, and taxes.
              </p>

              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-white/10 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                <button
                  type="button"
                  onClick={onOpenVerify}
                  className="flex items-center gap-1.5 hover:text-cyan-600 dark:hover:text-cyan-300 transition-colors text-left cursor-pointer"
                  title="Click to inspect live FX API response and macro data proofs"
                >
                  <span className="text-[10px] font-mono tracking-wider uppercase text-cyan-600 dark:text-cyan-400 font-bold flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-pulse" />
                    Open Data
                  </span>
                  <span className="font-semibold text-slate-700 dark:text-slate-300 hover:text-slate-950 dark:hover:text-white">Sources &amp; Math ↗</span>
                </button>
                <div className="flex items-center gap-1.5 text-cyan-600 dark:text-cyan-400 font-medium">
                  <span>Live Pulse</span>
                  <TrendingUp className="w-3.5 h-3.5" />
                </div>
              </div>
            </div>
          </div>

          {/* Right Parity Delta Card */}
          <div className="md:col-span-7 flex justify-end">
            <div
              id="hero-parity-delta-card"
              onClick={onOpenAnalytics}
              className="w-full max-w-lg p-5 md:p-6 rounded-3xl bg-white/75 dark:bg-slate-900/65 backdrop-blur-2xl border border-white/70 dark:border-white/15 shadow-2xl shadow-slate-950/15 dark:shadow-black/40 transition-all duration-300 hover:border-cyan-400/60 hover:bg-white/85 dark:hover:bg-slate-900/80 hover:shadow-cyan-500/15 cursor-pointer group"
            >
              {/* Header row */}
              <div className="flex items-center justify-between mb-3">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/15 dark:bg-cyan-500/20 text-cyan-700 dark:text-cyan-300 border border-cyan-500/30 text-xs font-bold uppercase tracking-wider backdrop-blur-md">
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-pulse" />
                  <span>Parity Delta</span>
                </div>
                <button
                  id="hero-expand-analytics-btn"
                  className="w-8 h-8 rounded-full bg-slate-100/80 dark:bg-white/10 backdrop-blur-md hover:bg-cyan-500 hover:text-slate-950 flex items-center justify-center text-slate-600 dark:text-slate-300 transition-colors"
                  title="View full financial model"
                >
                  <ArrowUpRight className="w-4 h-4" />
                </button>
              </div>

              {/* Title */}
              <div className="mb-4">
                <h3 className="text-xl md:text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                  {originCity.name} vs {destCity.name}
                </h3>
                <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  <TrendingUp className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400" />
                  <span>Effective Living Standard Equivalent</span>
                </div>
              </div>

              {/* Salary Equivalence Box */}
              <div className="p-4 rounded-2xl bg-slate-50/70 dark:bg-white/[0.04] backdrop-blur-md border border-slate-200/60 dark:border-white/10 mb-4 shadow-xs">
                <div className="flex items-center justify-between text-[11px] font-mono uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1">
                  <span>Purchasing Power Parity ({originCity.currency} / {destCurrency.code})</span>
                  <span className="text-cyan-600 dark:text-cyan-400 font-bold">{ratio.toFixed(3)}x Index Parity</span>
                </div>
                <div className="text-sm md:text-base text-slate-700 dark:text-slate-200">
                  You need{' '}
                  <span className="text-lg md:text-xl font-extrabold text-amber-600 dark:text-amber-400 font-mono">
                    {destFormattedSalary}
                  </span>{' '}
                  in {destCity.name} to match{' '}
                  <span className="font-bold text-slate-900 dark:text-white font-mono">{originFormattedSalary}</span> in{' '}
                  {originCity.name}.
                </div>
                <div className="mt-1 text-[11px] font-mono text-slate-500 dark:text-slate-400">
                  {secondaryEquivalenceText}
                </div>
              </div>

              {/* Itemized Parity Rows */}
              <div className="space-y-2 mb-4">
                {baskets.slice(0, 4).map((basket) => {
                  const isDestMoreExpensiveBasket = basket.diffPercent > 0;
                  return (
                    <div
                      key={basket.id}
                      className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50/65 dark:bg-white/[0.03] backdrop-blur-sm border border-slate-200/50 dark:border-white/5 text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-100/80 dark:hover:bg-white/[0.07] transition-colors gap-2"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        {basket.id === 'housing' && <Building2 className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400 shrink-0" />}
                        {basket.id === 'groceries' && <ShoppingCart className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />}
                        {basket.id === 'transit' && <Train className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0" />}
                        {basket.id === 'healthcare' && <ShieldCheck className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400 shrink-0" />}
                        {basket.id === 'dining' && <UtensilsCrossed className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400 shrink-0" />}
                        <div className="min-w-0">
                          <div className="font-medium text-slate-800 dark:text-slate-200 truncate">{basket.title}</div>
                          <div className="text-[10px] text-slate-500 dark:text-slate-400 font-mono truncate">
                            {originCity.currencySymbol}{basket.originMonthly.toLocaleString()}/mo vs {destCurrency.symbol}{basket.destMonthly.toLocaleString()}/mo
                          </div>
                        </div>
                      </div>
                      <div
                        className={`font-semibold font-mono text-[11px] px-2 py-0.5 rounded-md whitespace-nowrap shrink-0 ${
                          isDestMoreExpensiveBasket
                            ? 'bg-amber-500/15 text-amber-700 dark:text-amber-300 border border-amber-500/20'
                            : 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20'
                        }`}
                      >
                        {isDestMoreExpensiveBasket
                          ? `+${basket.diffPercent.toFixed(1)}% in ${destCity.name}`
                          : `${Math.abs(basket.diffPercent).toFixed(1)}% lower in ${destCity.name}`}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Card Footer */}
              <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 pt-3 border-t border-slate-100 dark:border-white/10">
                <div className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  <span>Live Macro Grounding</span>
                </div>
                <div className="flex items-center gap-2">
                  {onOpenVerify && (
                    <button
                      type="button"
                      onClick={onOpenVerify}
                      className="flex items-center gap-1.5 text-[11px] font-bold text-cyan-600 hover:text-cyan-700 dark:text-cyan-400 dark:hover:text-cyan-300 transition-colors bg-cyan-500/10 hover:bg-cyan-500/20 px-2.5 py-1 rounded-lg cursor-pointer"
                    >
                      <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                      <span>Inspect Data Proof</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Mobile-Only Dedicated "Why Choose GetCostPulse?" Section (cleanly separated at the bottom) */}
        {onOpenUsp && (
          <div className="mt-5 md:hidden">
            <button
              type="button"
              id="mobile-bottom-usp-btn"
              onClick={onOpenUsp}
              className="w-full p-4 rounded-2xl bg-gradient-to-r from-cyan-500/10 via-sky-500/5 to-cyan-500/10 border border-cyan-500/25 flex items-center justify-between text-xs text-slate-800 dark:text-slate-200 transition-all shadow-sm cursor-pointer active:scale-[0.99]"
            >
              <div className="flex items-center gap-3 text-left">
                <div className="w-9 h-9 rounded-xl bg-cyan-500/20 text-cyan-600 dark:text-cyan-400 flex items-center justify-center shrink-0">
                  <Sparkles className="w-4 h-4 text-cyan-500" />
                </div>
                <div>
                  <span className="font-bold text-slate-900 dark:text-white block text-xs">Why Choose GetCostPulse?</span>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400">See transparent comparison vs generic calculators</span>
                </div>
              </div>
              <span className="text-xs font-bold text-cyan-600 dark:text-cyan-400 bg-cyan-500/15 dark:bg-cyan-500/20 px-2.5 py-1 rounded-lg shrink-0 ml-2">
                Compare &rarr;
              </span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
