import React, { useState } from 'react';
import {
  Search,
  X,
  Building2,
  ArrowRight,
  TrendingUp,
  RefreshCw,
  Clock,
  History,
  Check,
} from 'lucide-react';
import { City, Currency } from '../types';
import { CITIES, CURRENCIES } from '../data/mockData';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectMetro: (city: City, role: 'origin' | 'dest') => void;
  onNavigateView: (view: 'hero' | 'analytics' | 'hub') => void;
  onOpenCurrencyModal: () => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  onSelectMetro,
  onNavigateView,
  onOpenCurrencyModal,
}) => {
  const [query, setQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'All' | 'Metros' | 'Pairs' | 'FX' | 'Saved'>('All');

  if (!isOpen) return null;

  const matchedCities = CITIES.filter(
    (c) =>
      c.name.toLowerCase().includes(query.toLowerCase()) ||
      c.country.toLowerCase().includes(query.toLowerCase())
  );

  const handleSelectPair = (originId: string, destId: string) => {
    const o = CITIES.find((c) => c.id === originId);
    const d = CITIES.find((c) => c.id === destId);
    if (o) onSelectMetro(o, 'origin');
    if (d) onSelectMetro(d, 'dest');
    onNavigateView('analytics');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 md:pt-20 px-4 bg-slate-900/60 dark:bg-slate-950/75">
      <div
        id="command-palette-modal"
        className="relative w-full max-w-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-white/15 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] text-slate-900 dark:text-slate-100 transition-colors"
      >
        {/* Search header */}
        <div className="p-4 border-b border-slate-200 dark:border-white/10 bg-slate-50/90 dark:bg-slate-900/90 space-y-3">
          <div className="relative flex items-center">
            <Search className="absolute left-3.5 w-5 h-5 text-slate-400 pointer-events-none" />
            <input
              type="text"
              autoFocus
              placeholder="Search metros, comparative pairs, currencies, or tools..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-full pl-11 pr-24 py-3 rounded-2xl bg-white dark:bg-slate-950/80 border border-slate-200 dark:border-white/12 text-sm text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 font-medium shadow-inner"
            />
            <button
              onClick={onClose}
              className="absolute right-3 px-2 py-1 rounded text-xs font-mono text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-white/5 hover:bg-slate-200 dark:hover:bg-white/10 border border-slate-200 dark:border-white/10"
            >
              ESC CLOSE
            </button>
          </div>

          {/* Filter Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto text-xs pb-1">
            {(
              [
                { id: 'All', label: 'ALL 24' },
                { id: 'Metros', label: 'METROS & CITIES 164' },
                { id: 'Pairs', label: 'COMPARATIVE PAIRS' },
                { id: 'FX', label: 'FX & CURRENCIES' },
                { id: 'Saved', label: 'SAVED REPORTS' },
              ] as const
            ).map((t) => (
              <button
                key={t.id}
                onClick={() => setActiveTab(t.id)}
                className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                  activeTab === t.id
                    ? 'bg-cyan-500 text-slate-950 shadow-sm font-bold'
                    : 'bg-white dark:bg-white/5 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/10 border border-slate-200 dark:border-white/5'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>

        {/* Search Results Body */}
        <div className="p-4 overflow-y-auto space-y-6 flex-1">
          {/* Top Metro Matches */}
          {(activeTab === 'All' || activeTab === 'Metros') && (
            <div>
              <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
                <span>Top Metro Matches</span>
                <span className="text-slate-400 dark:text-slate-500">Direct Index Telemetry</span>
              </div>

              <div className="space-y-2">
                {matchedCities.slice(0, 3).map((city) => (
                  <div
                    key={city.id}
                    className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-white/[0.02] border border-slate-200 dark:border-white/5 hover:bg-slate-100 dark:hover:bg-white/[0.06] hover:border-slate-300 dark:hover:border-white/15 transition-all"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-white/10 flex items-center justify-center text-lg shadow-sm">
                        {city.flag}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-sm text-slate-900 dark:text-white">
                            {city.name}, {city.country}
                          </span>
                          {city.id === 'london-uk' && (
                            <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-cyan-500/20 text-cyan-700 dark:text-cyan-300 border border-cyan-500/30">
                              Active Anchor
                            </span>
                          )}
                          {city.id === 'long-beach-us' && (
                            <span className="px-1.5 py-0.2 rounded text-[10px] font-mono text-slate-500 dark:text-slate-400 bg-slate-200 dark:bg-white/5">
                              Tier 2 Metro
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                          Base Currency: {city.currency} ({city.currencySymbol}) •{' '}
                          <span className="text-cyan-600 dark:text-cyan-400 font-semibold">{city.surplusNote}</span> • Median Tech:{' '}
                          {city.medianTechSalaryLocal}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          onSelectMetro(city, 'dest');
                          onClose();
                        }}
                        className="px-3 py-1.5 rounded-xl bg-cyan-500/15 hover:bg-cyan-500 hover:text-slate-950 text-cyan-700 dark:text-cyan-300 text-xs font-bold transition-all border border-cyan-500/30"
                      >
                        Select City ⇄
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Comparative Pairs & Parity Workspaces */}
          {(activeTab === 'All' || activeTab === 'Pairs') && (
            <div>
              <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
                <span>Comparative Pairs &amp; Parity Workspaces</span>
                <span className="text-slate-400 dark:text-slate-500">Arbitrage Models</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div
                  onClick={() => handleSelectPair('london-uk', 'new-york-us')}
                  className="p-3.5 rounded-2xl bg-slate-50 dark:bg-white/[0.02] border border-slate-200 dark:border-white/5 hover:border-cyan-500/40 cursor-pointer transition-all group"
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-sm text-slate-900 dark:text-white group-hover:text-cyan-600 dark:group-hover:text-cyan-300">
                      London ⇄ New York
                    </span>
                    <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-cyan-500/20 text-cyan-700 dark:text-cyan-300 border border-cyan-500/30">
                      Benchmark
                    </span>
                  </div>
                  <div className="text-xs text-slate-600 dark:text-slate-400">
                    Net Parity Target: <span className="font-bold text-slate-900 dark:text-white font-mono">$132,400 /yr</span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-cyan-600 dark:text-cyan-400 mt-2 pt-2 border-t border-slate-200 dark:border-white/5 font-semibold">
                    <span>↗ +18.4% Out-of-pocket Delta</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>

                <div
                  onClick={() => handleSelectPair('london-uk', 'berlin-de')}
                  className="p-3.5 rounded-2xl bg-slate-50 dark:bg-white/[0.02] border border-slate-200 dark:border-white/5 hover:border-cyan-500/40 cursor-pointer transition-all group"
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-sm text-slate-900 dark:text-white group-hover:text-cyan-600 dark:group-hover:text-cyan-300">
                      London ⇄ Berlin
                    </span>
                    <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-blue-500/20 text-blue-700 dark:text-blue-300 border border-blue-500/30">
                      EU Corridor
                    </span>
                  </div>
                  <div className="text-xs text-slate-600 dark:text-slate-400">
                    EUR Parity Target: <span className="font-bold text-slate-900 dark:text-white font-mono">€74,800 /yr</span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-emerald-600 dark:text-emerald-400 mt-2 pt-2 border-t border-slate-200 dark:border-white/5 font-semibold">
                    <span>↘ -22.5% Average Rent Saving</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Tools & Telemetry Deep-Links */}
          {(activeTab === 'All' || activeTab === 'FX') && (
            <div>
              <div className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
                Tools &amp; Telemetry Deep-Links
              </div>
              <div className="space-y-2">
                <div
                  onClick={() => {
                    onOpenCurrencyModal();
                    onClose();
                  }}
                  className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-white/[0.02] border border-slate-200 dark:border-white/5 hover:bg-slate-100 dark:hover:bg-white/[0.05] cursor-pointer transition-all"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-slate-200 dark:bg-slate-800 flex items-center justify-center text-cyan-600 dark:text-cyan-400 shadow-sm">
                      <RefreshCw className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-900 dark:text-white">Live FX &amp; Purchasing Power Matrix</div>
                      <div className="text-[11px] text-slate-600 dark:text-slate-400">
                        Real-time syndicated cross-rates for GBP, USD, EUR, CHF &amp; JPY
                      </div>
                    </div>
                  </div>
                  <span className="text-[11px] font-mono text-cyan-600 dark:text-cyan-400 font-bold">JUMP 1 →</span>
                </div>
              </div>
            </div>
          )}

          {/* Global Anchor Info Cards */}
          <div className="grid grid-cols-3 gap-3 pt-2">
            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-white/[0.02] border border-slate-200 dark:border-white/5">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 block">
                Global Anchor
              </span>
              <div className="text-xs font-bold text-slate-900 dark:text-white mt-1">London, UK</div>
              <div className="text-lg font-black text-cyan-600 dark:text-cyan-400 font-mono">100.0 <span className="text-[10px] text-slate-500 dark:text-slate-400 font-sans font-normal">Base</span></div>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-white/[0.02] border border-slate-200 dark:border-white/5">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 block">
                Highest Parity Gap
              </span>
              <div className="text-xs font-bold text-slate-900 dark:text-white mt-1">Zurich, CH</div>
              <div className="text-lg font-black text-rose-600 dark:text-rose-400 font-mono">+44.2% <span className="text-[10px] text-slate-500 dark:text-slate-400 font-sans font-normal">vs LDN</span></div>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-white/[0.02] border border-slate-200 dark:border-white/5">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 block">
                Highest Purchasing Gain
              </span>
              <div className="text-xs font-bold text-slate-900 dark:text-white mt-1">Valencia, ES</div>
              <div className="text-lg font-black text-emerald-600 dark:text-emerald-400 font-mono">-42.8% <span className="text-[10px] text-slate-500 dark:text-slate-400 font-sans font-normal">vs LDN</span></div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-slate-950/80 flex items-center justify-between text-xs text-slate-600 dark:text-slate-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-cyan-500" />
            <span>164 Metros Syndicated • IMF/Numbeo Realtime</span>
          </div>
          <span className="font-mono text-[11px] text-slate-500">Type &quot;vs&quot; to compare</span>
        </div>
      </div>
    </div>
  );
};
