import React, { useState } from 'react';
import {
  ArrowUpRight,
  Bookmark,
  TrendingUp,
  User,
  Bell,
  RefreshCw,
  Sliders,
  BookOpen,
  Search,
  CheckCircle2,
  ExternalLink,
} from 'lucide-react';
import { PLATFORM_MODULES } from '../data/mockData';
import { AdContainer } from './AdContainer';

interface PlatformHubViewProps {
  onNavigate: (view: 'hero' | 'analytics' | 'hub') => void;
  onOpenSearch: () => void;
  onOpenCurrencyModal: () => void;
  onOpenSettings: () => void;
  onOpenAlerts: () => void;
  onShowToast?: (msg: string, type?: 'success' | 'info' | 'warning') => void;
  onOpenVerify?: () => void;
}

export const PlatformHubView: React.FC<PlatformHubViewProps> = ({
  onNavigate,
  onOpenSearch,
  onOpenCurrencyModal,
  onOpenSettings,
  onOpenAlerts,
  onShowToast,
  onOpenVerify,
}) => {
  const [selectedFilter, setSelectedFilter] = useState<'All' | 'Core Tools' | 'Analytics' | 'Settings & FX' | 'Documentation'>('All');

  const filteredModules = PLATFORM_MODULES.filter((m) => {
    if (selectedFilter === 'All') return true;
    return m.category === selectedFilter;
  });

  const handleModuleClick = (id: string) => {
    if (id === 'matrix') onNavigate('analytics');
    else if (id === 'currencies') onOpenCurrencyModal();
    else if (id === 'settings') onOpenSettings();
    else if (id === 'alerts') onOpenAlerts();
    else if (id === 'docs' && onOpenVerify) onOpenVerify();
    else if (id === 'macro' && onOpenVerify) onOpenVerify();
    else if (id === 'saved' || id === 'profile') onNavigate('analytics');
    else {
      onShowToast?.(`Opening ${id} whitepaper and parity econometric methodology.`, 'info');
    }
  };

  return (
    <div className="min-h-screen w-full pt-20 md:pt-24 pb-32 md:pb-16 px-4 md:px-10 max-w-7xl mx-auto flex flex-col justify-between text-slate-900 dark:text-slate-100 transition-colors">
      <div>
        {/* Top Breadcrumb & Title */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2 text-[11px] font-mono tracking-wider uppercase text-cyan-600 dark:text-cyan-400 mb-1">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-pulse" />
              <span>App Navigation &amp; Workspace</span>
              <span className="text-slate-400 dark:text-white/20">/</span>
              <span className="text-slate-500 dark:text-slate-400">Version 2.4 Daylight</span>
            </div>
            <h1 className="text-3xl md:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              Navigation &amp; Platform Hub
            </h1>
            <p className="text-sm text-slate-600 dark:text-slate-400 max-w-2xl mt-1">
              Explore all comparative benchmarks, macroeconomic telemetry modules, parity indices, and personal relocation workspace tools.
            </p>
          </div>

          {/* Quick Jump Search Box */}
          <div
            onClick={onOpenSearch}
            className="flex items-center gap-3 px-4 py-2.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:border-cyan-500/40 cursor-pointer shadow-sm transition-all group"
          >
            <Search className="w-4 h-4 text-slate-400 group-hover:text-cyan-500" />
            <span className="text-xs">Jump to screen, tool, or metric...</span>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-slate-600 dark:text-slate-400">
              Ctrl+K
            </span>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 mb-6 text-xs">
          {(['All', 'Core Tools', 'Analytics', 'Settings & FX', 'Documentation'] as const).map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedFilter(cat)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                selectedFilter === cat
                  ? 'bg-cyan-500 text-slate-950 shadow-sm font-bold'
                  : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              {cat === 'All' ? 'All Modules' : cat}
            </button>
          ))}
        </div>

        {/* Live Data Verification Banner */}
        {onOpenVerify && (
          <div className="mb-6 p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-sm">
            <div className="flex items-center gap-3">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse shrink-0" />
              <div>
                <span className="text-xs font-bold text-slate-900 dark:text-white block">
                  Authoritative Econometric &amp; Real-Time FX Syndication
                </span>
                <span className="text-[11px] text-slate-600 dark:text-slate-400">
                  Exchange rates updated live via open.er-api.com • Metros calibrated against Numbeo &amp; Mercer standards.
                </span>
              </div>
            </div>
            <button
              onClick={onOpenVerify}
              className="px-3.5 py-1.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-700 dark:text-emerald-300 font-bold text-xs flex items-center gap-1.5 transition-colors shrink-0 self-start sm:self-auto"
            >
              <span>Inspect Live Data &amp; Proofs</span>
              <span className="text-xs">↗</span>
            </button>
          </div>
        )}

        {/* Bento Grid of Modules */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-5">
          {filteredModules.map((m) => (
            <div
              key={m.id}
              onClick={() => handleModuleClick(m.id)}
              className="group p-5 md:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-cyan-500/40 shadow-sm hover:shadow-md transition-all duration-200 cursor-pointer flex flex-col justify-between"
            >
              <div>
                {/* Header row with badge & hotkey */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-cyan-500/15 text-cyan-700 dark:text-cyan-300 border border-cyan-500/25">
                      {m.badge}
                    </span>
                    <span className="text-[11px] font-mono text-slate-500">{m.hotkey}</span>
                  </div>

                  <div className="w-7 h-7 rounded-full bg-slate-100 dark:bg-white/5 group-hover:bg-cyan-500 group-hover:text-slate-950 flex items-center justify-center text-slate-500 dark:text-slate-400 transition-colors">
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </div>
                </div>

                {/* Module title */}
                <h3 className="text-lg font-bold text-slate-900 dark:text-white group-hover:text-cyan-600 dark:group-hover:text-cyan-300 transition-colors mb-2">
                  {m.title}
                </h3>

                {/* Description */}
                <p className="text-xs leading-relaxed text-slate-600 dark:text-slate-400 font-normal">
                  {m.description}
                </p>
              </div>

              {/* Bottom footer text */}
              <div className="mt-5 pt-3 border-t border-slate-100 dark:border-white/5 flex items-center justify-between text-xs">
                <span className="text-slate-500 font-medium text-[11px]">{m.footerText}</span>
                <span className="text-cyan-600 dark:text-cyan-400 group-hover:underline font-semibold text-[11px]">
                  {m.actionText}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Google AdSense Responsive Display Inventory Container */}
      <AdContainer adSlot="7192830491" className="mt-8 mb-2" />

      {/* Hub Telemetry Footer */}
      <div className="mt-10 pt-4 border-t border-slate-200 dark:border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500 dark:text-slate-400">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span>Numbeo + IMF Data Engine active</span>
          <span className="text-slate-400">•</span>
          <span>Last synced 2 mins ago</span>
          <span className="text-slate-400">•</span>
          <span>Statistical Confidence: 99.4%</span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('hero')}
            className="px-3 py-1 rounded-lg bg-slate-100 dark:bg-white/5 hover:bg-slate-200 dark:hover:bg-white/10 text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition-colors text-xs"
          >
            ESC Return to Dashboard
          </button>
          <span className="font-mono text-slate-500 text-[11px]">1 - 8 Quick Launch</span>
        </div>
      </div>
    </div>
  );
};
