import React, { useState, useEffect } from 'react';
import {
  X,
  LifeBuoy,
  Send,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Clock,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  ShieldAlert,
  Sparkles,
  RefreshCw,
  LogOut,
  Laptop,
  Mail,
  Copy,
  ExternalLink,
} from 'lucide-react';
import { City, Currency, UserScenario } from '../types';

export const SUPPORT_EMAIL = 'Alphafee@outlook.com';

export interface SupportTicket {
  id: string;
  category: string;
  priority: 'normal' | 'high' | 'urgent';
  subject: string;
  message: string;
  email: string;
  createdAt: string;
  status: 'received' | 'investigating' | 'resolved';
  telemetry: {
    originCity: string;
    destCity: string;
    baseSalary: string;
    currency: string;
    theme: string;
    timestamp: string;
  };
}

export const buildSupportTicketEmailText = (ticket: SupportTicket) => {
  return `GetCostPulse Support Ticket #${ticket.id}
==============================================
Priority SLA  : ${ticket.priority.toUpperCase()} (<4h response target)
Category      : ${ticket.category}
Sender Email  : ${ticket.email}
Created At    : ${ticket.createdAt}

----------------------------------------------
SUBJECT:
${ticket.subject}

----------------------------------------------
DETAILS / COMPLAINT:
${ticket.message}

----------------------------------------------
SYSTEM TELEMETRY & DIAGNOSTICS:
Origin Metro    : ${ticket.telemetry.originCity}
Target Metro    : ${ticket.telemetry.destCity}
Base Salary     : ${ticket.telemetry.baseSalary}
Active Currency : ${ticket.telemetry.currency}
Active Theme    : ${ticket.telemetry.theme}
Timestamp       : ${ticket.telemetry.timestamp}
App Environment : ${typeof window !== 'undefined' ? window.location.origin : 'GetCostPulse Web'}
==============================================`;
};

export const buildSupportMailto = (ticket: SupportTicket) => {
  const mailSubject = encodeURIComponent(`[GetCostPulse Support #${ticket.id}] ${ticket.subject}`);
  const mailBody = encodeURIComponent(buildSupportTicketEmailText(ticket));
  return `mailto:${SUPPORT_EMAIL}?subject=${mailSubject}&body=${mailBody}`;
};

interface SupportModalProps {
  isOpen: boolean;
  onClose: () => void;
  userEmail?: string;
  isAuthenticated: boolean;
  originCity: City;
  destCity: City;
  scenario: UserScenario;
  activeCurrency: Currency;
  onSignOut?: () => void;
  onShowToast?: (msg: string, type?: 'success' | 'info' | 'warning') => void;
}

const DEFAULT_FAQS = [
  {
    q: 'How do I securely sign out of my active session?',
    a: 'Click your profile shield icon in the top right header or bottom toolbar, which opens your Account & Session Manager. From there, select "Sign Out & Disconnect Session". You can also sign out directly from the Preferences Drawer.',
  },
  {
    q: 'How does the Daylight vs Night theme work?',
    a: 'Click the Sun/Moon icon on the toolbar or open Settings to select "Light" (Daylight) or "Dark" mode. Daylight mode utilizes an airy, high-contrast off-white canvas engineered for high ambient lighting.',
  },
  {
    q: 'Where is the navigation toolbar on mobile and tablet screens?',
    a: 'On mobile and tablet devices, the toolbar is anchored along the bottom edge of your screen for natural thumb reach. On desktop monitors, it rests on the left dock rail.',
  },
  {
    q: 'Where do cost indices and exchange rates come from?',
    a: 'Click the "Data & Sources" badge in the header or the shield icon on the toolbar. This opens our Data Sources & Calculation Inspector displaying live rates from open.er-api.com and public benchmark references from Numbeo and the World Bank.',
  },
  {
    q: 'What should I do if a city or rental figure looks inaccurate?',
    a: 'Submit feedback using the "Data Discrepancy / Inaccuracy Report" category on this screen to flag benchmark adjustments.',
  },
];

export const SupportModal: React.FC<SupportModalProps> = ({
  isOpen,
  onClose,
  userEmail = '',
  isAuthenticated,
  originCity,
  destCity,
  scenario,
  activeCurrency,
  onSignOut,
  onShowToast,
}) => {
  const [activeTab, setActiveTab] = useState<'lodge' | 'tickets' | 'faq'>('lodge');
  const [category, setCategory] = useState('Data Discrepancy / Inaccuracy Complaint');
  const [priority, setPriority] = useState<'normal' | 'high' | 'urgent'>('normal');
  const [email, setEmail] = useState(userEmail || 'user@company.com');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [attachTelemetry, setAttachTelemetry] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedTicket, setSubmittedTicket] = useState<SupportTicket | null>(null);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);
  const [hasCopied, setHasCopied] = useState(false);

  // Load existing tickets from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem('costpulse_support_tickets');
      if (saved) {
        setTickets(JSON.parse(saved));
      }
    } catch {
      // ignore
    }
  }, [isOpen]);

  useEffect(() => {
    if (userEmail) setEmail(userEmail);
  }, [userEmail]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim() || !message.trim()) {
      onShowToast?.('Please provide both a subject and a description of your issue or complaint.', 'warning');
      return;
    }

    setIsSubmitting(true);

    setTimeout(() => {
      const newTicket: SupportTicket = {
        id: `CP-${Math.floor(10000 + Math.random() * 90000)}`,
        category,
        priority,
        subject: subject.trim(),
        message: message.trim(),
        email: email.trim(),
        createdAt: new Date().toLocaleString(),
        status: 'received',
        telemetry: {
          originCity: `${originCity.name}, ${originCity.country}`,
          destCity: `${destCity.name}, ${destCity.country}`,
          baseSalary: `${originCity.currencySymbol}${scenario.baseSalary.toLocaleString()}`,
          currency: activeCurrency.code,
          theme: scenario.theme,
          timestamp: new Date().toISOString(),
        },
      };

      const updated = [newTicket, ...tickets];
      setTickets(updated);
      try {
        localStorage.setItem('costpulse_support_tickets', JSON.stringify(updated));
      } catch {
        // ignore
      }

      setSubmittedTicket(newTicket);
      setIsSubmitting(false);

      // Trigger user's mail client addressed directly to Alphafee@outlook.com
      const mailtoUrl = buildSupportMailto(newTicket);
      try {
        window.location.href = mailtoUrl;
      } catch {
        // ignore if blocked by browser sandbox
      }

      onShowToast?.(`Ticket #${newTicket.id} logged. Email draft prepared for Support Desk!`, 'success');
    }, 450);
  };

  const handleResetForm = () => {
    setSubmittedTicket(null);
    setSubject('');
    setMessage('');
    setHasCopied(false);
    setActiveTab('lodge');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 animate-fadeIn">
      <div
        id="support-complaint-modal"
        className="relative w-full max-w-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-white/15 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] text-slate-900 dark:text-slate-100 transition-colors"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-600 dark:text-cyan-400 shrink-0">
              <LifeBuoy className="w-5 h-5 stroke-[2.2]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white tracking-tight">
                  Support &amp; Issue Resolution Desk
                </h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30">
                  LIVE RESPONSE
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Lodge a complaint, report a calculation glitch, or consult quick self-service fixes.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-200 dark:hover:bg-white/10 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-2 px-6 pt-3 pb-2 border-b border-slate-200 dark:border-white/10 bg-slate-100/60 dark:bg-slate-950/30 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('lodge')}
            className={`px-3 py-1.5 rounded-xl transition-all ${
              activeTab === 'lodge'
                ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Lodge Complaint / Issue
          </button>
          <button
            onClick={() => setActiveTab('tickets')}
            className={`px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 ${
              activeTab === 'tickets'
                ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <span>My Lodged Tickets</span>
            {tickets.length > 0 && (
              <span className="px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-slate-900/20 dark:bg-white/20">
                {tickets.length}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('faq')}
            className={`px-3 py-1.5 rounded-xl transition-all ${
              activeTab === 'faq'
                ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Self-Service FAQs
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 text-xs">
          {/* TAB 1: LODGE COMPLAINT / ISSUE */}
          {activeTab === 'lodge' && (
            <div>
              {submittedTicket ? (
                <div className="py-6 text-center space-y-4">
                  <div className="w-14 h-14 mx-auto rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-500 flex items-center justify-center">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <div>
                    <span className="px-3 py-1 rounded-full text-[11px] font-mono font-bold bg-cyan-500/15 text-cyan-600 dark:text-cyan-400 border border-cyan-500/30">
                      TICKET REFERENCE: #{submittedTicket.id}
                    </span>
                    <h3 className="text-xl font-extrabold text-slate-900 dark:text-white mt-2">
                      Complaint Queued for Support Desk
                    </h3>
                    <p className="text-slate-500 dark:text-slate-400 max-w-md mx-auto mt-1 leading-relaxed">
                      Your complaint regarding <strong className="text-slate-800 dark:text-slate-200">"{submittedTicket.subject}"</strong> has been logged. An email draft pre-addressed to our official support desk has been prepared with full system diagnostics.
                    </p>
                  </div>

                  <div className="p-4 rounded-2xl bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-white/10 text-left max-w-md mx-auto space-y-2 font-mono text-[11px]">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Destination:</span>
                      <span className="font-bold text-cyan-600 dark:text-cyan-400">Official Support Desk</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Category:</span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200">{submittedTicket.category}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Priority SLA:</span>
                      <span className="font-bold text-amber-500 uppercase">{submittedTicket.priority} (&lt;4h response)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Diagnostics Attached:</span>
                      <span className="text-emerald-500">{submittedTicket.telemetry.originCity} ⇄ {submittedTicket.telemetry.destCity} • Live FX</span>
                    </div>
                  </div>

                  {/* Action dispatch buttons */}
                  <div className="flex flex-col sm:flex-row items-center justify-center gap-2.5 pt-2 max-w-md mx-auto">
                    <a
                      href={buildSupportMailto(submittedTicket)}
                      className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Mail className="w-4 h-4 shrink-0" />
                      <span>Send / Re-open in Email Client</span>
                    </a>
                    <button
                      type="button"
                      onClick={() => {
                        try {
                          navigator.clipboard.writeText(buildSupportTicketEmailText(submittedTicket));
                          setHasCopied(true);
                          setTimeout(() => setHasCopied(false), 2500);
                          onShowToast?.(`Ticket #${submittedTicket.id} report copied to clipboard!`, 'info');
                        } catch {
                          onShowToast?.('Failed to copy. Please click the Send Email button above.', 'warning');
                        }
                      }}
                      className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-slate-200 dark:bg-white/10 hover:bg-slate-300 dark:hover:bg-white/15 text-slate-800 dark:text-white font-semibold transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      {hasCopied ? (
                        <>
                          <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                          <span className="text-emerald-500 font-bold">Copied to Clipboard!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4 shrink-0" />
                          <span>Copy Ticket Report</span>
                        </>
                      )}
                    </button>
                  </div>

                  <div className="flex items-center justify-center gap-3 pt-1">
                    <button
                      onClick={handleResetForm}
                      className="text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 underline cursor-pointer"
                    >
                      Lodge Another Issue
                    </button>
                    <span className="text-slate-400">•</span>
                    <button
                      onClick={() => setActiveTab('tickets')}
                      className="text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 underline cursor-pointer"
                    >
                      View All Tickets ({tickets.length})
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  {/* Category & Priority */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 block mb-1">
                        Complaint / Inquiry Category
                      </label>
                      <select
                        value={category}
                        onChange={(e) => setCategory(e.target.value)}
                        className="w-full px-3 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-950 border border-slate-300 dark:border-white/10 text-slate-900 dark:text-white focus:outline-none focus:border-cyan-400 font-medium"
                      >
                        <option value="Data Discrepancy / Inaccuracy Complaint">Data Discrepancy / Inaccuracy Complaint</option>
                        <option value="Parity Calculation / Math Question">Parity Calculation / Math Question</option>
                        <option value="Technical Bug or Interface Issue">Technical Bug or Interface Issue</option>
                        <option value="Theme / Daylight Display Issue">Theme / Daylight Display Issue</option>
                        <option value="Missing City or Metro Request">Missing City or Metro Request</option>
                        <option value="Account / Session / Sign-out Inquiry">Account / Session / Sign-out Inquiry</option>
                        <option value="General Feedback or Feature Suggestion">General Feedback or Feature Suggestion</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 block mb-1">
                        Severity &amp; Priority
                      </label>
                      <div className="grid grid-cols-3 gap-1.5">
                        {(['normal', 'high', 'urgent'] as const).map((p) => (
                          <button
                            key={p}
                            type="button"
                            onClick={() => setPriority(p)}
                            className={`py-2 px-2 rounded-xl text-center font-bold capitalize transition-all ${
                              priority === p
                                ? p === 'urgent'
                                  ? 'bg-rose-500 text-white shadow-sm'
                                  : p === 'high'
                                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                                  : 'bg-cyan-500 text-slate-950 shadow-sm'
                                : 'bg-slate-100 dark:bg-slate-950/60 text-slate-600 dark:text-slate-400 border border-slate-300 dark:border-white/10'
                            }`}
                          >
                            {p}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Email & Subject */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 block mb-1">
                        Your Contact Email
                      </label>
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full px-3 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-950 border border-slate-300 dark:border-white/10 text-slate-900 dark:text-white focus:outline-none focus:border-cyan-400"
                        placeholder="you@company.com"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 block mb-1">
                        Summary / Subject Line
                      </label>
                      <input
                        type="text"
                        value={subject}
                        onChange={(e) => setSubject(e.target.value)}
                        className="w-full px-3 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-950 border border-slate-300 dark:border-white/10 text-slate-900 dark:text-white focus:outline-none focus:border-cyan-400"
                        placeholder="e.g., Rent index discrepancy for London vs Berlin"
                        required
                      />
                    </div>
                  </div>

                  {/* Detailed Description */}
                  <div>
                    <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 block mb-1">
                      Detailed Complaint / Explanation
                    </label>
                    <textarea
                      rows={4}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      className="w-full p-3 rounded-xl bg-slate-100 dark:bg-slate-950 border border-slate-300 dark:border-white/10 text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                      placeholder="Please describe what you experienced, any discrepancies you noticed, or what you would like addressed..."
                      required
                    />
                  </div>

                  {/* Diagnostic Telemetry Auto-attach */}
                  <div className="p-3.5 rounded-2xl bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-white/10 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <input
                        type="checkbox"
                        id="telemetry-check"
                        checked={attachTelemetry}
                        onChange={(e) => setAttachTelemetry(e.target.checked)}
                        className="rounded border-slate-300 dark:border-white/20 text-cyan-500 focus:ring-cyan-400"
                      />
                      <label htmlFor="telemetry-check" className="cursor-pointer">
                        <span className="font-bold text-slate-800 dark:text-slate-200 block">
                          Attach Live System Diagnostics &amp; Active Metro Pair
                        </span>
                        <span className="text-[11px] text-slate-500 dark:text-slate-400">
                          {originCity.name} ⇄ {destCity.name} • {activeCurrency.code} • Base {originCity.currencySymbol}{scenario.baseSalary.toLocaleString()}
                        </span>
                      </label>
                    </div>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 border border-cyan-500/20 shrink-0">
                      TELEMETRY
                    </span>
                  </div>

                  {/* Direct Recipient Notice */}
                  <div className="p-3 rounded-xl bg-cyan-500/5 dark:bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-between text-[11px]">
                    <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
                      <Mail className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400 shrink-0" />
                      <span>Complaints route directly to our <strong className="text-cyan-600 dark:text-cyan-400 font-bold">Official Support Desk</strong></span>
                    </div>
                    <span className="font-mono text-[10px] text-slate-500">DIRECT INBOX</span>
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-sky-500 hover:from-cyan-400 hover:to-sky-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-lg shadow-cyan-500/20 disabled:opacity-50 cursor-pointer"
                  >
                    {isSubmitting ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Logging Ticket &amp; Preparing Mail to Support Desk...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>Submit Issue &amp; Send to Support</span>
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>
          )}

          {/* TAB 2: MY TICKETS */}
          {activeTab === 'tickets' && (
            <div className="space-y-3">
              {tickets.length === 0 ? (
                <div className="py-12 text-center text-slate-500 dark:text-slate-400 space-y-2">
                  <ShieldAlert className="w-10 h-10 mx-auto opacity-40" />
                  <p className="font-semibold">No complaints or tickets lodged yet.</p>
                  <p className="text-[11px]">If you experience any issues or discrepancies, submit a ticket using the first tab.</p>
                </div>
              ) : (
                <>
                  <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-white/10 text-slate-500">
                    <span>{tickets.length} total logged tickets</span>
                    <button
                      onClick={() => {
                        localStorage.removeItem('costpulse_support_tickets');
                        setTickets([]);
                        onShowToast?.('Ticket history cleared.', 'info');
                      }}
                      className="text-[11px] text-rose-500 hover:underline cursor-pointer"
                    >
                      Clear History
                    </button>
                  </div>

                  {tickets.map((t) => (
                    <div
                      key={t.id}
                      className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-white/10 space-y-2"
                    >
                      <div className="flex items-center justify-between gap-2 flex-wrap">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-cyan-600 dark:text-cyan-400">
                            #{t.id}
                          </span>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 uppercase">
                            {t.status}
                          </span>
                        </div>
                        <span className="text-[11px] text-slate-400">{t.createdAt}</span>
                      </div>

                      <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                        {t.subject}
                      </h4>

                      <p className="text-slate-600 dark:text-slate-400 text-xs leading-relaxed bg-white/50 dark:bg-white/[0.02] p-2.5 rounded-xl border border-slate-200/50 dark:border-white/5">
                        {t.message}
                      </p>

                      <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 font-mono flex-wrap gap-2">
                        <span>Category: {t.category}</span>
                        <a
                          href={buildSupportMailto(t)}
                          className="px-2.5 py-1 rounded-lg bg-cyan-500/15 text-cyan-600 dark:text-cyan-400 font-bold border border-cyan-500/30 flex items-center gap-1 hover:bg-cyan-500/25 transition-all text-[11px] cursor-pointer"
                        >
                          <Mail className="w-3.5 h-3.5" />
                          <span>Email Support</span>
                        </a>
                      </div>
                    </div>
                  ))}
                </>
              )}
            </div>
          )}

          {/* TAB 3: SELF-SERVICE FAQS */}
          {activeTab === 'faq' && (
            <div className="space-y-2.5">
              {DEFAULT_FAQS.map((faq, i) => (
                <div
                  key={i}
                  className="rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-white/10 overflow-hidden"
                >
                  <button
                    onClick={() => setOpenFaqIndex(openFaqIndex === i ? null : i)}
                    className="w-full p-3.5 text-left flex items-center justify-between gap-3 font-semibold text-slate-900 dark:text-white"
                  >
                    <span>{faq.q}</span>
                    {openFaqIndex === i ? (
                      <ChevronUp className="w-4 h-4 text-cyan-500 shrink-0" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                    )}
                  </button>
                  {openFaqIndex === i && (
                    <div className="px-3.5 pb-3.5 text-slate-600 dark:text-slate-400 text-xs leading-relaxed border-t border-slate-200/50 dark:border-white/5 pt-2.5">
                      {faq.a}
                      {i === 0 && isAuthenticated && onSignOut && (
                        <div className="mt-3">
                          <button
                            onClick={() => {
                              onSignOut();
                              onClose();
                            }}
                            className="px-3 py-1.5 rounded-xl bg-rose-500/15 text-rose-500 dark:text-rose-400 font-bold border border-rose-500/30 flex items-center gap-1.5 hover:bg-rose-500/25 transition-all"
                          >
                            <LogOut className="w-3.5 h-3.5" />
                            <span>Sign Out of Current Session Right Now</span>
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer Support Hotline */}
        <div className="px-6 py-3 border-t border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-slate-950/80 flex items-center justify-between text-xs text-slate-500 flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>
              Official Support Desk • Typical response: &lt; 2 hours
            </span>
          </div>
          <span className="font-mono text-[10px]">v2.4 Production Support</span>
        </div>
      </div>
    </div>
  );
};
