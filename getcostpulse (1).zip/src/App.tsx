import React, { useState, useEffect } from 'react';
import { CITIES, CURRENCIES, DEFAULT_SCENARIO, ALERT_ITEMS } from './data/mockData';
import { City, Currency, UserScenario, AlertItem, UserProfile } from './types';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { HeroView } from './components/HeroView';
import { AnalyticsView } from './components/AnalyticsView';
import { PlatformHubView } from './components/PlatformHubView';
import { CitySelectorModal } from './components/CitySelectorModal';
import { CurrencyModal } from './components/CurrencyModal';
import { AuthModal } from './components/AuthModal';
import { SettingsDrawer } from './components/SettingsDrawer';
import { CommandPalette } from './components/CommandPalette';
import { AlertsModal } from './components/AlertsModal';
import { SalaryEditorModal } from './components/SalaryEditorModal';
import { ToastContainer, ToastMessage } from './components/Toast';
import { DataVerificationModal } from './components/DataVerificationModal';
import { SupportModal } from './components/SupportModal';
import { DisclaimerPrivacyModal } from './components/DisclaimerPrivacyModal';
import { UspModal } from './components/UspModal';
import { UserProfileModal } from './components/UserProfileModal';
import { fetchLiveExchangeRates, LiveFxState } from './utils/liveFxService';
import { getRealisticBaselineForCity, calculateParity } from './utils/parityCalc';
import { updateComparisonSEO } from './utils/seoHelper';
import { AlertTriangle, X } from 'lucide-react';

const DEFAULT_USER_PROFILE: UserProfile = {
  fullName: 'Alexander Wright',
  role: 'Senior Staff Engineer',
  email: 'alexander.wright@techparity.io',
  homeCityId: 'lon',
  preferredCurrency: 'GBP',
  baseSalary: 125000,
  isAnnual: true,
  bio: 'Global software engineer evaluating European & US purchasing power parity and tax-adjusted relocation compensation.',
  avatarColor: 'cyan',
};

export function App() {
  const [originCity, setOriginCity] = useState<City>(CITIES[0]); // London
  const [destCity, setDestCity] = useState<City>(CITIES[1]); // New York
  const [scenario, setScenario] = useState<UserScenario>(DEFAULT_SCENARIO);
  const [currencies, setCurrencies] = useState<Currency[]>(CURRENCIES);
  const [activeCurrency, setActiveCurrency] = useState<Currency>(CURRENCIES[0]); // GBP
  const [activeView, setActiveView] = useState<'hero' | 'analytics' | 'hub'>('hero');
  const [alerts, setAlerts] = useState<AlertItem[]>(ALERT_ITEMS);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // User Profile State with local storage persistence
  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem('costpulse_user_profile_v1');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to parse saved user profile', e);
    }
    return DEFAULT_USER_PROFILE;
  });
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);

  // One-time disclaimer acknowledgement state (stored in localStorage)
  const [hasAcknowledgedDisclaimer, setHasAcknowledgedDisclaimer] = useState<boolean>(() => {
    return localStorage.getItem('costpulse_disclaimer_ack') === 'true';
  });

  const handleDismissDisclaimer = () => {
    setHasAcknowledgedDisclaimer(true);
    localStorage.setItem('costpulse_disclaimer_ack', 'true');
  };

  // Live FX State
  const [liveFx, setLiveFx] = useState<LiveFxState>({
    currencies: CURRENCIES,
    lastUpdated: 'Live syncing...',
    nextUpdate: '',
    provider: 'Open Exchange Rates (open.er-api.com)',
    isLive: false,
    isLoading: true,
  });

  // Modals & Panels
  const [isOriginPickerOpen, setIsOriginPickerOpen] = useState(false);
  const [isDestPickerOpen, setIsDestPickerOpen] = useState(false);
  const [isCurrencyModalOpen, setIsCurrencyModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isAlertsOpen, setIsAlertsOpen] = useState(false);
  const [isSalaryEditorOpen, setIsSalaryEditorOpen] = useState(false);
  const [isVerifyOpen, setIsVerifyOpen] = useState(false);
  const [isSupportOpen, setIsSupportOpen] = useState(false);
  const [isDisclaimerModalOpen, setIsDisclaimerModalOpen] = useState(false);
  const [disclaimerInitialTab, setDisclaimerInitialTab] = useState<'disclaimer' | 'terms' | 'privacy'>('disclaimer');
  const [isUspModalOpen, setIsUspModalOpen] = useState(false);

  // User Auth State
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userEmail, setUserEmail] = useState('');

  const handleOpenDisclaimer = (tab: 'disclaimer' | 'terms' | 'privacy' = 'disclaimer') => {
    setDisclaimerInitialTab(tab);
    setIsDisclaimerModalOpen(true);
  };

  const showToast = (message: string, type: 'success' | 'info' | 'warning' = 'info') => {
    const id = Date.now().toString() + Math.random().toString(36).substring(2, 5);
    setToasts((prev) => [...prev.slice(-3), { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3500);
  };

  const handleDismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Live FX Refresh function
  const handleRefreshLiveFx = async (isManual = false) => {
    try {
      const data = await fetchLiveExchangeRates();
      setCurrencies(data.currencies);
      setLiveFx({
        currencies: data.currencies,
        lastUpdated: data.lastUpdated,
        nextUpdate: data.nextUpdate,
        provider: data.provider,
        isLive: true,
        isLoading: false,
        lastFetchDurationMs: data.durationMs,
        error: null,
        isFallback: data.isFallback,
      });

      // Synchronize active currency
      setActiveCurrency((prev) => {
        const matching = data.currencies.find((c) => c.code === prev.code);
        return matching || prev;
      });

      if (!data.isFallback) {
        if (isManual) {
          showToast(`Live exchange rates updated via ${data.provider} (${data.durationMs}ms)`, 'success');
        }
      } else if (isManual) {
        showToast('Exchange rates loaded from baseline benchmark rates.', 'info');
      }
    } catch {
      // Quiet failover to reliable local benchmark rates
      setCurrencies(CURRENCIES);
      setLiveFx((prev) => ({
        ...prev,
        isLive: true,
        isLoading: false,
        error: null,
        provider: 'Consolidated Institutional FX Matrix',
        isFallback: true,
      }));
    }
  };

  // Mount effect: Fetch live real-world exchange rates immediately
  useEffect(() => {
    handleRefreshLiveFx(false);
  }, []);

  // Dark Mode (Main theme is Daylight)
  const isDarkMode = scenario.theme === 'dark' || (scenario.theme === 'system' && typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Dynamic OpenGraph meta tags & JSON-LD structured data for every comparison page and view
  useEffect(() => {
    const destCurrency = currencies.find((c) => c.code === destCity.currency) || currencies[1];
    const parityResult = calculateParity(originCity, destCity, scenario, currencies);
    updateComparisonSEO(
      activeView,
      originCity,
      destCity,
      scenario,
      parityResult.targetRequiredDest,
      destCurrency?.symbol || '$'
    );
  }, [activeView, originCity, destCity, scenario, currencies]);

  // Global Keyboard shortcuts (Ctrl+K, 1-3 views, Esc)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept when user is typing in inputs or textareas
      const tag = (document.activeElement?.tagName || '').toLowerCase();
      if (tag === 'input' || tag === 'textarea' || tag === 'select') {
        if (e.key === 'Escape') {
          (document.activeElement as HTMLElement)?.blur();
        }
        return;
      }

      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchOpen((prev) => !prev);
        return;
      }

      if (e.key === '1') {
        setActiveView('hero');
        return;
      }
      if (e.key === '2') {
        setActiveView('analytics');
        return;
      }
      if (e.key === '3') {
        setActiveView('hub');
        return;
      }

      if (e.key === 'Escape') {
        setIsOriginPickerOpen(false);
        setIsDestPickerOpen(false);
        setIsCurrencyModalOpen(false);
        setIsAuthModalOpen(false);
        setIsSettingsOpen(false);
        setIsSearchOpen(false);
        setIsAlertsOpen(false);
        setIsSalaryEditorOpen(false);
        setIsVerifyOpen(false);
        setIsSupportOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleUpdateScenario = (updates: Partial<UserScenario>) => {
    setScenario((prev) => ({ ...prev, ...updates }));
  };

  const handleSignOut = () => {
    setIsAuthenticated(false);
    setUserEmail('');
    showToast('You have been securely signed out.', 'info');
  };

  const handleSwapCities = () => {
    const temp = originCity;
    setOriginCity(destCity);
    setDestCity(temp);

    // If swapping across currency boundaries, update activeCurrency and recalibrate baseline
    if (destCity.currency !== originCity.currency) {
      const newCurr = currencies.find((c) => c.code === destCity.currency) || currencies[0];
      setActiveCurrency(newCurr);
      const realisticSalary = getRealisticBaselineForCity(destCity, scenario.isAnnual);
      setScenario((prev) => ({
        ...prev,
        currencyCode: destCity.currency,
        baseSalary: realisticSalary,
      }));
    }

    showToast(`Metros inverted: ${destCity.name} ⇄ ${temp.name}`, 'info');
  };

  const handleMarkAllAlertsAsRead = () => {
    setAlerts((prev) => prev.map((a) => ({ ...a, read: true })));
    showToast('All volatility and parity notifications marked as read.', 'success');
  };

  const unreadAlertsCount = alerts.filter((a) => !a.read).length;

  const handleSaveProfile = (updated: UserProfile) => {
    setUserProfile(updated);
    try {
      localStorage.setItem('costpulse_user_profile_v1', JSON.stringify(updated));
    } catch (e) {
      console.error('Failed to save profile to localStorage', e);
    }
    showToast(`Profile updated for ${updated.fullName}`, 'success');
  };

  return (
    <div className="relative min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans selection:bg-cyan-500 selection:text-slate-950 transition-colors duration-300">
      {/* Top Floating Glass Header */}
      <Header
        originCity={originCity}
        destCity={destCity}
        baseSalary={scenario.baseSalary}
        isAnnual={scenario.isAnnual}
        activeCurrency={activeCurrency}
        userProfile={userProfile}
        onOpenOriginPicker={() => setIsOriginPickerOpen(true)}
        onOpenDestPicker={() => setIsDestPickerOpen(true)}
        onOpenSalaryEditor={() => setIsSalaryEditorOpen(true)}
        onOpenCurrencyModal={() => setIsCurrencyModalOpen(true)}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        onOpenProfile={() => setIsProfileModalOpen(true)}
        onSwapCities={handleSwapCities}
        onCalculateClick={() => setActiveView('analytics')}
        onLogoClick={() => setActiveView('hero')}
        onOpenVerify={() => setIsVerifyOpen(true)}
        onOpenSupport={() => setIsSupportOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenUsp={() => setIsUspModalOpen(true)}
        onSignOut={handleSignOut}
        onToggleTheme={() => {
          const nextTheme = isDarkMode ? 'light' : 'dark';
          handleUpdateScenario({ theme: nextTheme });
        }}
        isDarkMode={isDarkMode}
        isAuthenticated={isAuthenticated}
        activeView={activeView}
      />

      {/* Left Docked Sidebar Rail */}
      <Sidebar
        activeView={activeView}
        onSelectView={(v) => setActiveView(v)}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        onOpenProfile={() => setIsProfileModalOpen(true)}
        onOpenAlerts={() => setIsAlertsOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenVerify={() => setIsVerifyOpen(true)}
        onOpenSupport={() => setIsSupportOpen(true)}
        onToggleTheme={() => {
          const nextTheme = isDarkMode ? 'light' : 'dark';
          handleUpdateScenario({ theme: nextTheme });
        }}
        isDarkMode={isDarkMode}
        unreadAlertsCount={unreadAlertsCount}
      />

      {/* Main View Area (Single View Switcher) */}
      <main className="w-full">
        {activeView === 'hero' && (
          <HeroView
            originCity={originCity}
            destCity={destCity}
            scenario={scenario}
            currencies={currencies}
            onOpenAnalytics={() => setActiveView('analytics')}
            onOpenAbout={() => setIsSettingsOpen(true)}
            onOpenVerify={() => setIsVerifyOpen(true)}
            onOpenUsp={() => setIsUspModalOpen(true)}
            isDarkMode={isDarkMode}
          />
        )}

        {activeView === 'analytics' && (
          <AnalyticsView
            originCity={originCity}
            destCity={destCity}
            scenario={scenario}
            currencies={currencies}
            onUpdateScenario={handleUpdateScenario}
            onNavigate={(v) => setActiveView(v)}
            onShowToast={showToast}
            onOpenVerify={() => setIsVerifyOpen(true)}
          />
        )}

        {activeView === 'hub' && (
          <PlatformHubView
            onNavigate={(v) => setActiveView(v)}
            onOpenSearch={() => setIsSearchOpen(true)}
            onOpenCurrencyModal={() => setIsCurrencyModalOpen(true)}
            onOpenSettings={() => setIsSettingsOpen(true)}
            onOpenAlerts={() => setIsAlertsOpen(true)}
            onShowToast={showToast}
            onOpenVerify={() => setIsVerifyOpen(true)}
          />
        )}
      </main>

      {/* One-Time Initial Disclaimer Notice (Appears once, dismissible, never repeated on every page) */}
      {!hasAcknowledgedDisclaimer && (
        <div
          id="initial-disclaimer-notice"
          className="fixed bottom-20 sm:bottom-6 left-4 right-4 sm:left-auto sm:right-6 sm:max-w-md z-40 p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl text-xs text-slate-700 dark:text-slate-300 animate-in fade-in slide-in-from-bottom-2 duration-200"
        >
          <div className="flex items-start gap-2.5">
            <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
            <div className="flex-1 space-y-1">
              <p className="text-[11px] leading-relaxed">
                <span className="font-bold text-slate-900 dark:text-white">Disclaimer:</span> Cost and parity calculations are mathematical approximations for educational planning and do not constitute financial, legal, or tax advisory.
              </p>
              <div className="flex items-center gap-3 pt-0.5">
                <button
                  onClick={() => handleOpenDisclaimer('disclaimer')}
                  className="text-[11px] font-semibold text-cyan-600 dark:text-cyan-400 hover:underline cursor-pointer"
                >
                  Read full disclaimer &rarr;
                </button>
                <button
                  onClick={handleDismissDisclaimer}
                  className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-white/10 dark:hover:bg-white/15 font-bold text-[11px] text-slate-800 dark:text-slate-200 transition-colors cursor-pointer ml-auto"
                >
                  Understood
                </button>
              </div>
            </div>
            <button
              onClick={handleDismissDisclaimer}
              className="p-1 -mr-1 -mt-1 text-slate-400 hover:text-slate-700 dark:hover:text-white transition-colors cursor-pointer"
              title="Dismiss"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Modals & Dialogs */}
      <CitySelectorModal
        isOpen={isOriginPickerOpen}
        onClose={() => setIsOriginPickerOpen(false)}
        selectedCityId={originCity.id}
        title="Select Anchor Baseline City"
        onSelectCity={(c) => {
          setOriginCity(c);
          // If the newly selected origin city uses a different currency, auto-recalibrate
          if (c.currency !== originCity.currency) {
            const newCurr = currencies.find((curr) => curr.code === c.currency) || currencies[0];
            setActiveCurrency(newCurr);
            const realisticSalary = getRealisticBaselineForCity(c, scenario.isAnnual);
            setScenario((prev) => ({
              ...prev,
              currencyCode: c.currency,
              baseSalary: realisticSalary,
            }));
            showToast(`Origin set to ${c.name}, ${c.country} (Anchor calibrated to ${c.currencySymbol}${realisticSalary.toLocaleString()}${scenario.isAnnual ? '/yr' : '/mo'})`, 'info');
          } else {
            showToast(`Origin set to ${c.name}, ${c.country}`, 'info');
          }
        }}
        onShowToast={showToast}
      />

      <CitySelectorModal
        isOpen={isDestPickerOpen}
        onClose={() => setIsDestPickerOpen(false)}
        selectedCityId={destCity.id}
        title="Select Target Comparison City"
        onSelectCity={(c) => {
          setDestCity(c);
          showToast(`Target set to ${c.name}, ${c.country}`, 'info');
        }}
        onShowToast={showToast}
      />

      <CurrencyModal
        isOpen={isCurrencyModalOpen}
        onClose={() => setIsCurrencyModalOpen(false)}
        selectedCurrencyCode={activeCurrency.code}
        onOpenVerify={() => {
          setIsCurrencyModalOpen(false);
          setIsVerifyOpen(true);
        }}
        liveLastUpdated={liveFx.lastUpdated}
        onSelectCurrency={(c) => {
          setActiveCurrency(c);
          handleUpdateScenario({ currencyCode: c.code });
          showToast(`Active currency benchmark converted to ${c.code} (${c.symbol})`, 'success');
        }}
      />

      <SalaryEditorModal
        isOpen={isSalaryEditorOpen}
        onClose={() => setIsSalaryEditorOpen(false)}
        currentSalary={scenario.baseSalary}
        isAnnual={scenario.isAnnual}
        originCity={originCity}
        onSaveSalary={(num, isAnnual) => {
          handleUpdateScenario({ baseSalary: num, isAnnual });
          showToast(`Baseline compensation updated to ${originCity.currencySymbol}${num.toLocaleString()}${isAnnual ? '/yr' : '/mo'}`, 'success');
        }}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        isAuthenticated={isAuthenticated}
        userEmail={userEmail}
        onSuccessAuth={(em) => {
          setIsAuthenticated(true);
          setUserEmail(em);
          showToast(`Signed in as ${em}`, 'success');
        }}
        onSignOut={handleSignOut}
        onShowToast={showToast}
      />

      <SettingsDrawer
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        scenario={scenario}
        onUpdateScenario={handleUpdateScenario}
        originCity={originCity}
        onOpenOriginPicker={() => {
          setIsSettingsOpen(false);
          setIsOriginPickerOpen(true);
        }}
        onShowToast={showToast}
        isAuthenticated={isAuthenticated}
        userEmail={userEmail}
        onSignOut={handleSignOut}
        onOpenSupport={() => {
          setIsSettingsOpen(false);
          setIsSupportOpen(true);
        }}
        onOpenAuth={() => {
          setIsSettingsOpen(false);
          setIsAuthModalOpen(true);
        }}
        onOpenDisclaimer={() => handleOpenDisclaimer('disclaimer')}
        onOpenPrivacy={() => handleOpenDisclaimer('privacy')}
        onOpenTerms={() => handleOpenDisclaimer('terms')}
        onOpenUsp={() => {
          setIsSettingsOpen(false);
          setIsUspModalOpen(true);
        }}
      />

      <SupportModal
        isOpen={isSupportOpen}
        onClose={() => setIsSupportOpen(false)}
        userEmail={userEmail}
        isAuthenticated={isAuthenticated}
        originCity={originCity}
        destCity={destCity}
        scenario={scenario}
        activeCurrency={activeCurrency}
        onSignOut={handleSignOut}
        onShowToast={showToast}
      />

      <CommandPalette
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectMetro={(c, role) => {
          if (role === 'origin') {
            setOriginCity(c);
            showToast(`Origin set to ${c.name}`, 'info');
          } else {
            setDestCity(c);
            showToast(`Target set to ${c.name}`, 'info');
          }
        }}
        onNavigateView={(v) => setActiveView(v)}
        onOpenCurrencyModal={() => setIsCurrencyModalOpen(true)}
      />

      <AlertsModal
        isOpen={isAlertsOpen}
        onClose={() => setIsAlertsOpen(false)}
        alerts={alerts}
        onMarkAllAsRead={handleMarkAllAlertsAsRead}
      />

      {/* Financial & Tax Disclaimer, Terms Modal */}
      <DisclaimerPrivacyModal
        isOpen={isDisclaimerModalOpen}
        onClose={() => setIsDisclaimerModalOpen(false)}
        initialTab={disclaimerInitialTab}
      />

      {/* Live Data & Telemetry Verification Inspector */}
      <DataVerificationModal
        isOpen={isVerifyOpen}
        onClose={() => setIsVerifyOpen(false)}
        originCity={originCity}
        destCity={destCity}
        scenario={scenario}
        currencies={currencies}
        liveFx={liveFx}
        onRefreshLiveFx={() => handleRefreshLiveFx(true)}
      />

      {/* Unique Selling Proposition (USP) Transparency & Retention Modal */}
      <UspModal
        isOpen={isUspModalOpen}
        onClose={() => setIsUspModalOpen(false)}
        onOpenAnalytics={() => setActiveView('analytics')}
      />

      {/* User Profile Editor Modal */}
      <UserProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        profile={userProfile}
        cities={CITIES}
        currencies={currencies}
        onSaveProfile={handleSaveProfile}
        isAuthenticated={isAuthenticated}
        onSignOut={handleSignOut}
        onOpenAuth={() => {
          setIsProfileModalOpen(false);
          setIsAuthModalOpen(true);
        }}
        onShowToast={showToast}
      />

      {/* Floating Non-Blocking Toast Notifications Container */}
      <ToastContainer toasts={toasts} onDismiss={handleDismissToast} />
    </div>
  );
}

export default App;
